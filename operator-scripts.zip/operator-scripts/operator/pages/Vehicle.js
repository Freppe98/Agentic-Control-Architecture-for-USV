// Vehicle.js — the professional diagnostics page. Fleet systems matrix, then the
// selected vehicle organized into named sections an operator can scan top-to-bottom:
// Vehicle Health, Control, Power, Communication, Local Agent, Sensors, System.
//
// Every diagnostic here is ALWAYS LIVE — there is no "Run System Check" button or
// simulated delay. The previous version's check ran a fake 550ms timer and then
// re-displayed values already computed from the fleet payload (Scout exposes no real
// diagnostics endpoint — see BACKEND_ROADMAP.md); that click-and-wait added workload
// for zero new information, so every one of its checks now renders continuously in
// the section it actually belongs to instead.
//
// Vehicle Health's Home verification / Current waypoint / Mission loaded reuse the
// SAME Pixhawk mission readback + lib/mission.js math as Map.js and Mission.js — this
// page can never disagree with those two about the same vehicle's mission state.
//
// Reuses VehicleDock, CommsPill, BatteryBar, AuthoritySeg, ui/home/mission helpers.
import * as api from "../services/api.js";
import { NavRail } from "../components/NavRail.js";
import { Ribbon, updateRibbon } from "../components/Ribbon.js";
import { CommsPill } from "../components/CommsPill.js";
import { BatteryBar } from "../components/BatteryBar.js";
import { AuthoritySeg } from "../components/AuthoritySeg.js";
import { vehicleRows } from "../components/VehicleDock.js";
import { commState, cls, fmtAge, pad3, noTelem } from "../lib/ui.js";
import { createAuthorityController, handoffGate } from "../lib/authority.js";
import { isSafetyHold, SAFETY_HOLD_TITLE, homeStatus, commandGate, commandGateCtx } from "../lib/home.js";
import { classifyMissionWaypoints, missionCounts } from "../lib/mission.js";
import { commandVerification } from "../lib/command.js";

const MXCOLS = [["battery", "Battery"], ["sensors", "Sensors"], ["gps", "GPS"], ["compass", "Compass"], ["storage", "Storage"], ["cpu", "CPU"], ["network", "Network"]];
const SEV_ORDER = { ok: 0, caution: 1, warn: 2 };
const SEV_LABEL = { ok: "Nominal", warn: "Warning", caution: "Caution" };
function sevLabel(sev) { return SEV_LABEL[sev] || "No signal"; }
function sevClass(sev) { return sev || "idle"; }
function worstSev(...sevs) {
  let w = null;
  sevs.forEach((sv) => { if (sv && sv in SEV_ORDER) { if (w == null || SEV_ORDER[sv] > SEV_ORDER[w]) w = sv; } });
  return w;
}

// Command & Control: the safe command set for the reverse path. High-risk commands
// (ARM/DISARM touch the motors; AUTO/RTL change what the vehicle does on its own) get
// an extra operator confirmation and are sent with confirm:true. Labels are the
// operator's shorthand; the value is the backend command type. Buttons are enabled
// only when the latest Scout-confirmed control authority is OPERATOR — see the
// Control card below; there is no separate/independent authority store. Under
// LOCAL_AGENT the station is read-only for vehicle writes (strict ownership: no
// SET_HOME/LOITER exemption), and under RC the physical override wins — both leave
// hasControl false, which is the single write-enable predicate (lib/authority.js).
//
// Mode presentation follows the shared taxonomy (lib/home.js): LOITER is the Scout's
// PRIMARY safety hold (active anti-drift) and sits in the primary row beside AUTO /
// MANUAL / RTL; the mission + arming controls follow. HOLD and GUIDED are demoted to a
// collapsed "Advanced modes" group — HOLD is a PASSIVE hold (kept for backend
// compatibility) and must never read as LOITER's equal.
const PRIMARY_CMDS = [
  ["SET_MODE_AUTO", "AUTO"], ["SET_MODE_MANUAL", "MANUAL"],
  ["SET_MODE_LOITER", "LOITER"], ["RTL", "RTL"],
  ["MISSION_PAUSE", "PAUSE MISSION"], ["MISSION_RESUME", "RESUME MISSION"],
  ["ARM", "ARM"], ["DISARM", "DISARM"],
];
const ADVANCED_CMDS = [["SET_MODE_HOLD", "HOLD"], ["SET_MODE_GUIDED", "GUIDED"]];
const CMDS = [...PRIMARY_CMDS, ...ADVANCED_CMDS];  // combined lookup (labels, routing)
const HIGH_RISK = new Set(["ARM", "DISARM", "RTL", "SET_MODE_AUTO"]);
const CMD_STATUS_CLS = { QUEUED: "u", SENT: "p", ACCEPTED: "p", EXECUTED: "c", REJECTED: "d", FAILED: "d", EXPIRED: "u" };
const fmtClock = (iso) => { if (!iso) return "—"; const d = new Date(iso); return Number.isNaN(d.getTime()) ? "—" : d.toLocaleTimeString([], { hour12: false }); };
const lockSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="11" width="16" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';

export function Vehicle(root) {
  let fleet = [], selId = null, cmds = [];
  const pxm = {};  // per-vehicle Pixhawk mission cache — same contract as Map.js/Mission.js

  // Control authority — a dedicated read (GET /api/control_authority/{id}, a live
  // proxy to Scout's Flask API), fed through the shared authority controller so a
  // hand-off is PENDING until the effective value Scout reports confirms it (then
  // confirmed / rejected / timeout). NOT fleet data, NOT the command queue. Scout is
  // the sole source of truth; the operator backend holds no authority of its own.
  //   Take Control  → request OPERATOR   Release Control → request LOCAL_AGENT
  const authCtl = createAuthorityController(() => renderDetail());
  function loadAuthority(id) {
    if (id == null) return;
    api.getControlAuthority(id).then((a) => {
      if (id === selId) authCtl.setServer(a);
    }).catch(() => {
      if (id === selId) authCtl.setServer({ ok: true, available: true, reachable: false, authority: null });
    });
  }
  function refreshCommands() {
    const id = selId;
    if (id == null) return;
    api.getCommands(id).then((d) => {
      if (id !== selId) return;
      cmds = (d && d.commands) || [];
      renderDetail();
    }).catch(() => {
      if (id !== selId) return;
      cmds = [];
      renderDetail();
    });
  }
  function pxmState(id) { return pxm[id] || (pxm[id] = { mission: null, fetchedAt: 0, loading: false, note: null }); }
  async function fetchPixhawkMission(id) {
    if (id == null) return;
    const s = pxmState(id);
    s.loading = true; if (id === selId) renderDetail();
    try {
      const res = await api.getPixhawkMission(id);
      if (res && res.reachable) { s.mission = res; s.fetchedAt = Date.now(); s.note = res.available === false ? "no-api" : (res.partial ? "partial" : null); }
      else s.note = (res && res.available === false) ? "no-api" : "unreachable";
    } catch (e) { s.note = "error"; }
    finally { s.loading = false; if (id === selId) renderDetail(); }
  }
  function selectVehicle(id) {
    if (id !== selId) {
      selId = id; authCtl.reset(); loadAuthority(id);
      cmds = []; refreshCommands();
      // Auto-fetch once per vehicle per page visit (this page's whole purpose is
      // showing vehicle state) — Refresh stays a deliberate action for re-fetches,
      // the same caution Map.js's live Scout proxy already uses.
      if (!pxm[id] || !pxm[id].fetchedAt) fetchPixhawkMission(id);
    }
  }

  root.className = "app dock-main";
  root.innerHTML =
    Ribbon({ missionLabel: "Live fleet" }) +
    NavRail("vehicle") +
    `<div class="dock">
       <div class="dock-h"><span class="lbl">Vehicles</span><span class="lbl">Systems</span></div>
       <div class="veh-list" id="veh-list"></div>
       <div class="dock-foot">
         <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 8v4l3 2"/></svg>
         <span>Every diagnostic below is live — no "run check" button or simulated delay. Values tagged <b>Not reported</b> have no telemetry field yet; never invented.</span>
       </div>
     </div>
     <div class="content-main">
       <div class="toolbar"><h1>Vehicle</h1><span class="count mono" id="vcount">—</span></div>
       <div class="vcontent">
         <div class="sect"><span class="lbl">Fleet systems matrix</span><span class="tag">vehicles × subsystems · click a row for detail</span></div>
         <div class="mxwrap" id="mxwrap"></div>
         <div class="sect"><span class="lbl">Vehicle diagnostics</span><span class="tag" id="dettag"></span></div>
         <div class="detail" id="detail"></div>
       </div>
     </div>`;

  // ---- derive subsystem severity + display value from live data (feeds the matrix
  // AND the section severities below — one computation, never two slightly different
  // judgements of the same battery/leak/gps reading) ----
  function subsys(v) {
    const h = v.health || {}, comm = commState(v);
    const num = (x) => (x == null ? null : x);
    return {
      battery: v.battery == null ? { sev: null } : { sev: v.battery < 20 ? "warn" : v.battery < 40 ? "caution" : "ok", val: v.battery + "%" },
      sensors: h.leak_detected === true ? { sev: "warn", val: "LEAK" } : { sev: "ok", val: "OK" },
      gps: v.lat != null && v.lng != null ? { sev: "ok", val: "3D" } : { sev: "caution", val: "NO FIX" },
      compass: v.heading != null ? { sev: "ok", val: pad3(v.heading) + "°" } : { sev: null },
      storage: num(h.disk_usage) == null ? { sev: null } : { sev: h.disk_usage > 90 ? "warn" : h.disk_usage > 75 ? "caution" : "ok", val: h.disk_usage + "%" },
      cpu: num(h.cpu_load) == null ? { sev: null } : { sev: h.cpu_load > 85 ? "warn" : h.cpu_load > 65 ? "caution" : "ok", val: h.cpu_load + "%" },
      network: comm === "connected" ? { sev: "ok", val: "CONN" } : comm === "partitioned" ? { sev: "caution", val: "PART" } : comm === "disconnected" ? { sev: "warn", val: "DISC" } : { sev: "idle", val: "UNK" },
    };
  }
  function overallSev(s) {
    let worst = null;
    Object.values(s).forEach((x) => { if (x.sev && x.sev !== "idle") { if (worst == null || SEV_ORDER[x.sev] > SEV_ORDER[worst]) worst = x.sev; } });
    return worst; // null → no signal
  }

  // ---- matrix ----
  function mcell(s) {
    if (!s || s.sev == null) return `<td class="cell"><span class="mcell na"><span class="mdot"></span><span class="mv">—</span></span></td>`;
    return `<td class="cell"><span class="mcell ${s.sev}"><span class="mdot"></span><span class="mv">${s.val}</span></span></td>`;
  }
  function renderMatrix() {
    const head = `<tr><th class="veh">Vehicle</th>${MXCOLS.map(([, l]) => `<th>${l}</th>`).join("")}</tr>`;
    const body = fleet.map((v) => {
      const s = subsys(v);
      return `<tr data-id="${v.id}" class="${v.id === selId ? "sel" : ""}">
        <td class="vcell"><span class="vc-in"><span class="statdot" style="background:var(--${cls(v) === "c" ? "connected" : cls(v) === "p" ? "partitioned" : cls(v) === "d" ? "disconnected" : "unknown"})"></span><b>${v.name || "USV-" + v.id}</b>${CommsPill(v)}</span></td>
        ${MXCOLS.map(([k]) => mcell(s[k])).join("")}
      </tr>`;
    }).join("");
    const mx = document.getElementById("mxwrap");
    mx.innerHTML = `<table class="mx"><thead>${head}</thead><tbody>${body}</tbody></table>`;
    mx.querySelectorAll("tbody tr").forEach((tr) => (tr.onclick = () => { selectVehicle(+tr.dataset.id); renderMatrix(); renderDetail(); }));
  }

  // ---- detail ----
  const bar = (pct, color) => `<span class="bar" style="width:64px;flex:none"><i style="width:${pct}%;background:${color}"></i></span>`;
  const row = (k, val, extra = "") => `<div class="mrow"><span class="k">${k}</span><span class="val ${extra}">${val}</span></div>`;
  const naRow = (k, reason = "no telem") => `<div class="mrow"><span class="k">${k}</span><span class="val na">${noTelem(reason)}</span></div>`;
  // Full-width, always-live named section (Vehicle Health / Power / Communication /
  // Local Agent / Sensors / System) — a free-text condition label, not a severity
  // derived one, so a section with no bad signal at all can still say "Nominal".
  function panelCard(title, condLabel, condClass, bodyHtml) {
    return `<div class="sub full"><div class="sub-head ${condClass}"><span class="hd"></span><span class="nm">${title}</span><span class="cond">${condLabel}</span></div>${bodyHtml}</div>`;
  }

  // RC retains hardware-level override regardless of software control authority
  // (SYSTEM_INFORMATION_MODEL.md / commands.md "Control authority") — a stated
  // architecture invariant, not a per-vehicle telemetry field. Rendered as a
  // constant "Always" rather than NO-TELEM so it never misreads as "unknown
  // whether the safety fallback works".
  const rcAlwaysCell = '<span class="txt-c" title="RC transmitter always retains hardware-level override, independent of software control authority">Always</span>';

  // ---- Control actions (authority hand-off + command queue, Scout-confirmed only) ----
  // Take Control → OPERATOR, Release Control → LOCAL_AGENT. The request goes PENDING
  // and is confirmed only when Scout's reported effective authority matches — the
  // controller (not this click) decides confirmed/rejected/timeout.
  async function authorityAction(target, vname) {
    if (target === "OPERATOR" &&
        !window.confirm(`Take control of ${vname}?\n\nThis requests OPERATOR authority so operator commands can execute. It does NOT arm the vehicle or change its mode.`)) return;
    const res = await authCtl.request(target, (a) => api.setControlAuthority(selId, a));
    if (res && !res.ok) window.alert((res.data && (res.data.message || res.data.error)) || "Authority change failed.");
    refreshCommands();
  }

  async function sendCommand(type, vname) {
    const label = (CMDS.find(([t]) => t === type) || [null, type])[1];
    const highRisk = HIGH_RISK.has(type);
    if (highRisk &&
        !window.confirm(`Confirm ${label} for ${vname}?\n\nThe command is queued for the vehicle to execute. It is NOT applied until the local agent reports back.`)) return;
    let res = await api.createCommand({ vehicle_id: selId, type, confirm: highRisk });
    if (!res.ok && res.data && res.data.needs_confirmation) {
      if (!window.confirm(`${res.data.message}\n\nQueue anyway?`)) return;
      res = await api.createCommand({ vehicle_id: selId, type, confirm: true });
    }
    if (!res.ok) window.alert((res.data && res.data.message) || "Command was not accepted.");
    refreshCommands();
  }

  // Pixhawk mission readback → { home, route, cur, counts }, or null when not fetched
  // yet / unavailable. Same classification + progress math as Map.js/Mission.js
  // (lib/mission.js) — this page never computes a second, different waypoint count.
  function missionStatsFor(v) {
    const s = pxm[v.id];
    if (!s || !s.mission) return null;
    const { home, route } = classifyMissionWaypoints(s.mission.waypoints || []);
    const cur = s.mission.current_seq;
    return { home, route, cur, counts: missionCounts(route, cur) };
  }

  function renderDetail() {
    const v = fleet.find((x) => x.id === selId);
    const box = document.getElementById("detail");
    if (!v) { box.innerHTML = `<div class="empty-state" style="padding:8px 0">No vehicle selected</div>`; return; }
    const vname = v.name || "USV-" + v.id;
    document.getElementById("dettag").textContent = `${vname} · live diagnostics`;
    const s = subsys(v), ov = overallSev(s), stale = commState(v) !== "connected";
    const h = v.health || {}, meas = v.measurements || {}, t = v.telemetry || {}, md = v.mission_data || {}, schema = (v.agent && v.agent.schema_version) || "—";
    const c = v.communication || {};

    // faults for the top-of-page glance
    const faults = MXCOLS.map(([k, l]) => ({ k, l, ...s[k] })).filter((x) => x.sev === "caution" || x.sev === "warn");
    const faultsHtml = faults.length
      ? faults.map((f) => `<div class="frow"><span class="fd" style="background:var(--${f.sev})"></span><span class="txt-${f.sev === "warn" ? "d" : "p"}">${f.l} — ${f.val}</span></div>`).join("")
      : `<div class="frow none">No active faults — all reporting subsystems nominal</div>`;

    // Control authority via the controller (pending → confirmed/rejected/timeout).
    // Write-enable + hand-off affordances both come from the one authored policy
    // (lib/authority.js handoffGate) — identical to Map's, never a second derivation.
    const av = authCtl.view();
    const authVal = stale ? null : av.value;
    const { canTake, canRelease, hasControl, busy } = handoffGate(av, { stale });
    const authoritySeg = AuthoritySeg(authVal, { phase: av.phase, pending: av.pending });
    const operatorReachable = c.operator_reachable;
    const operatorReachCell = operatorReachable != null ? (operatorReachable ? '<span class="txt-c">Yes</span>' : '<span class="txt-p">No</span>') : noTelem("no telem");
    const armed = t.armed;
    const armedCell = stale ? '<span class="txt-u">UNKNOWN</span>'
      : armed == null ? noTelem("no telem")
      : armed ? '<span class="txt-d">ARMED</span>' : '<span class="txt-c">DISARMED</span>';
    const modeCell = stale ? '<span class="txt-u">UNKNOWN</span>' : (t.mode || noTelem("no telem"));
    const mav = v.mavlink || {};
    const heartbeatCell = mav.heartbeat_age_s != null
      ? `<span class="txt-${mav.heartbeat_age_s <= 3 ? "c" : mav.heartbeat_age_s <= 10 ? "p" : "d"}">${mav.heartbeat_age_s.toFixed(1)}s ago</span>`
      : noTelem("no telem");
    const mavlinkCell = mav.connected === true ? `<span class="txt-c">Connected${mav.msg_rate_hz != null ? `, ${mav.msg_rate_hz} Hz` : ""}</span>`
      : mav.connected === false ? '<span class="txt-d">Disconnected</span>'
      : mav.last_msg_age_s != null ? `<span class="txt-${mav.last_msg_age_s <= 3 ? "c" : mav.last_msg_age_s <= 10 ? "p" : "d"}">Last msg ${mav.last_msg_age_s.toFixed(1)}s ago</span>`
      : noTelem("no telem");
    const rcActiveCell = stale || !av.reachable ? noTelem("no telem")
      : av.value === "RC" ? '<span class="txt-d">ACTIVE</span>' : '<span class="txt-c">Inactive</span>';

    // Operator Backend link — the SAME feed-health api.js tracks for the Ribbon's
    // Operator Link indicator (poll key "fleet", shared across pages), so this row and
    // the Ribbon can never disagree about whether the backend itself is reachable.
    const feedH = api.getFeedHealth("fleet");
    const feedAgeS = feedH && feedH.lastOkAt != null ? (Date.now() - feedH.lastOkAt) / 1000 : null;
    const operatorBackendCell = feedAgeS == null ? noTelem("connecting")
      : feedAgeS <= 4 ? '<span class="txt-c">Live</span>'
      : feedAgeS <= 12 ? `<span class="txt-p">Delayed ${Math.round(feedAgeS)}s</span>`
      : `<span class="txt-d">Unreachable ${Math.round(feedAgeS)}s</span>`;

    // Pixhawk mission readback (Vehicle Health's Home/Waypoint/Loaded rows) — never a
    // second computation from what Map.js/Mission.js already trust (lib/mission.js).
    const ms = missionStatsFor(v);
    const hs = homeStatus(v, {});
    // Command-gate context, built by the SAME shared builder Map uses (lib/home.js), so
    // both pages gate every button identically. The Vehicle page has no Set Home control,
    // so no Set Home request can be pending from here.
    const gateCtx = commandGateCtx(v, {
      hasControl,
      connected: !stale,
      missionLoaded: !!(ms && ms.counts.total > 0),
    });
    const homeCls = hs.state === "verified" ? "ok" : hs.state === "pending" ? "pending" : hs.state === "unknown" ? "dim" : "warn";
    const homeTxt = hs.state === "verified" ? "Verified" : hs.state === "pending" ? "Setting…" : hs.state === "unknown" ? "Unknown" : "Not verified";
    const curWpText = !ms ? noTelem("not fetched") : ms.cur == null ? "—" : (ms.home && ms.home.seq === ms.cur ? `Mission start (seq ${ms.cur})` : `WP ${ms.cur} / ${ms.route.length}`);
    const missionLoadedText = ms ? (ms.counts.total > 0 ? "Yes" : "No") : noTelem("not fetched");
    const pixhawkCell = mav.heartbeat_age_s != null
      ? (mav.heartbeat_age_s <= 3 ? '<span class="txt-c">Connected</span>' : mav.heartbeat_age_s <= 10 ? '<span class="txt-p">Degraded</span>' : '<span class="txt-d">No heartbeat</span>')
      : mav.connected === true ? '<span class="txt-c">Connected</span>' : mav.connected === false ? '<span class="txt-d">Disconnected</span>' : noTelem("no telem");

    // ---- section 1: Vehicle Health ----
    const healthSev = stale ? null : worstSev(hs.state === "verified" ? "ok" : "caution", s.gps.sev);
    const healthRows = `
        ${row("Pixhawk", pixhawkCell, "keep")}
        ${row("Heartbeat", heartbeatCell, "keep")}
        ${row("GPS", v.lat != null && v.lng != null ? '<span class="txt-c">3D fix</span>' : '<span class="txt-p">No fix</span>', "keep")}
        ${naRow("EKF")}
        ${row("RC override active", rcActiveCell, "keep")}
        ${row("Armed", armedCell, "keep")}
        ${row("Mode", modeCell, "keep")}
        ${row("Mission", md.mission_state || v.status || noTelem("no telem"), "keep")}
        ${row("Home verification", `<span class="pxm-chip ${homeCls}">${homeTxt}</span>`, "keep")}
        ${row("Current waypoint", curWpText, "keep")}
        ${row("Mission loaded", missionLoadedText, "keep")}`;

    // ---- section 2: Control (authority hand-off + command queue) ----
    const controlCond = busy ? "Requesting…"
      : hasControl ? "Operator engaged"
      : av.value === "LOCAL_AGENT" ? "Local Agent (autonomy)"
      : av.value === "RC" ? "RC override active"
      : "Unknown";
    const controlClass = hasControl ? "ok" : av.value === "LOCAL_AGENT" ? "idle" : busy ? "caution" : "warn";
    const authBadge = hasControl
      ? `<span class="auth-badge on"><i></i>OPERATOR ENGAGED</span>`
      : `<span class="auth-badge"><i></i>${busy ? "REQUESTING…" : av.value === "LOCAL_AGENT" ? "LOCAL AGENT" : av.value === "RC" ? "RC OVERRIDE" : "UNKNOWN"}</span>`;
    const p = av.pending;
    const authNote = busy
      ? `Requesting <b>${p && p.requested === "OPERATOR" ? "OPERATOR" : "LOCAL AGENT"}</b> authority for ${vname} — awaiting confirmation from the vehicle. Commands stay locked until confirmed.`
      : p && p.phase === "rejected"
        ? `Authority request rejected — ${p.reason || "not accepted"}.`
      : p && p.phase === "timeout"
        ? `Authority request timed out — ${p.reason || "no confirmation from the vehicle"}.`
      : hasControl
        ? `Operator commands are <b>enabled</b> for ${vname}. Releasing hands authority back to the Local Agent without changing the vehicle's mode.`
      : av.value === "LOCAL_AGENT"
        ? `The Local Agent holds control (autonomy). Press <b>Take Control</b> to request OPERATOR authority. This does not arm the vehicle or change its mode.`
      : av.value === "RC"
        ? `An RC transmitter override is active — it holds physical control. Take Control requests OPERATOR authority once RC releases.`
      : stale
        ? `Authority is <b>UNKNOWN</b> — telemetry is stale. Commands stay locked until the link is current.`
        : `Control authority is unknown — Scout's control-authority service did not respond. Commands stay locked until authority is confirmed.`;
    // Take Control must stay available whenever the operator does not already hold a
    // confirmed OPERATOR authority — LOCAL_AGENT included. Enablement is handoffGate's.
    const authBtn = hasControl
      ? `<button class="ctl-auth release" data-auth="LOCAL_AGENT"${canRelease ? "" : " disabled"}>Release Control</button>`
      : `<button class="ctl-auth engage" data-auth="OPERATOR"${canTake ? "" : " disabled"}>Take Control</button>`;
    // Button enablement + disabled reasons come from the SHARED policy (commandGate,
    // lib/home.js) on the SHARED context (commandGateCtx) — identical to Map's cmdRow,
    // never a second set of conditions authored here. Authority permits writes; each
    // command still answers to its own prerequisites (AUTO/RTL/RESUME need a verified
    // Home; LOITER/MANUAL never do). A Home-interlock disable explains itself on hover.
    const renderCmd = ([type, label]) => {
      const hr = HIGH_RISK.has(type);
      const safety = isSafetyHold(type);
      const g = commandGate(type, gateCtx);
      const homeLocked = !g.enabled && !!g.reason;   // disabled by the Home interlock, not the authority lock
      const title = g.reason || (safety ? SAFETY_HOLD_TITLE : `${type}${hr ? " · confirmation required" : ""}`);
      return `<button class="ctl-cmd${hr ? " hr" : ""}${safety ? " safety" : ""}${homeLocked ? " home-locked" : ""}" data-cmd="${type}"${g.enabled ? "" : " disabled"} title="${title.replace(/"/g, "&quot;")}">${label}</button>`;
    };
    const primaryBtns = PRIMARY_CMDS.map(renderCmd).join("");
    const advancedBtns = ADVANCED_CMDS.map(renderCmd).join("");
    const queueHtml = cmds.length
      ? cmds.slice(0, 8).map((cm) => {
          // An EXECUTED whose per-type verification failed (SET_HOME not read back, RTL
          // not actually entered) is shown as FAILED, never a green EXECUTED — the same
          // shared rule the Map panel uses (commandVerification, lib/command.js). The
          // real reason is already on cm.reason (set by the backend classifier) and
          // renders in the note below.
          const failedVerify = commandVerification(cm).verified === false;
          const clsx = failedVerify ? "d" : (CMD_STATUS_CLS[cm.status] || "u");
          const label = failedVerify ? "FAILED" : cm.status;
          const when = cm.completed_at || cm.claimed_at || cm.created_at;
          const note = cm.reason || cm.warning || "";
          return `<div class="ctl-row"><span class="ctl-type mono">${cm.type}</span><span class="pill ${clsx}">${label}</span><span class="ctl-when mono">${fmtClock(when)}</span>${note ? `<span class="ctl-note" title="${note.replace(/"/g, "&quot;")}">${note}</span>` : ""}</div>`;
        }).join("")
      : `<div class="ctl-empty">No commands issued for ${vname} yet.</div>`;
    const controlCard = panelCard("Control", controlCond, controlClass,
      `<div class="metrics">
        ${row("Authority", authoritySeg, "keep")}
        ${row("Operator connected", operatorReachCell, "keep")}
        ${row("RC override policy", rcAlwaysCell, "keep")}
      </div>
      <div style="padding:13px;display:flex;flex-direction:column;gap:12px;border-top:1px solid var(--line)">
        <div class="ctl-auth-bar${hasControl ? " engaged" : ""}">
          <div class="ctl-auth-l"><span class="lbl">Engage</span>${authBadge}</div>
          <div class="ctl-auth-note">${authNote}</div>
          ${authBtn}
        </div>
        <div class="ctl-cmds${hasControl ? "" : " locked"}">${primaryBtns}</div>
        ${hasControl ? "" : `<div class="ctl-lock-note">${lockSvg}<span>Commands are locked. Take Control (Scout-confirmed) to enable them.</span></div>`}
        <details class="ctl-advanced">
          <summary>Advanced modes</summary>
          <div class="ctl-cmds${hasControl ? "" : " locked"}">${advancedBtns}</div>
          <div class="ctl-advanced-note">HOLD is a <b>passive</b> hold — the USV may drift with wind or current. For an active anti-drift safety hold use <b>LOITER</b> above.</div>
        </details>
        <div class="ctl-queue">
          <div class="ctl-queue-h"><span class="lbl">Command queue &amp; history</span><span class="tag">status is reported by the vehicle — never assumed</span></div>
          ${queueHtml}
        </div>
      </div>`);

    // ---- section 3: Power ----
    const powerRows = `
        ${naRow("Battery voltage")}
        ${naRow("Battery current")}
        ${naRow("Power source")}
        ${row("Remaining %", BatteryBar(v.battery), "keep")}
        ${naRow("Failsafe status")}`;

    // ---- section 4: Communication ----
    const commRows = `
        ${naRow("WireGuard", "no VPN telemetry field")}
        ${row("Operator Backend", operatorBackendCell, "keep")}
        ${row("Local Agent", v.online ? '<span class="txt-c">Online</span>' : '<span class="txt-d">Offline</span>', "keep")}
        ${row("MAVLink", mavlinkCell, "keep")}
        ${row("Telemetry freshness", `<span class="txt-${cls(v)}">${fmtAge(v.last_seen_age_s)}</span> · ${commState(v).toUpperCase()}`, "keep")}
        ${naRow("Packet loss (future)")}
        ${naRow("RTT (future)")}`;

    // ---- section 5: Local Agent (payload.agent.* — forwarded verbatim, same field
    // precedence the Agent page uses, so the two pages never disagree) ----
    const a = v.agent_status || {};
    const clean = (val) => (val == null || val === "" ? null : String(val));
    const behaviour = clean(a.current_behaviour ?? a.behaviour ?? a.behavior);
    const decision = clean(a.current_decision) || behaviour;
    const policy = clean(a.current_policy ?? a.communication_policy);
    const reasonRaw = Array.isArray(a.decision_reasons) ? a.decision_reasons[0] : (a.decision_reasons ?? a.decision_reason);
    const reason = clean(reasonRaw);
    const agentLive = behaviour != null || decision != null || reason != null || policy != null;
    const agentRows = `
        ${row("Current behaviour", behaviour || noTelem("not emitted"), "keep")}
        ${row("Current decision", decision || noTelem("not emitted"), "keep")}
        ${row("Current policy", policy || noTelem("not emitted"), "keep")}
        ${row("Control authority", authoritySeg, "keep")}
        ${row("Decision reason", reason || noTelem("not emitted"), "keep")}`;

    // ---- section 6: Sensors ----
    const sensorRows = `
        ${row("GPS", v.lat != null ? `${(+v.lat).toFixed(5)}, ${(+v.lng).toFixed(5)}` : noTelem("no telem"), "keep")}
        ${naRow("GPS satellites")}
        ${row("Compass", v.heading != null ? pad3(v.heading) + "°" : noTelem("no telem"), "keep")}
        ${naRow("IMU")}
        ${naRow("Camera")}
        ${row("Sonar / bathymetry", meas.bathymetry ? '<span class="txt-c">Logging</span>' : noTelem("no telem"), "keep")}
        ${row("Leak sensor", h.leak_detected === true ? '<span class="txt-d">LEAK DETECTED</span>' : (h.leak_detected === false ? "No leak" : noTelem("no telem")), "keep")}`;

    // ---- section 7: System ----
    const sysRows = `
        ${h.cpu_load != null ? row("CPU", `${bar(h.cpu_load, h.cpu_load > 85 ? "var(--disconnected)" : h.cpu_load > 65 ? "var(--partitioned)" : "var(--connected)")}<span class="pcw">${h.cpu_load}%</span>`, "keep") : naRow("CPU")}
        ${h.ram_usage != null ? row("Memory", `${bar(h.ram_usage, h.ram_usage > 90 ? "var(--disconnected)" : h.ram_usage > 75 ? "var(--partitioned)" : "var(--connected)")}<span class="pcw">${h.ram_usage}%</span>`, "keep") : naRow("Memory")}
        ${naRow("Temperature")}
        ${h.disk_usage != null ? row("Disk usage", `${bar(h.disk_usage, "var(--connected)")}<span class="pcw">${h.disk_usage}%</span>`, "keep") : naRow("Disk usage")}
        ${row("Service status", h.flask_status ? "Flask " + h.flask_status : noTelem("no telem"), "keep")}
        ${row("Firmware", schema === "—" ? noTelem("no telem") : "v" + schema, "keep")}`;

    const powerSev = s.battery.sev;
    const commSev = worstSev(s.network.sev, feedAgeS != null && feedAgeS > 12 ? "warn" : null);
    const agentSev = !agentLive ? null : v.online ? "ok" : "warn";
    const sensorsSev = s.sensors.sev;
    const sysSev = worstSev(s.cpu.sev, s.storage.sev);

    const banner = stale
      ? `<div class="stale-note" style="margin:0 0 14px"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>Telemetry as of ${fmtAge(v.last_seen_age_s)} ago — not live. Sensors, GPS, compass, storage &amp; CPU are last-known; battery and link state remain current.</div>`
      : "";

    box.innerHTML = `
      <div class="dhead">
        <span class="dname">${vname}</span>
        ${CommsPill(v, { full: true })}
        <span class="ovr ${ov == null ? "ok" : ov}"><span class="hd"></span>${ov == null ? "No signal" : ov === "ok" ? "OK" : ov === "warn" ? "Warning" : "Caution"}</span>
        <span class="sp"></span>
        <span class="contact"><span class="lbl">Last contact</span><span class="big txt-${cls(v)}">${fmtAge(v.last_seen_age_s)}</span></span>
      </div>
      ${banner}
      <div class="faults" style="margin-bottom:14px;border:1px solid var(--line);border-radius:var(--r);background:var(--panel)">${faultsHtml}</div>
      ${panelCard("Vehicle Health", sevLabel(healthSev), sevClass(healthSev), `<div class="metrics${stale ? " stale" : ""}">${healthRows}</div>`)}
      ${controlCard}
      ${panelCard("Power", sevLabel(powerSev), sevClass(powerSev), `<div class="metrics">${powerRows}</div>`)}
      ${panelCard("Communication", sevLabel(commSev), sevClass(commSev), `<div class="metrics">${commRows}</div>`)}
      ${panelCard("Local Agent", sevLabel(agentSev), sevClass(agentSev), `<div class="metrics${stale ? " stale" : ""}">${agentRows}</div>`)}
      ${panelCard("Sensors", sevLabel(sensorsSev), sevClass(sensorsSev), `<div class="metrics${stale ? " stale" : ""}">${sensorRows}</div>`)}
      ${panelCard("System", sevLabel(sysSev), sevClass(sysSev), `<div class="metrics">${sysRows}</div>`)}`;

    const authBtnEl = box.querySelector(".ctl-auth");
    if (authBtnEl) authBtnEl.onclick = () => authorityAction(authBtnEl.dataset.auth, vname);
    box.querySelectorAll(".ctl-cmd").forEach((b) => (b.onclick = () => sendCommand(b.dataset.cmd, vname)));
  }

  function counts() {
    const c = { c: 0, p: 0, d: 0 };
    fleet.forEach((v) => { const st = commState(v); if (st === "connected") c.c++; else if (st === "partitioned") c.p++; else if (st === "disconnected") c.d++; });
    return c;
  }

  // Operator Link — shared with Map.js/Mission.js via the SAME api.js poll key
  // ("fleet"), so the Ribbon's backend-reachability indicator (and this page's own
  // "Operator Backend" row) read identically no matter which page is open.
  function updateFeedIndicator() {
    const h = api.getFeedHealth("fleet");
    if (!h || (h.lastOkAt == null && h.lastErrAt == null)) { updateRibbon({ feed: { cls: "dim", label: "CONNECTING…" } }); return; }
    if (h.lastOkAt == null) { updateRibbon({ feed: { cls: "bad", label: "BACKEND UNREACHABLE" } }); return; }
    const ageS = (Date.now() - h.lastOkAt) / 1000;
    if (ageS <= 4) updateRibbon({ feed: { cls: "ok", label: "LIVE" } });
    else if (ageS <= 12) updateRibbon({ feed: { cls: "warn", label: `DELAYED ${Math.round(ageS)}s` } });
    else updateRibbon({ feed: { cls: "bad", label: `UNREACHABLE ${Math.round(ageS)}s` } });
  }

  function onFleet(data) {
    fleet = Array.isArray(data) ? data : [];
    // Open on a vehicle that is actually reporting rather than a placeholder template row.
    if (selId == null && fleet.length) {
      selectVehicle((fleet.find((x) => x.online) || fleet.find((x) => x.lat != null) || fleet[0]).id);
    }
    document.getElementById("vcount").textContent = `${fleet.length} vehicles`;
    document.getElementById("veh-list").innerHTML = vehicleRows(fleet, selId);
    document.querySelectorAll("#veh-list .vrow").forEach((el) => (el.onclick = () => { selectVehicle(+el.dataset.id); onFleet(fleet); }));
    renderMatrix(); renderDetail();
    updateRibbon({ counts: counts() });
  }

  const stopFleet = api.poll(api.getFleet, 2000, onFleet, updateFeedIndicator, "fleet");
  const authorityId = setInterval(() => loadAuthority(selId), 2000);  // refresh selected vehicle's control authority
  const commandsId = setInterval(() => refreshCommands(), 3000);  // refresh selected vehicle's command queue
  const clockId = setInterval(() => { updateRibbon({ clock: new Date().toLocaleTimeString([], { hour12: false }) }); updateFeedIndicator(); }, 1000);
  updateRibbon({ clock: new Date().toLocaleTimeString([], { hour12: false }) });
  updateFeedIndicator();

  return function cleanup() { stopFleet(); clearInterval(clockId); clearInterval(authorityId); clearInterval(commandsId); authCtl.dispose(); };
}
