"""
Standalone tests for services/agent_state.py's telemetry construction --
specifically that telemetry.armed/telemetry.mode reflect real HEARTBEAT
data independently of GLOBAL_POSITION_INT/VFR_HUD availability, and that
armed is read from the safety-armed bit rather than inferred from mode.
No pytest dependency -- run directly:

    python3 test_agent_state.py
"""
import unittest
from datetime import datetime, timedelta, timezone

import services.agent_state as agent_state
import services.state as _state


def _iso(age_seconds=0.0):
    ts = datetime.now(timezone.utc) - timedelta(seconds=age_seconds)
    return ts.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z"


def _hb(custom_mode=0, armed=False, age_seconds=None):
    bits = 1 | (128 if armed else 0)  # bit0 CUSTOM_MODE_ENABLED + bit7 SAFETY_ARMED
    envelope = {"message": {"custom_mode": custom_mode, "base_mode": {"bits": bits}}}
    if age_seconds is not None:
        envelope["status"] = {"time": {"last_update": _iso(age_seconds)}}
    return envelope


def _pos(lat=56.5, lon=12.5):
    return {"message": {"lat": int(lat * 1e7), "lon": int(lon * 1e7)}}


def _hud(alt=1.0, heading=90, groundspeed=0.5):
    return {"message": {"alt": alt, "heading": heading, "groundspeed": groundspeed}}


def _bat(remaining=80):
    return {"message": {"battery_remaining": remaining}}


def _mav_get_factory(responses):
    """responses: dict of {path_suffix: value_or_None}; missing/None -> raises."""
    def _mav_get(path):
        for suffix, value in responses.items():
            if path.endswith(suffix):
                if value is None:
                    raise RuntimeError("no data")
                return value
        raise RuntimeError(f"unexpected path: {path}")
    return _mav_get


def _init(responses):
    agent_state.init(
        mav_get_fn=_mav_get_factory(responses),
        sensor_url="http://sensor.invalid",
        gpio_socket_path="/tmp/nonexistent.sock",
        app_state_getter=lambda: {
            "mission_active": False,
            "current_mission_id": None,
            "take_sensitive_measurements": False,
            "measurementDelay": 60,
        },
    )


class TestTelemetryArmedMode(unittest.TestCase):
    def setUp(self):
        _state.gps_log.clear()

    def test_armed_true_from_safety_armed_bit_not_mode(self):
        _init({
            "HEARTBEAT": _hb(custom_mode=0, armed=True),
            "GLOBAL_POSITION_INT": _pos(), "VFR_HUD": _hud(), "BATTERY_STATUS": _bat(),
        })
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertIs(telemetry["armed"], True)
        self.assertEqual(telemetry["mode"], 0)

    def test_disarmed_regardless_of_mode_value(self):
        _init({
            "HEARTBEAT": _hb(custom_mode=10, armed=False),
            "GLOBAL_POSITION_INT": _pos(), "VFR_HUD": _hud(), "BATTERY_STATUS": _bat(),
        })
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertIs(telemetry["armed"], False)
        self.assertEqual(telemetry["mode"], 10)

    def test_armed_and_mode_survive_missing_position(self):
        """
        A missing GLOBAL_POSITION_INT (e.g. no GPS fix yet) must not blank
        out armed/mode -- they come from HEARTBEAT, a separate message.
        """
        _init({
            "HEARTBEAT": _hb(custom_mode=3, armed=True),
            "GLOBAL_POSITION_INT": None, "VFR_HUD": _hud(), "BATTERY_STATUS": _bat(),
        })
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertIs(telemetry["armed"], True)
        self.assertEqual(telemetry["mode"], 3)
        self.assertIsNone(telemetry["lat"])
        self.assertIsNone(telemetry["lng"])
        self.assertNotIn("error", telemetry)

    def test_armed_and_mode_survive_missing_hud(self):
        _init({
            "HEARTBEAT": _hb(custom_mode=3, armed=True),
            "GLOBAL_POSITION_INT": _pos(), "VFR_HUD": None, "BATTERY_STATUS": _bat(),
        })
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertIs(telemetry["armed"], True)
        self.assertIsNone(telemetry["alt"])
        self.assertIsNone(telemetry["heading"])
        self.assertIsNone(telemetry["groundspeed"])

    def test_armed_and_mode_none_when_heartbeat_missing(self):
        _init({
            "HEARTBEAT": None,
            "GLOBAL_POSITION_INT": _pos(), "VFR_HUD": _hud(), "BATTERY_STATUS": _bat(),
        })
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertIsNone(telemetry["armed"])
        self.assertIsNone(telemetry["mode"])
        self.assertIsNotNone(telemetry["lat"])  # unaffected by missing HEARTBEAT

    def test_gps_log_not_appended_when_position_missing(self):
        _init({
            "HEARTBEAT": _hb(), "GLOBAL_POSITION_INT": None,
            "VFR_HUD": _hud(), "BATTERY_STATUS": _bat(),
        })
        agent_state.build_agent_state()
        self.assertEqual(len(_state.gps_log), 0)

    def test_gps_log_appended_when_position_available(self):
        _init({
            "HEARTBEAT": _hb(), "GLOBAL_POSITION_INT": _pos(),
            "VFR_HUD": _hud(), "BATTERY_STATUS": _bat(),
        })
        agent_state.build_agent_state()
        self.assertEqual(len(_state.gps_log), 1)


class TestTelemetryExpandedFields(unittest.TestCase):
    def setUp(self):
        _state.gps_log.clear()

    def test_mode_name_decodes_known_ardurover_mode(self):
        _init({"HEARTBEAT": _hb(custom_mode=10), "GLOBAL_POSITION_INT": _pos(),
               "VFR_HUD": _hud(), "BATTERY_STATUS": _bat()})
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertEqual(telemetry["mode"], 10)
        self.assertEqual(telemetry["mode_name"], "AUTO")

    def test_mode_name_unknown_value_labeled_not_guessed(self):
        _init({"HEARTBEAT": _hb(custom_mode=99), "GLOBAL_POSITION_INT": _pos(),
               "VFR_HUD": _hud(), "BATTERY_STATUS": _bat()})
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertEqual(telemetry["mode_name"], "MODE_99")

    def test_mode_name_none_when_heartbeat_missing(self):
        _init({"HEARTBEAT": None, "GLOBAL_POSITION_INT": _pos(),
               "VFR_HUD": _hud(), "BATTERY_STATUS": _bat()})
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertIsNone(telemetry["mode_name"])

    def test_battery_voltage_and_current_from_battery_status(self):
        bat = {"message": {"battery_remaining": 80, "voltages": [12200, 65535, 65535],
                            "current_battery": 350}}
        _init({"HEARTBEAT": _hb(), "GLOBAL_POSITION_INT": _pos(),
               "VFR_HUD": _hud(), "BATTERY_STATUS": bat})
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertEqual(telemetry["battery_voltage"], 12.2)
        self.assertEqual(telemetry["battery_current"], 3.5)

    def test_battery_current_none_when_not_measured(self):
        bat = {"message": {"battery_remaining": 80, "voltages": [12200], "current_battery": -1}}
        _init({"HEARTBEAT": _hb(), "GLOBAL_POSITION_INT": _pos(),
               "VFR_HUD": _hud(), "BATTERY_STATUS": bat})
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertIsNone(telemetry["battery_current"])

    def test_gps_fix_type_and_satellites(self):
        gps_raw = {"message": {"fix_type": {"type": "GPS_FIX_TYPE_3D_FIX"}, "satellites_visible": 16}}
        _init({"HEARTBEAT": _hb(), "GLOBAL_POSITION_INT": _pos(), "VFR_HUD": _hud(),
               "BATTERY_STATUS": _bat(), "GPS_RAW_INT": gps_raw})
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertEqual(telemetry["gps_fix_type"], 3)
        self.assertEqual(telemetry["gps_satellites"], 16)

    def test_gps_satellites_none_when_unknown_sentinel(self):
        gps_raw = {"message": {"fix_type": {"type": "GPS_FIX_TYPE_NO_FIX"}, "satellites_visible": 255}}
        _init({"HEARTBEAT": _hb(), "GLOBAL_POSITION_INT": _pos(), "VFR_HUD": _hud(),
               "BATTERY_STATUS": _bat(), "GPS_RAW_INT": gps_raw})
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertIsNone(telemetry["gps_satellites"])

    def test_ekf_ok_none_when_not_available(self):
        _init({"HEARTBEAT": _hb(), "GLOBAL_POSITION_INT": _pos(),
               "VFR_HUD": _hud(), "BATTERY_STATUS": _bat()})
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertIsNone(telemetry["ekf_ok"])

    def test_ekf_ok_true_when_healthy_flags_set(self):
        ekf = {"message": {"flags": {"bits": 1 | 2 | 16 | 32}}}
        _init({"HEARTBEAT": _hb(), "GLOBAL_POSITION_INT": _pos(), "VFR_HUD": _hud(),
               "BATTERY_STATUS": _bat(), "EKF_STATUS_REPORT": ekf})
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertIs(telemetry["ekf_ok"], True)

    def test_ekf_ok_false_in_const_pos_mode(self):
        ekf = {"message": {"flags": {"bits": 1 | 2 | 16 | 32 | 128}}}
        _init({"HEARTBEAT": _hb(), "GLOBAL_POSITION_INT": _pos(), "VFR_HUD": _hud(),
               "BATTERY_STATUS": _bat(), "EKF_STATUS_REPORT": ekf})
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertIs(telemetry["ekf_ok"], False)

    def test_airspeed_always_none_no_sensor_on_surface_vehicle(self):
        _init({"HEARTBEAT": _hb(), "GLOBAL_POSITION_INT": _pos(),
               "VFR_HUD": _hud(), "BATTERY_STATUS": _bat()})
        telemetry = agent_state.build_agent_state()["telemetry"]
        self.assertIsNone(telemetry["airspeed"])


class TestMavlinkHealthBlock(unittest.TestCase):
    def setUp(self):
        _state.gps_log.clear()
        import services.mavlink_health as mavlink_health
        mavlink_health._HEARTBEAT_ARRIVALS.clear()
        mavlink_health._last_heartbeat_token = None

    def test_heartbeat_age_reported_when_timestamped(self):
        _init({"HEARTBEAT": _hb(age_seconds=0.5), "GLOBAL_POSITION_INT": _pos(),
               "VFR_HUD": _hud(), "BATTERY_STATUS": _bat()})
        mavlink = agent_state.build_agent_state()["mavlink"]
        self.assertAlmostEqual(mavlink["heartbeat_age_s"], 0.5, delta=0.2)
        self.assertTrue(mavlink["mavlink_connected"])

    def test_mavlink_connected_false_when_heartbeat_stale(self):
        _init({"HEARTBEAT": _hb(age_seconds=10), "GLOBAL_POSITION_INT": _pos(),
               "VFR_HUD": _hud(), "BATTERY_STATUS": _bat()})
        mavlink = agent_state.build_agent_state()["mavlink"]
        self.assertIs(mavlink["mavlink_connected"], False)

    def test_mavlink_connected_unknown_when_no_heartbeat(self):
        _init({"HEARTBEAT": None, "GLOBAL_POSITION_INT": _pos(),
               "VFR_HUD": _hud(), "BATTERY_STATUS": _bat()})
        mavlink = agent_state.build_agent_state()["mavlink"]
        self.assertIsNone(mavlink["mavlink_connected"])
        self.assertIsNone(mavlink["heartbeat_age_s"])

    def test_parser_errors_always_null_not_fabricated(self):
        _init({"HEARTBEAT": _hb(), "GLOBAL_POSITION_INT": _pos(),
               "VFR_HUD": _hud(), "BATTERY_STATUS": _bat()})
        mavlink = agent_state.build_agent_state()["mavlink"]
        self.assertIsNone(mavlink["parser_errors"])

    def test_rate_none_until_second_distinct_heartbeat_observed(self):
        _init({"HEARTBEAT": _hb(age_seconds=0.1), "GLOBAL_POSITION_INT": _pos(),
               "VFR_HUD": _hud(), "BATTERY_STATUS": _bat()})
        mavlink = agent_state.build_agent_state()["mavlink"]
        self.assertIsNone(mavlink["mavlink_msg_rate_hz"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
