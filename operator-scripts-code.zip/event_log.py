import time
import datetime

_events: list = []
_MAX_EVENTS = 100


def add_event(event_type: str, detail: dict | None = None) -> None:
    entry = {
        'time': round(time.time(), 2),
        'time_str': datetime.datetime.now().strftime('%H:%M:%S'),
        'type': event_type,
    }
    if detail:
        entry['detail'] = detail
    _events.append(entry)
    if len(_events) > _MAX_EVENTS:
        del _events[:len(_events) - _MAX_EVENTS]


def get_recent(n: int = 20) -> list:
    return list(_events[-n:])
