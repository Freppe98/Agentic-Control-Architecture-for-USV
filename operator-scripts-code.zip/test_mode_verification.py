"""
Standalone tests for services/mode_verification.py. No pytest dependency --
run directly:

    python3 test_mode_verification.py

Fakes mav_get/mav_post with a small stateful "fake vehicle" (same convention
as test_set_home_service.py's FakeVehicle): HEARTBEAT is modelled as a
continuous stream (mav_get returns whatever custom_mode the fake vehicle
currently reports, with a fresh status.time.last_update token every call --
mavlink2rest never expires a cached message, so a real caller reads
"whatever's cached", exactly like GLOBAL_POSITION_INT elsewhere in this
codebase) and COMMAND_ACK is a single-slot cache that only resolves after a
matching COMMAND_LONG has been posted, same single-slot hazard set_home_
service.py's own COMMAND_ACK handling guards against. No live mavlink2rest
or Pixhawk required.

All tests use small explicit ack_timeout_s/verify_timeout_s/stable_window_s/
poll_interval_s arguments (real wall-clock, just tiny) rather than mocking
time.time() -- fast enough to run in well under a second per test while
still exercising the real bounded-retry code path.
"""
import time
import unittest
from datetime import datetime, timedelta, timezone

import services.mode_verification as mode_verification


class FakeVehicle:
    def __init__(self, mode_sequence=None, ack_result="MAV_RESULT_ACCEPTED",
                 ack_never_arrives=False, ack_wrong_command=False):
        # If mode_sequence is given, each HEARTBEAT read pops the next value
        # (holding the last value once exhausted) -- lets a test script an
        # exact reached-then-reverted trace. If None, posting
        # MAV_CMD_DO_SET_MODE instantly flips custom_mode to the requested
        # param2 and it holds forever (the "clean success" default).
        self.custom_mode = 0
        self.mode_sequence = list(mode_sequence) if mode_sequence is not None else None
        self.ack_result = ack_result
        self.ack_never_arrives = ack_never_arrives
        self.ack_wrong_command = ack_wrong_command

        self.post_log = []
        self._token_n = 0
        self._ack_cached = None
        self._ack_cached_token = None
        self._ack_pending = None

    def _new_token(self):
        self._token_n += 1
        return (datetime.now(timezone.utc) + timedelta(microseconds=self._token_n)).isoformat()

    def mav_post(self, data):
        self.post_log.append(data)
        if data.get("type") != "COMMAND_LONG":
            return
        command = (data.get("command") or {}).get("type")
        if command == "MAV_CMD_DO_SET_MODE":
            if not self.ack_never_arrives:
                acked_command = "MAV_CMD_COMPONENT_ARM_DISARM" if self.ack_wrong_command else "MAV_CMD_DO_SET_MODE"
                self._ack_pending = (self._new_token(), acked_command, self.ack_result)
            if self.mode_sequence is None:
                self.custom_mode = data["param2"]

    def _resolve_ack(self):
        if self._ack_pending:
            token, command, result = self._ack_pending
            self._ack_cached = {"command": {"type": command}, "result": {"type": result}}
            self._ack_cached_token = token
            self._ack_pending = None

    def mav_get(self, path):
        if path.endswith("HEARTBEAT"):
            if self.mode_sequence is not None and self.mode_sequence:
                self.custom_mode = self.mode_sequence.pop(0)
            return {
                "message": {"custom_mode": self.custom_mode},
                "status": {"time": {"last_update": self._new_token()}},
            }
        if path.endswith("COMMAND_ACK"):
            self._resolve_ack()
            if self._ack_cached is None:
                raise RuntimeError("no data")
            return {"message": dict(self._ack_cached), "status": {"time": {"last_update": self._ack_cached_token}}}
        raise RuntimeError(f"unexpected path: {path}")


def _init(vehicle):
    mode_verification.init(mav_get_fn=vehicle.mav_get, mav_post_fn=vehicle.mav_post)


# Small, fast bounds shared by every test below -- real wall-clock but tiny.
_FAST = dict(ack_timeout_s=0.05, verify_timeout_s=0.2, stable_window_s=0.1, poll_interval_s=0.01)


class TestSetModeParams(unittest.TestCase):
    """Root-cause regression coverage: /nav/rtl previously sent
    MAV_CMD_DO_SET_MODE with param1/param2 swapped (param1=11, param2=0,
    which actually commands MANUAL, not RTL). Every mode change through this
    module must send the correct base_mode/custom_mode in the correct slots
    -- the same param1=209 every other /nav/* mode route already uses."""

    def test_rtl_sends_correct_base_mode_and_custom_mode(self):
        vehicle = FakeVehicle()
        _init(vehicle)
        mode_verification.set_mode_and_verify("RTL", 11, **_FAST)

        set_mode_posts = [p for p in vehicle.post_log if p.get("command", {}).get("type") == "MAV_CMD_DO_SET_MODE"]
        self.assertEqual(len(set_mode_posts), 1)
        post = set_mode_posts[0]
        self.assertEqual(post["param1"], 209, "base_mode must be 209, not the ArduRover custom_mode value")
        self.assertEqual(post["param2"], 11, "custom_mode must be RTL's 11, not 0")
        self.assertEqual(post["target_system"], 1)
        self.assertEqual(post["target_component"], 1)

    def test_loiter_sends_correct_base_mode_and_custom_mode(self):
        vehicle = FakeVehicle()
        _init(vehicle)
        mode_verification.set_mode_and_verify("LOITER", 5, **_FAST)

        post = next(p for p in vehicle.post_log if p.get("command", {}).get("type") == "MAV_CMD_DO_SET_MODE")
        self.assertEqual(post["param1"], 209)
        self.assertEqual(post["param2"], 5)


class TestArduRoverCustomModesTable(unittest.TestCase):
    """The one name<->int table every mode-changing route (AUTO, MANUAL,
    HOLD, LOITER, RTL -- and MISSION_PAUSE/MISSION_RESUME, implemented as
    HOLD/AUTO) and agent_state.py's telemetry.mode_name share -- not a
    second copy maintained independently."""

    def test_all_five_command_registry_modes_present(self):
        self.assertEqual(mode_verification.ARDUROVER_CUSTOM_MODES["MANUAL"], 0)
        self.assertEqual(mode_verification.ARDUROVER_CUSTOM_MODES["HOLD"], 4)
        self.assertEqual(mode_verification.ARDUROVER_CUSTOM_MODES["LOITER"], 5)
        self.assertEqual(mode_verification.ARDUROVER_CUSTOM_MODES["AUTO"], 10)
        self.assertEqual(mode_verification.ARDUROVER_CUSTOM_MODES["RTL"], 11)

    def test_reverse_table_is_the_exact_inverse(self):
        for name, mode in mode_verification.ARDUROVER_CUSTOM_MODES.items():
            self.assertEqual(mode_verification.ARDUROVER_MODE_NAMES[mode], name)

    def test_agent_state_reuses_the_same_table_not_a_copy(self):
        """Regression guard for the dedup: agent_state.py must import
        ARDUROVER_MODE_NAMES from mode_verification, not keep its own
        _ROVER_MODE_NAMES dict that could silently drift out of sync."""
        import services.agent_state as agent_state
        self.assertIs(agent_state.ARDUROVER_MODE_NAMES, mode_verification.ARDUROVER_MODE_NAMES)
        self.assertFalse(hasattr(agent_state, "_ROVER_MODE_NAMES"))


class TestModeNameResolution(unittest.TestCase):
    """Callers should normally pass just a mode name -- custom_mode is
    resolved from ARDUROVER_CUSTOM_MODES, not repeated as a magic number at
    every call site (the same 11/5/... previously duplicated across four
    separate /nav/* routes in app.py)."""

    def test_custom_mode_resolved_from_name_when_omitted(self):
        vehicle = FakeVehicle()
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("HOLD", **_FAST)

        self.assertEqual(result["requested_custom_mode"], 4)
        post = next(p for p in vehicle.post_log if p.get("command", {}).get("type") == "MAV_CMD_DO_SET_MODE")
        self.assertEqual(post["param2"], 4)

    def test_name_resolution_is_case_insensitive(self):
        vehicle = FakeVehicle()
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("auto", **_FAST)
        self.assertEqual(result["requested_custom_mode"], 10)

    def test_explicit_custom_mode_overrides_table_lookup(self):
        """Escape hatch for a mode not yet in the table, or a test double --
        an explicit custom_mode is never overridden by the name lookup."""
        vehicle = FakeVehicle()
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("GUIDED", 15, **_FAST)
        self.assertEqual(result["requested_custom_mode"], 15)


class TestMultiVehicleParameterization(unittest.TestCase):
    """target_system/target_component are per-call parameters, not module-
    level constants baked into a fixed mavlink2rest path at import time --
    future-proofing for a deployment addressing more than one vehicle
    through the same mavlink2rest, or a non-default SYSID_THISMAV."""

    def test_defaults_to_vehicle_one_component_one(self):
        vehicle = FakeVehicle()
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("HOLD", **_FAST)

        self.assertEqual(result["target_system"], mode_verification.DEFAULT_TARGET_SYSTEM)
        self.assertEqual(result["target_component"], mode_verification.DEFAULT_TARGET_COMPONENT)

    def test_custom_target_system_and_component_used_end_to_end(self):
        paths_requested = []
        vehicle = FakeVehicle()
        _init(vehicle)
        real_get = vehicle.mav_get

        def tracking_get(path):
            paths_requested.append(path)
            return real_get(path)

        vehicle.mav_get = tracking_get
        mode_verification.init(mav_get_fn=vehicle.mav_get, mav_post_fn=vehicle.mav_post)

        result = mode_verification.set_mode_and_verify(
            "HOLD", target_system=7, target_component=3, **_FAST,
        )

        self.assertEqual(result["target_system"], 7)
        self.assertEqual(result["target_component"], 3)
        post = next(p for p in vehicle.post_log if p.get("command", {}).get("type") == "MAV_CMD_DO_SET_MODE")
        self.assertEqual(post["target_system"], 7)
        self.assertEqual(post["target_component"], 3)
        self.assertTrue(any("/vehicles/7/components/3/" in p for p in paths_requested))


class TestRtlVerification(unittest.TestCase):
    def test_mode_changes_and_holds_is_verified_success(self):
        """Mode changes to RTL and remains there -> success."""
        vehicle = FakeVehicle(mode_sequence=[0, 11])  # previous=0, then reaches 11 and holds
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("RTL", 11, **_FAST)

        self.assertEqual(result["previous_mode"], 0)
        self.assertEqual(result["requested_mode"], "RTL")
        self.assertEqual(result["requested_custom_mode"], 11)
        self.assertTrue(result["accepted"])
        self.assertTrue(result["verified"])
        self.assertEqual(result["observed_mode"], 11)
        self.assertIsNone(result["reason"])
        self.assertEqual(result["target_system"], 1)
        self.assertEqual(result["target_component"], 1)
        self.assertEqual(result["ack_result"], "MAV_RESULT_ACCEPTED")

    def test_request_accepted_but_mode_remains_manual_is_failure(self):
        """Request sent but HEARTBEAT.custom_mode never changes -> failure,
        not success -- a request being sent is not proof it happened."""
        vehicle = FakeVehicle(mode_sequence=[0])  # stays at 0 forever (never posts a change)
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("RTL", 11, **_FAST)

        self.assertFalse(result["accepted"])
        self.assertFalse(result["verified"])
        self.assertEqual(result["observed_mode"], 0)
        self.assertIn("never reported custom_mode=11", result["reason"])

    def test_briefly_enters_rtl_then_reverts_is_failure(self):
        """Mode briefly becomes RTL and reverts -> failure, not success."""
        vehicle = FakeVehicle(mode_sequence=[0, 11, 0])  # previous=0, reaches 11, then reverts to 0
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("RTL", 11, **_FAST)

        self.assertTrue(result["accepted"], "the Pixhawk did briefly enter the requested mode")
        self.assertFalse(result["verified"], "a transient blip must never be reported as verified success")
        self.assertEqual(result["observed_mode"], 0)
        self.assertIn("reverted", result["reason"])

    def test_mavlink_rejection_surfaces_ack_reason_and_is_failure(self):
        """ArduPilot rejecting MAV_CMD_DO_SET_MODE (ack_result != ACCEPTED)
        combined with the mode never actually changing -> failure, with the
        ACK's real rejection result surfaced in ack_result."""
        vehicle = FakeVehicle(mode_sequence=[0], ack_result="MAV_RESULT_DENIED")
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("RTL", 11, **_FAST)

        self.assertFalse(result["accepted"])
        self.assertFalse(result["verified"])
        self.assertEqual(result["ack_result"], "MAV_RESULT_DENIED")

    def test_timeout_with_no_ack_at_all_is_terminal_failure(self):
        """Firmware that never ACKs DO_SET_MODE at all must not block
        forever or be treated as a hard error -- ack_result comes back None
        and the HEARTBEAT readback (which also never reaches the requested
        mode here) is what actually determines failure."""
        vehicle = FakeVehicle(mode_sequence=[0], ack_never_arrives=True)
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("RTL", 11, **_FAST)

        self.assertIsNone(result["ack_result"])
        self.assertFalse(result["accepted"])
        self.assertFalse(result["verified"])

    def test_target_system_and_component_always_surfaced(self):
        """Wrong/unexpected target_system or target_component would show up
        here -- this module hardcodes system=1/component=1 (the one vehicle
        this codebase talks to, same constant set_home_service.py uses), and
        every result surfaces it explicitly rather than leaving the caller
        to assume it."""
        vehicle = FakeVehicle(mode_sequence=[0, 11])
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("RTL", 11, **_FAST)

        self.assertEqual(result["target_system"], mode_verification.DEFAULT_TARGET_SYSTEM)
        self.assertEqual(result["target_component"], mode_verification.DEFAULT_TARGET_COMPONENT)
        self.assertEqual((result["target_system"], result["target_component"]), (1, 1))

    def test_samples_captures_heartbeat_trace(self):
        """samples is the raw HEARTBEAT.custom_mode sequence observed during
        verification -- needed to diagnose exactly what the Pixhawk did
        (e.g. a live investigation of one real RTL request)."""
        vehicle = FakeVehicle(mode_sequence=[0, 11, 0])
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("RTL", 11, **_FAST)

        self.assertIn(11, result["samples"])
        self.assertIn(0, result["samples"])

    def test_reason_is_none_only_on_full_success(self):
        vehicle = FakeVehicle(mode_sequence=[0])
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("RTL", 11, **_FAST)
        self.assertIsNotNone(result["reason"])


class TestLoiterVerification(unittest.TestCase):
    """LOITER runs through the exact same set_mode_and_verify() function as
    RTL -- no parallel verification path -- just with the shorter bounds
    app.py's /nav/loiter route configures (see TestSetModeParams above for
    the params-sent proof)."""

    def test_loiter_reaches_and_holds_is_verified_success(self):
        vehicle = FakeVehicle(mode_sequence=[0, 5])
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("LOITER", 5, **_FAST)

        self.assertTrue(result["accepted"])
        self.assertTrue(result["verified"])
        self.assertEqual(result["observed_mode"], 5)

    def test_loiter_never_reached_is_failure(self):
        vehicle = FakeVehicle(mode_sequence=[0])
        _init(vehicle)
        result = mode_verification.set_mode_and_verify("LOITER", 5, **_FAST)

        self.assertFalse(result["accepted"])
        self.assertFalse(result["verified"])


if __name__ == "__main__":
    unittest.main()
