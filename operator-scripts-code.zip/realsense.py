"""
Intel RealSense Camera Service
Serves RGB and Depth streams as HTTP MJPEG on separate ports
Binds to localhost only (127.0.0.1) for security - not accessible from outside
"""
import pyrealsense2 as rs
import numpy as np
import cv2
import threading
import time
from flask import Flask, Response
import atexit
import logging

# Configuration
# NOTE: temporary A/B bitrate-reduction test for latency investigation.
# DEPTH_FPS dropped 30 -> 6 (valid RealSense mode at this resolution) to cut
# egress bandwidth; revert to 30 once the WAN-bufferbloat theory is confirmed
# or ruled out.
COLOR_WIDTH, COLOR_HEIGHT, COLOR_FPS = 640, 480, 30
DEPTH_WIDTH, DEPTH_HEIGHT, DEPTH_FPS = 640, 480, 6
RGB_PORT = 5001
DEPTH_PORT = 5002

# Global state
pipeline = None
latest_color_frame = None
latest_depth_frame = None
frame_lock = threading.Lock()
stop_event = threading.Event()


def init_realsense():
    """Initialize RealSense pipeline with color and depth streams."""
    global pipeline
    if pipeline is not None:
        return pipeline

    pipeline = rs.pipeline()
    config = rs.config()
    config.enable_stream(rs.stream.color, COLOR_WIDTH, COLOR_HEIGHT, rs.format.bgr8, COLOR_FPS)
    config.enable_stream(rs.stream.depth, DEPTH_WIDTH, DEPTH_HEIGHT, rs.format.z16, DEPTH_FPS)
    profile = pipeline.start(config)

    # Cap each sensor's internal SDK frame queue to the newest frame only.
    # Otherwise, if our encode loop ever falls a beat behind the camera's
    # output rate, librealsense buffers frames FIFO and the backlog never
    # catches up, producing an ever-growing multi-second lag.
    try:
        for sensor in profile.get_device().query_sensors():
            if sensor.supports(rs.option.frames_queue_size):
                sensor.set_option(rs.option.frames_queue_size, 1)
    except Exception as e:
        print(f"Warning: could not set frames_queue_size: {e}")

    print(f"RealSense camera initialized at {COLOR_WIDTH}x{COLOR_HEIGHT} {COLOR_FPS}fps and {DEPTH_WIDTH}x{DEPTH_HEIGHT} {DEPTH_FPS}fps")
    return pipeline


def release_realsense():
    """Release RealSense pipeline."""
    global pipeline
    if pipeline is not None:
        try:
            pipeline.stop()
        except:
            pass
        pipeline = None
        print("RealSense camera released")


def capture_frames():
    """Background thread to continuously capture frames from RealSense."""
    global latest_color_frame, latest_depth_frame
    
    init_realsense()
    
    while not stop_event.is_set():
        try:
            frames = pipeline.wait_for_frames()

            # Drop any additional frames already queued behind this one so we
            # always process the most recent frameset, never a stale backlog.
            while True:
                newer_frames = pipeline.poll_for_frames()
                if not newer_frames:
                    break
                frames = newer_frames

            # Get color frame
            color_frame = frames.get_color_frame()
            if color_frame:
                color_image = np.asanyarray(color_frame.get_data())
                ret, buffer = cv2.imencode('.jpg', color_image, [cv2.IMWRITE_JPEG_QUALITY, 60])
                if ret:
                    with frame_lock:
                        latest_color_frame = buffer.tobytes()
            
            # Get depth frame and apply colormap
            depth_frame = frames.get_depth_frame()
            if depth_frame:
                depth_image = np.asanyarray(depth_frame.get_data())
                # Apply colormap for visualization
                depth_colormap = cv2.applyColorMap(
                    cv2.convertScaleAbs(depth_image, alpha=0.03), 
                    cv2.COLORMAP_JET
                )
                ret, buffer = cv2.imencode('.jpg', depth_colormap, [cv2.IMWRITE_JPEG_QUALITY, 40])
                if ret:
                    with frame_lock:
                        latest_depth_frame = buffer.tobytes()
                        
        except Exception as e:
            print(f"Frame capture error: {e}")
            release_realsense()
            time.sleep(2)
            try:
                init_realsense()
            except:
                pass


def generate_color_frames():
    """Generator for RGB MJPEG stream."""
    while not stop_event.is_set():
        with frame_lock:
            frame = latest_color_frame
        
        if frame is None:
            time.sleep(0.01)
            continue
            
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        time.sleep(1 / COLOR_FPS)


def generate_depth_frames():
    """Generator for Depth MJPEG stream."""
    while not stop_event.is_set():
        with frame_lock:
            frame = latest_depth_frame
        
        if frame is None:
            time.sleep(0.01)
            continue
            
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        time.sleep(1 / DEPTH_FPS)


def create_rgb_app():
    """Create Flask app for RGB stream."""
    app = Flask(__name__)
    
    @app.after_request
    def add_headers(response):
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        return response
    
    @app.route('/')
    def index():
        return '''
        <!DOCTYPE html>
        <html>
        <head><title>RealSense RGB Stream</title></head>
        <body style="background:#1a1a1a;color:#fff;text-align:center;font-family:sans-serif;">
            <h1>RealSense RGB Stream</h1>
            <img src="/video_feed" style="max-width:100%;border:2px solid #333;border-radius:8px;">
            <p>Port: 5001 | Resolution: 640x480 @ 30fps</p>
        </body>
        </html>
        '''
    
    @app.route('/video_feed')
    def video_feed():
        return Response(
            generate_color_frames(),
            mimetype='multipart/x-mixed-replace; boundary=frame'
        )
    
    @app.route('/health')
    def health():
        return {'status': 'healthy', 'stream': 'rgb', 'port': RGB_PORT}
    
    return app


def create_depth_app():
    """Create Flask app for Depth stream."""
    app = Flask(__name__)
    
    @app.after_request
    def add_headers(response):
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        return response
    
    @app.route('/')
    def index():
        return '''
        <!DOCTYPE html>
        <html>
        <head><title>RealSense Depth Stream</title></head>
        <body style="background:#1a1a1a;color:#fff;text-align:center;font-family:sans-serif;">
            <h1>RealSense Depth Stream</h1>
            <img src="/video_feed" style="max-width:100%;border:2px solid #333;border-radius:8px;">
            <p>Port: 5002 | Resolution: 640x480 @ 30fps | Colormap: JET</p>
        </body>
        </html>
        '''
    
    @app.route('/video_feed')
    def video_feed():
        return Response(
            generate_depth_frames(),
            mimetype='multipart/x-mixed-replace; boundary=frame'
        )
    
    @app.route('/health')
    def health():
        return {'status': 'healthy', 'stream': 'depth', 'port': DEPTH_PORT}
    
    return app


def run_rgb_server():
    """Run RGB stream server."""
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.ERROR)
    app = create_rgb_app()
    print(f"Starting RGB stream server on 0.0.0.0:{RGB_PORT}")
    app.run(host='0.0.0.0', port=RGB_PORT, threaded=True, use_reloader=False, debug=False)


def run_depth_server():
    """Run Depth stream server."""
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.ERROR)
    app = create_depth_app()
    print(f"Starting Depth stream server on 0.0.0.0:{DEPTH_PORT}")
    app.run(host='0.0.0.0', port=DEPTH_PORT, threaded=True, use_reloader=False, debug=False)

def cleanup():
    """Cleanup on exit."""
    print("Shutting down RealSense service...")
    stop_event.set()
    release_realsense()


if __name__ == "__main__":
    print("=" * 50)
    print("Intel RealSense Camera Service")
    print(f"RGB Stream:   http://0.0.0.0:{RGB_PORT}/video_feed")
    print(f"Depth Stream: http://0.0.0.0:{DEPTH_PORT}/video_feed")
    print("=" * 50)
    
    # Register cleanup handler
    atexit.register(cleanup)
    
    # Start frame capture thread
    capture_thread = threading.Thread(target=capture_frames, daemon=True)
    capture_thread.start()
    
    # Give camera time to initialize
    time.sleep(2)
    
    # Start RGB server in a separate thread
    rgb_thread = threading.Thread(target=run_rgb_server, daemon=False)
    rgb_thread.start()
    
     # Start Depth server in a separate thread
    depth_thread = threading.Thread(target=run_depth_server, daemon=False)
    depth_thread.start()
    
    # Keep main thread alive
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nShutting down...")
        cleanup()
