"""
Small, pure helpers shared by services/agent_state.py, services/diagnostics_service.py,
and services/mavlink_health.py for reading mavlink2rest message envelopes.

No I/O here -- everything takes an already-fetched envelope (the dict mav_get()
returned, or None) and returns a decoded value or None. Centralized so the same
"how do I read this field" logic isn't re-derived slightly differently in each
of the three call sites.
"""
import re
from datetime import datetime, timezone
from typing import Optional


def last_update_epoch(envelope: Optional[dict]) -> Optional[float]:
    """
    `status.time.last_update` (RFC3339, nanosecond precision) converted to a
    Unix epoch float, for callers that need to compare it against a
    wall-clock deadline -- e.g. "did this message arrive after I posted my
    request" -- rather than merely detect that it changed. See
    services/mission_service.py's transaction freshness proof, which uses
    this alongside last_update_token() so a stale message can't be accepted
    just because *something* about the cache slot looks new.

    Returns None on the same conditions message_age_seconds() does: no
    envelope, no timestamp, or an unparseable one -- callers must treat that
    as "freshness unprovable", never as "assume fresh".
    """
    try:
        last_update = envelope["status"]["time"]["last_update"]
    except (KeyError, TypeError):
        return None
    ts = re.sub(r'\.(\d{6})\d*Z?$', r'.\1+00:00', last_update)
    if ts.endswith("Z"):
        ts = ts[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(ts).timestamp()
    except ValueError:
        return None


def message_age_seconds(envelope: Optional[dict]) -> Optional[float]:
    """
    Seconds since mavlink2rest last received this message, read from the
    envelope's status.time.last_update (RFC3339, nanosecond precision).
    mavlink2rest never expires a cached message on its own -- a channel that
    stopped transmitting hours ago still answers with its last-known value,
    so presence alone can't prove a link is currently alive. Returns None if
    the envelope carries no timestamp (missing envelope, or an unexpected
    mavlink2rest response shape), letting the caller fail to UNKNOWN/null
    rather than assume freshness.
    """
    epoch = last_update_epoch(envelope)
    if epoch is None:
        return None
    return datetime.now(timezone.utc).timestamp() - epoch


def last_update_token(envelope: Optional[dict]) -> Optional[str]:
    """Raw last_update string, used as a cheap "did a new message arrive"
    marker (unequal token => a new message was cached since last read) --
    see mavlink_health.py's rate tracking."""
    try:
        return envelope["status"]["time"]["last_update"]
    except (KeyError, TypeError):
        return None


_GPS_FIX_NUM = {
    "GPS_FIX_TYPE_NO_GPS": 0, "GPS_FIX_TYPE_NO_FIX": 1,
    "GPS_FIX_TYPE_2D_FIX": 2, "GPS_FIX_TYPE_3D_FIX": 3,
    "GPS_FIX_TYPE_DGPS": 4, "GPS_FIX_TYPE_RTK_FLOAT": 5,
    "GPS_FIX_TYPE_RTK_FIXED": 6,
}


def gps_fix_type_num(gps_raw: Optional[dict]) -> Optional[int]:
    """Numeric GPS_RAW_INT fix_type (0-6, MAVLink GPS_FIX_TYPE enum), decoded
    from either mavlink2rest's named-enum shape ({"type": "GPS_FIX_TYPE_3D_FIX"})
    or a raw int, whichever it hands back. None if not available/unrecognized."""
    if gps_raw is None:
        return None
    try:
        fix_raw = gps_raw["message"]["fix_type"]
        if isinstance(fix_raw, dict):
            fix_raw = fix_raw.get("type")
        if isinstance(fix_raw, int):
            return fix_raw
        return _GPS_FIX_NUM.get(fix_raw)
    except Exception:
        return None


def gps_satellites_visible(gps_raw: Optional[dict]) -> Optional[int]:
    """GPS_RAW_INT.satellites_visible -- MAVLink convention reports 255 for
    "unknown", which is not a real satellite count, so it maps to None."""
    if gps_raw is None:
        return None
    try:
        count = gps_raw["message"]["satellites_visible"]
        return count if isinstance(count, int) and count != 255 else None
    except Exception:
        return None
