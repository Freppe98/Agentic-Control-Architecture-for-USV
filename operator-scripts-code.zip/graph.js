const graph = document.getElementById('graph');


//['timestamp', 'latitude', 'longitude', 'temperature', 'ph', 'voltage']

savedData = [];




var MaximumDataPointsInBrowser = 20

//Default Graph To show
var currentGraph = 'PH';
var currentSpan = 20;

function AddValues(data){
    
    for(var i = 0; i < data.length; i++){
        savedData.push(data[i]);
    }

    //Make sure we do not store to many datapoints in the browser
    //The MaximumDataPointsInBrowser can be reduced to decrease ram usage on lower end machines. But i do not know if this would be significant in any way
    while(savedData.length > MaximumDataPointsInBrowser){
        savedData.shift()
    }
    
    SetGraph(currentGraph, currentSpan);
}


function SetGraph(id, span=20) {
   
    currentGraph = id;
    currentSpan = span;

    
    let times =[];
    var datapoints = [];

    for(var i = 0; i < savedData.length; i++){
        datapoints.push(savedData[i][id])
        times.push(savedData[i]["timestamp"].slice(11,-3));
    }
    
    

    // Remove old chart
    if (typeof chart !== 'undefined') {
        chart.destroy();
    }

    chart = new Chart(graph, {
        type: 'line',
        data: {
            labels: times,
            datasets: [{
                label: id,
                data: datapoints,
                borderWidth: 2,
               
            }]
        },
        options: {
            animation:{
                duration: 0
            },
            plugins: {
                legend: {
                    display: false // Hide the default legend
                }
            },
        },
        
    });
}

// Start with a chart
//SetGraph("Water Temperature (C)", ["13:37", "13:38","13:39","13:40","13:41","13:42"], [3,3,6,4,2,3]);
