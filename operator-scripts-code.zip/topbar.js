
//For enabeling disableing the sensors

function ToggleSensors(slider){
    if (slider.classList.contains("sliderDisable")){
        SendCommand("toggleSensors", 1);
        console.log("Starting sensors");

        slider.classList.remove("sliderDisable");
        slider.firstElementChild.classList.remove("switchoff");

    }else{
        SendCommand("toggleSensors", 0);
        
        slider.classList.add("sliderDisable");
        slider.firstElementChild.classList.add("switchoff");
    
    }
}

var measurementsSliderSwitch = document.getElementsByClassName("measurementsSliderSwitch")[0];

function ToggleSensorsBackEndRequest(state){
    if (state){
        
        measurementsSliderSwitch.classList.remove("sliderDisable");
        measurementsSliderSwitch.firstElementChild.classList.remove("switchoff");
    }else{
        measurementsSliderSwitch.classList.add("sliderDisable");
        measurementsSliderSwitch.firstElementChild.classList.add("switchoff");

    }
}

function ToggleBuzzer(slider){
    if (slider.classList.contains("sliderDisable")){
        //Led is not set to on
        //Styling for the slider
        SendCommand("Buzzer", 1);
        slider.classList.remove("sliderDisable");
        slider.firstElementChild.classList.remove("switchoff");
    }else{
        SendCommand("Buzzer", 0);
        slider.classList.add("sliderDisable");
        slider.firstElementChild.classList.add("switchoff");

    }
}

//For handeling historical data

function ToggleMission(slider) {
  if (slider.classList.contains("sliderDisable")) {

    const missionName = prompt("Enter your 'Location' here:");
    if (!missionName) return;  // User cancelled or left blank

    // Start mission on server
    fetch('/start_mission', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: missionName })
    });

    console.log("Recording Mission");
    slider.classList.remove("sliderDisable");
    slider.firstElementChild.classList.remove("switchoff");
    document.getElementById("HistorySelection").disabled = true;

  } else {
    // Stop mission on server
    fetch('/stop_mission', { method: 'POST' });

    slider.classList.add("sliderDisable");
    slider.firstElementChild.classList.add("switchoff");
    document.getElementById("HistorySelection").disabled = false;
  }
}




// Click and download Mission from dropdown
function handleSelection(selectElement) {
  const selectedValue = selectElement.value;
  const spinnerContainer = document.getElementById('spinnerContainer');
  
  spinnerContainer.style.display = 'block';

  if (selectedValue === '-12h') {
    fetch('/getdata')
      .then(response => response.blob())
      .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;

        const now = new Date();
        const timestamp = now.toISOString().replace(/[:T]/g, '-').slice(0, 16);
        a.download = `${timestamp}_AqualityONE_data_-12h.txt`;

        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        spinnerContainer.style.display = 'none';
     })
      .catch(err => {
        console.error(err);
        alert('Could not download the data for -12h.');
        spinnerContainer.style.display = 'none';
      });

  } else {
    // Download selected mission
    fetch(`/download_mission?id=${encodeURIComponent(selectedValue)}`)
      .then(response => {
        console.error("Server response:", response);
        if (!response.ok) throw new Error('Failed to download');
        return response.blob();
      })
      .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${selectedValue}_AqualityONE_data.zip`; // Or .json or whatever you return
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        spinnerContainer.style.display = 'none';
      })
      .catch(err => {
        console.error(err);
        alert(`Could not download mission data for "${selectedValue}".`);
        spinnerContainer.style.display = 'none';
      });
  }
}

// dropdown menu should show all available missionIDs
async function loadMissionIds() {
  try {
    const response = await fetch('/get_missions');
    if (!response.ok) throw new Error('Network error');

    let missions = await response.json();

    // Sort by datetime descending (newest first)
    missions.sort((a, b) => {
      const getDate = id => {
        const [date, time] = id.split('_');
        return new Date(`${date}T${time.replace('-', ':')}`);
      };
      return getDate(b) - getDate(a); // newest first
    });

    const select = document.getElementById('HistorySelection');

    // Add sorted options
    missions.forEach(id => {
      const option = document.createElement('option');
      option.value = id;
      option.textContent = id;
      option.classList.add('mission-option');
      select.appendChild(option);
    });

  } catch (error) {
    console.error('Failed to load mission IDs:', error);
  }
}

// Load on page ready
window.addEventListener('DOMContentLoaded', loadMissionIds);





/*/Eventlistener on when date is changed
document.getElementById("HistorySelection").addEventListener('change', function() {
    
    //Go back to Mission mode if Mission is selected
    if(this.value == "Live"){
        ToggleMission(document.getElementById("switch"));
        //Load todays db
        window.request_data('today');
    }

    //Get the history data instead
    window.request_data(this.value);


});*/

//Takes a list of database names in the form of dates. And makes sure the drop down menu contains them
function LoadAvailableDatabaseList(list){
    var HistoryElement = document.getElementById("HistorySelection");
    for (var i = 0; i < list.length; i++){
        var txt = list[i];
        if(txt.includes('.Identifier')){
            continue;
        }
        var item = document.createElement('option');
        //remove the .db
        txt = txt.substring(0, txt.length -3);
        item.innerHTML=txt;
        HistoryElement.appendChild(item);
    }
}

//Opens the BlueOs dashboard (local)
function OpenBlue(){
    window.location = "http://192.168.2.10:8086/";
}

// Rotate Dome Cam
function rotateDomeCam(button) {
    const buttonId = button.id;
    const currentUrl = window.location.origin;
    const newUrl = currentUrl + "/rotate_dome_cam?id=" + buttonId;

    fetch(newUrl)
        .then(response => response.text())
        .then(data => {
            console.log("Response from server:", data);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

//Toggle LED
var ledSwitch = document.getElementsByClassName("LedSliderSwitch")[0];

function ToggleLed(){
    if (ledSwitch.classList.contains("sliderDisable")){
        ledSwitch.classList.remove("sliderDisable");
        ledSwitch.firstElementChild.classList.remove("switchoff");
        SendCommand("toggleLed", 1);
    }else{
        ledSwitch.classList.add("sliderDisable");
        ledSwitch.firstElementChild.classList.add("switchoff");

        SendCommand("toggleLed", 0);
    }
}

//For triggering the individual water samples and disable them afterwards to avoid sample loss 

function handleSampleClick(button) {
    button.style.backgroundColor = 'var(--red_off)';
    button.disabled = true;

    const buttonId = button.id;
    
    const currentUrl = window.location.origin;
    const newUrl = currentUrl + "/control_sampler?id=" + buttonId;

    fetch(newUrl)
        .then(response => response.text())
        .then(data => {
            console.log("Response from server:", data);
        })
        .catch(error => {
            console.error('Error:', error);
        });

}
// Attach event listeners to sample buttons that trigger handleSampleClick function

document.addEventListener('DOMContentLoaded', function() {
    const buttons = document.querySelectorAll('.samplerbutton');

    buttons.forEach(button => {
        button.addEventListener('click', function() {
            handleSampleClick(this);
        });
    });
});


var cameraButton = document.getElementById('cameraButton');
var cameraAlts = document.getElementsByClassName("cameraAlt");

function CameraClick(obj){
    if(obj.id == "cameraButton"){
        if(cameraButton.classList.contains("open")){
            //Close menu and select new camera option
            cameraButton.classList.remove("open");
            for (let btn of cameraAlts){
                btn.classList.add("unclickable");
            }
            
    
            
        }else{
            //open the meny
            cameraButton.classList.add("open");
            for (let btn of cameraAlts){
                btn.classList.remove("unclickable");
            }
    
    
        }

    }else{
        //Send the new settings to the server 
        SendCommand("CameraMode", obj.innerHTML);

        //Update the ui
        var temp = cameraAlts[0].innerHTML;
        cameraAlts[0].innerHTML = obj.innerHTML;
        obj.innerHTML = temp;
    }
   
    

}




//Reload button for the water samplers inside pop-up window

function openPOPup(button) {
    document.getElementById('myModal').style.display = 'block';
}
var modal = document.getElementById('myModal');
var span = document.getElementsByClassName('close')[0];
span.onclick = function() {modal.style.display = 'none';}


function reloadsampler(button) {
    const buttonId = button.id;
    const currentUrl = window.location.origin;
    const newUrl = currentUrl + "/reload_sampler?id=" + buttonId;

    fetch(newUrl)
            .then(response => response.text())
            .then(data => {
                console.log("Response from server:", data);

                // Integrated logic to reset sample buttons
                const sampleButtons = document.querySelectorAll('.samplerbutton');
                sampleButtons.forEach(button => {
                    button.style.backgroundColor = 'var(--green_on)';
                    button.disabled = false;
                });
            })
            .catch(error => {
                console.error('Error:', error);
            });
}

//Add event listenes for close and YES button in the modal/ pop-up window 

document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('myModal');
    const modalButton = document.getElementById('5'); 
    const closeButton = document.querySelector('.close');

    modalButton.addEventListener('click', function() {
        reloadsampler(this);
        modal.style.display = 'none';
    });
    closeButton.addEventListener('click', function() {
        modal.style.display = 'none';
    });
});


