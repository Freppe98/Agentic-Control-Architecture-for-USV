import os
import shutil
import socket
import requests


def ram_usage_percent() -> float | None:
    try:
        info = {}
        with open('/proc/meminfo') as f:
            for line in f:
                if ':' in line:
                    key, val = line.split(':', 1)
                    info[key.strip()] = int(val.strip().split()[0])
        total = info.get('MemTotal', 0)
        avail = info.get('MemAvailable', 0)
        return round(100 * (total - avail) / total, 1) if total else None
    except Exception:
        return None


def cpu_temp() -> float | None:
    try:
        with open('/sys/class/thermal/thermal_zone0/temp') as f:
            return round(int(f.read().strip()) / 1000, 1)
    except Exception:
        return None


def service_reachable(url: str, timeout: float = 0.5) -> bool:
    try:
        requests.head(url, timeout=timeout)
        return True
    except Exception:
        return False


def gpio_reachable(socket_path: str, timeout: float = 0.5) -> bool:
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect(socket_path)
        s.close()
        return True
    except Exception:
        return False


def build_health(
    sensor_url: str,
    gpio_socket_path: str,
    pixhawk_ok: bool,
    bat,
    gps_raw,
    sensors_enabled: bool,
) -> dict:
    disk = shutil.disk_usage('/')

    gps_fix = None
    try:
        fix_raw = gps_raw.get('message', {}).get('fix_type', {})
        if isinstance(fix_raw, dict):
            gps_fix = fix_raw.get('type', '?').replace('GPS_FIX_TYPE_', '')
        else:
            _fix_map = {
                0: 'NO_GPS', 1: 'NO_FIX', 2: '2D', 3: '3D',
                4: 'DGPS', 5: 'RTK_FLOAT', 6: 'RTK_FIXED',
            }
            gps_fix = _fix_map.get(int(fix_raw), str(fix_raw))
    except Exception:
        pass

    return {
        'cpu_load': round(os.getloadavg()[0], 2),
        'ram_usage': ram_usage_percent(),
        'disk_usage': round(100 * disk.used / disk.total, 1),
        'temperature': cpu_temp(),
        'docker': {
            'flask':  True,
            'sensor': service_reachable(sensor_url),
            'gpio':   gpio_reachable(gpio_socket_path),
            'influx': None,
        },
        'pixhawk': {
            'connected': pixhawk_ok,
            'gps_fix':   gps_fix,
            'battery':   (bat['message']['battery_remaining'] if bat else None),
        },
        'system': {
            'leak_detected':   None,
            'estop':           None,
            'sensors_enabled': sensors_enabled,
        },
    }
