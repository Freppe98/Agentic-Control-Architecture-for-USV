"""
Tracks operator command_ids already processed by this Local Agent, so a
command re-delivered by the operator backend is never executed twice.
Persisted to survive a Local Agent restart mid-mission.
"""
from config import COMMAND_LOG_FILE, MAX_TRACKED_COMMAND_IDS


def _read_ids():
    try:
        with open(COMMAND_LOG_FILE, "r") as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        return []


def is_duplicate(command_id: str) -> bool:
    return command_id in _read_ids()


def mark_processed(command_id: str) -> None:
    ids = _read_ids()
    ids.append(command_id)
    ids = ids[-MAX_TRACKED_COMMAND_IDS:]
    with open(COMMAND_LOG_FILE, "w") as f:
        for cid in ids:
            f.write(cid + "\n")
