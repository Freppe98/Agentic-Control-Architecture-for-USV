"""
Scout-side "Set Home Here" capability: sets Pixhawk HOME_POSITION to the
Scout's own current GPS position, verifies it actually took effect (not just
that a MAVLink command was transmitted), and tracks whether this runtime has
completed and confirmed such a verification -- see GET /agent/home_status
and README "Set Home" for curl examples.

Root problem this exists to fix: ArduPilot mission sequence 0 always
reflects Pixhawk HOME_POSITION, set once (at the garage, on power-up) and
never moved automatically when a new mission is later uploaded for a
different launch site (e.g. a lake). AUTO/RTL/MISSION_RESUME executed
against a stale Home would navigate relative to, or return to, the wrong
location. This module is the one place that ever calls MAV_CMD_DO_SET_HOME,
and the one place that decides whether Home is currently trustworthy enough
to gate those commands on -- see is_ready_for_auto_or_rtl(), used by
app.py's /nav/AutoModeOn, /nav/rtl, /nav/resume. LOITER and MANUAL never
call into this module at all: they must remain available regardless of
Home verification (see app.py's /nav/hold, /nav/loiter, /nav/manual).

Design mirrors services/mission_service.py: mavlink2rest never expires a
cached message and caches exactly one slot per message type, so "post a
request, sleep, read whatever's cached" can silently accept a stale or
unrelated reply. Every MAVLink reply this module waits for (COMMAND_ACK,
HOME_POSITION) is proven fresh the same way mission_service.py proves
MISSION_COUNT/MISSION_ITEM_INT fresh: a status.time.last_update token that
changed since immediately before the request was posted, AND an arrival
time not earlier than the moment the request was sent (see
mavlink_message_utils.last_update_epoch) -- not just "the cache slot looks
different". COMMAND_ACK additionally is only accepted if its own `command`
field names MAV_CMD_DO_SET_HOME (mavlink2rest caches exactly one COMMAND_ACK
regardless of which command it acks, same single-slot hazard as
MISSION_ITEM_INT's `seq`).

Verification-state latch (module-level, in-process only -- same lifetime
convention as services/control_authority.py, and for the same reason: this
process's own memory is the only thing that can honestly know "I, this
runtime, actually completed and confirmed a Set Home operation". Coordinates
alone can never prove that -- a stale Home could coincidentally sit near the
vehicle's current position without anyone ever running this flow, and this
module must not treat that coincidence as verified. The latch is:

  - SET only by a fully successful set_home_current_position() call (every
    condition in that function's docstring held).
  - CLEARED (never silently kept) when:
      * mavlink2rest reports the Pixhawk rebooted/reconnected --
        GLOBAL_POSITION_INT's time_boot_ms (milliseconds since flight-
        controller boot) goes backwards, the standard reboot tell since
        HEARTBEAT itself carries no boot counter;
      * the live HOME_POSITION reading drifts more than
        HOME_DRIFT_INVALIDATION_M from the position last confirmed by
        set_home_current_position(), without an intervening successful
        call to it (something other than this module moved Home).
  - NEVER cleared merely by the vehicle's current GPS position moving away
    from Home -- that is the *expected* outcome of a mission (the vehicle
    drives away from its verified recovery point toward the mission area),
    not evidence Home is wrong. distance_from_vehicle_m in
    GET /agent/home_status is informational only, never a gating input.
  - NOT reset by a Local Agent (motherpi/services/local_mission_agent/)
    process restart: verification state lives here, in the vehicle Flask
    service, which the Local Agent only ever queries over HTTP -- restarting
    that separate process safely reconstructs its view by simply calling
    GET /agent/home_status again.
  - IS reset whenever this Flask service itself restarts (in-memory only,
    same as control_authority) -- deliberately conservative: a fresh
    process cannot honestly know whether a Set Home actually completed
    before it started.

Never renumbers, uploads, clears, or otherwise touches the mission stored on
the Pixhawk -- Home (sequence 0 in the mission protocol) and the executable
mission items (sequence 1..N) are handled by entirely separate MAVLink
messages (COMMAND_LONG/HOME_POSITION here vs MISSION_ITEM_INT in
mission_service.py); this module never posts a mission message of any kind.
"""
import math
import threading
import time
from typing import Callable, Optional

import requests

from services.mavlink_message_utils import last_update_token, last_update_epoch

TARGET_SYSTEM = 1
TARGET_COMPONENT = 1

_BASE_PATH = f"/mavlink/vehicles/{TARGET_SYSTEM}/components/{TARGET_COMPONENT}/messages"
_GLOBAL_POSITION_INT_PATH = f"{_BASE_PATH}/GLOBAL_POSITION_INT"
_HOME_POSITION_PATH = f"{_BASE_PATH}/HOME_POSITION"
_COMMAND_ACK_PATH = f"{_BASE_PATH}/COMMAND_ACK"

# ── Configurable thresholds -- safe defaults; a caller (ultimately the
# operator's Set Home request body, threaded through set_home_handler.py ->
# api_client.py -> POST /agent/set_home) may override tolerance_m/
# freshness_s per call. See set_home_current_position(). ──────────────────
DEFAULT_POSITION_FRESHNESS_S = 3.0
DEFAULT_VERIFICATION_TOLERANCE_M = 5.0
# Looser than DEFAULT_VERIFICATION_TOLERANCE_M on purpose: this guards
# against a *different* Home silently appearing later (module docstring),
# not the tight just-set check -- extra slack avoids re-triggering on GPS
# jitter around the same point.
HOME_DRIFT_INVALIDATION_M = 15.0

_ACK_TIMEOUT_S = 3.0
_ACK_MAX_RETRIES = 3
_HOME_TIMEOUT_S = 3.0
_HOME_MAX_RETRIES = 3
_POLL_INTERVAL_S = 0.05
_CLOCK_SKEW_TOLERANCE_S = 0.25

_SET_HOME_COMMAND = "MAV_CMD_DO_SET_HOME"
_GET_HOME_COMMAND = "MAV_CMD_GET_HOME_POSITION"
_ACK_ACCEPTED = "MAV_RESULT_ACCEPTED"

# Single gunicorn worker (gthread, multiple threads -- see
# gunicorn_config.py) means two overlapping Set Home / home_status calls
# would otherwise interleave COMMAND_LONG/COMMAND_ACK/HOME_POSITION traffic
# against the same mavlink2rest cache, exactly the hazard
# mission_service.py's _download_lock guards against. Also protects the
# verification latch below from a torn read/write.
_lock = threading.Lock()

_mav_get: Optional[Callable] = None
_mav_post: Optional[Callable] = None
_mavlink_base_url: Optional[str] = None

# The verification latch -- see module docstring. `_verified_home` is the
# HOME_POSITION confirmed at the moment verification last succeeded, kept
# only to detect a later unexpected drift; GET /agent/home_status always
# recomputes home_position fresh, never from this cached value.
# `_verified_distance_m` is the verification_distance_m computed by that same
# successful call, kept only so GET /agent/home_status can report it without
# re-deriving it -- purely informational, never a gating input.
_verified = False
_verified_at: Optional[float] = None
_verified_home: Optional[dict] = None
_verified_distance_m: Optional[float] = None
_last_time_boot_ms: Optional[int] = None


def init(mav_get_fn: Callable, mav_post_fn: Callable, mavlink_base_url: str) -> None:
    global _mav_get, _mav_post, _mavlink_base_url
    _mav_get = mav_get_fn
    _mav_post = mav_post_fn
    _mavlink_base_url = mavlink_base_url


def reset_verification_for_tests() -> None:
    """Test-only hook to clear the module-level latch between test cases --
    real code never calls this (see module docstring: the latch is only
    ever cleared by a real invalidation trigger or this process restarting)."""
    global _verified, _verified_at, _verified_home, _verified_distance_m, _last_time_boot_ms
    _verified = False
    _verified_at = None
    _verified_home = None
    _verified_distance_m = None
    _last_time_boot_ms = None


def _safe_get(path: str):
    try:
        return _mav_get(path)
    except Exception:
        return None


def mavlink2rest_reachable(timeout: float = 1.0) -> bool:
    if not _mavlink_base_url:
        return False
    try:
        requests.get(_mavlink_base_url, timeout=timeout)
        return True
    except Exception:
        return False


def _decode_enum(value):
    return value.get("type") if isinstance(value, dict) else value


def _haversine_m(lat1, lon1, lat2, lon2) -> float:
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlambda / 2) ** 2
    return 2 * r * math.asin(min(1.0, math.sqrt(a)))


def _valid_coordinate(lat, lon) -> bool:
    if lat is None or lon is None:
        return False
    if not (-90.0 <= lat <= 90.0) or not (-180.0 <= lon <= 180.0):
        return False
    if lat == 0.0 and lon == 0.0:
        return False  # ArduPilot's "no GPS fix yet" sentinel, never a real position
    return True


def _read_vehicle_position(freshness_s: float):
    """
    Returns (position_dict_or_None, error_code_or_None, error_message_or_None).
    position_dict: {"latitude", "longitude", "age_s", "time_boot_ms"}.
    """
    envelope = _safe_get(_GLOBAL_POSITION_INT_PATH)
    if envelope is None:
        return None, "POSITION_UNAVAILABLE", "No GLOBAL_POSITION_INT has ever been received from the Pixhawk."
    try:
        msg = envelope["message"]
        lat = round(msg["lat"] / 1e7, 7)
        lon = round(msg["lon"] / 1e7, 7)
        time_boot_ms = msg.get("time_boot_ms")
    except (KeyError, TypeError):
        return None, "POSITION_UNAVAILABLE", "GLOBAL_POSITION_INT reply was malformed."

    epoch = last_update_epoch(envelope)
    age_s = (time.time() - epoch) if epoch is not None else None

    if age_s is None:
        return None, "POSITION_STALE", "Could not determine the age of the current vehicle position."
    if age_s > freshness_s:
        return None, "POSITION_STALE", (
            f"Current vehicle position is {age_s:.1f}s old, exceeding the "
            f"{freshness_s:.1f}s freshness threshold."
        )
    if not _valid_coordinate(lat, lon):
        return None, "INVALID_POSITION", f"Vehicle position lat={lat} lon={lon} is not a valid, non-zero fix."

    return {"latitude": lat, "longitude": lon, "age_s": round(age_s, 3), "time_boot_ms": time_boot_ms}, None, None


def _fetch_home_position() -> Optional[dict]:
    envelope = _safe_get(_HOME_POSITION_PATH)
    if envelope is None:
        return None
    try:
        msg = envelope["message"]
        return {
            "latitude": round(msg["latitude"] / 1e7, 7),
            "longitude": round(msg["longitude"] / 1e7, 7),
            "altitude": round(msg["altitude"] / 1000.0, 3),
        }
    except (KeyError, TypeError):
        return None


def _wait_for_fresh(path: str, baseline_token, not_before: float, deadline: float, predicate: Optional[Callable] = None):
    """Same freshness proof as services/mission_service.py's _wait_for_fresh:
    a candidate reply is only accepted once its own status.time.last_update
    token differs from `baseline_token` AND mavlink2rest's own reported
    arrival time for it is not earlier than `not_before` -- proving it is a
    reply that could only have been produced after this specific request
    was posted, not merely a cache slot that happened to look different."""
    while time.time() < deadline:
        envelope = _safe_get(path)
        if envelope is not None:
            token = last_update_token(envelope)
            if token is not None and token != baseline_token:
                arrival = last_update_epoch(envelope)
                fresh = arrival is None or arrival >= not_before - _CLOCK_SKEW_TOLERANCE_S
                if fresh and (predicate is None or predicate(envelope)):
                    return envelope
        time.sleep(_POLL_INTERVAL_S)
    return None


def _send_set_home_current_location() -> None:
    _mav_post({
        "type": "COMMAND_LONG",
        "param1": 1, "param2": 0, "param3": 0, "param4": 0, "param5": 0, "param6": 0, "param7": 0,
        "command": {"type": _SET_HOME_COMMAND},
        "target_system": TARGET_SYSTEM, "target_component": TARGET_COMPONENT,
        "confirmation": 0,
    })


def _request_home_position_broadcast() -> None:
    """MAV_CMD_GET_HOME_POSITION -- forces ArduPilot to re-send HOME_POSITION
    on demand. ArduPilot only otherwise broadcasts HOME_POSITION once, on
    change, with no repeating stream and no *_REQUEST_* counterpart (see
    mission_service.py's HOME_POSITION docstring for the same limitation) --
    this command is the one way to force a fresh, provable answer instead of
    passively hoping a stale cached value happens to already be right."""
    _mav_post({
        "type": "COMMAND_LONG",
        "param1": 0, "param2": 0, "param3": 0, "param4": 0, "param5": 0, "param6": 0, "param7": 0,
        "command": {"type": _GET_HOME_COMMAND},
        "target_system": TARGET_SYSTEM, "target_component": TARGET_COMPONENT,
        "confirmation": 0,
    })


def _wait_for_set_home_ack(deadline: float):
    """MAV_CMD_DO_SET_HOME -> COMMAND_ACK, bounded by _ACK_TIMEOUT_S per
    attempt and _ACK_MAX_RETRIES attempts, both capped by `deadline`. Only
    accepts a reply whose own `command` field names MAV_CMD_DO_SET_HOME --
    mavlink2rest caches exactly one COMMAND_ACK regardless of which command
    it acks, so without this a stale ack for an unrelated command could be
    mistaken for this one."""
    def _is_set_home_ack(envelope):
        try:
            return _decode_enum(envelope["message"]["command"]) == _SET_HOME_COMMAND
        except (KeyError, TypeError):
            return False

    baseline_token = last_update_token(_safe_get(_COMMAND_ACK_PATH))
    for _ in range(_ACK_MAX_RETRIES):
        if time.time() >= deadline:
            return None, "no COMMAND_ACK received before the overall deadline"
        _send_set_home_current_location()
        sent_at = time.time()
        attempt_deadline = min(deadline, sent_at + _ACK_TIMEOUT_S)
        envelope = _wait_for_fresh(_COMMAND_ACK_PATH, baseline_token, sent_at, attempt_deadline, predicate=_is_set_home_ack)
        if envelope is not None:
            return envelope, None
        baseline_token = last_update_token(_safe_get(_COMMAND_ACK_PATH))
    return None, f"no COMMAND_ACK for {_SET_HOME_COMMAND} after {_ACK_MAX_RETRIES} attempts"


def _wait_for_updated_home(deadline: float):
    """MAV_CMD_GET_HOME_POSITION -> a fresh HOME_POSITION broadcast, same
    bounded retry/timeout shape as _wait_for_set_home_ack."""
    baseline_token = last_update_token(_safe_get(_HOME_POSITION_PATH))
    for _ in range(_HOME_MAX_RETRIES):
        if time.time() >= deadline:
            return None, "no updated HOME_POSITION received before the overall deadline"
        _request_home_position_broadcast()
        sent_at = time.time()
        attempt_deadline = min(deadline, sent_at + _HOME_TIMEOUT_S)
        envelope = _wait_for_fresh(_HOME_POSITION_PATH, baseline_token, sent_at, attempt_deadline)
        if envelope is not None:
            return envelope, None
        baseline_token = last_update_token(_safe_get(_HOME_POSITION_PATH))
    return None, f"no updated HOME_POSITION after {_HOME_MAX_RETRIES} attempts"


def _result(accepted, verified, command_id, error_code=None, error_message=None,
            requested_position=None, home_position=None, verification_distance_m=None,
            ack_result=None) -> dict:
    return {
        "accepted": accepted,
        "verified": verified,
        "command_id": command_id,
        "requested_position": requested_position,
        "home_position": home_position,
        "verification_distance_m": verification_distance_m,
        "ack_result": ack_result,
        "error": {"code": error_code, "message": error_message} if error_code else None,
    }


def _log(event, **fields) -> None:
    """Structured single-line logs -- received request, position selected,
    DO_SET_HOME sent, ACK result, Home before/after, verification distance,
    final outcome. Deliberately plain print (same convention as
    local_agent.py's own [LOCAL AGENT] lines and app.py's [TIMING]/[VERIFY]
    ones) rather than a new logging framework this codebase doesn't use
    elsewhere."""
    detail = " ".join(f"{k}={v}" for k, v in fields.items())
    print(f"[SET_HOME] {event}: {detail}")


def _mark_verified(command_id, home_position, distance_m) -> None:
    global _verified, _verified_at, _verified_home, _verified_distance_m
    _verified = True
    _verified_at = time.time()
    _verified_home = dict(home_position)
    _verified_distance_m = distance_m
    _log("verification_latched", command_id=command_id, home=home_position, at=_verified_at)


def _invalidate(reason: str) -> None:
    global _verified, _verified_at, _verified_home, _verified_distance_m
    if _verified:
        _log("verification_invalidated", reason=reason)
    _verified = False
    _verified_at = None
    _verified_home = None
    _verified_distance_m = None


def _check_reboot(time_boot_ms: Optional[int]) -> None:
    """Invalidates the verification latch if GLOBAL_POSITION_INT's
    time_boot_ms (milliseconds since flight-controller boot) goes backwards
    -- the standard reboot/reconnect tell, since HEARTBEAT itself carries no
    boot counter."""
    global _last_time_boot_ms
    if time_boot_ms is None:
        return
    if _last_time_boot_ms is not None and time_boot_ms < _last_time_boot_ms:
        _invalidate(
            f"Pixhawk time_boot_ms went backwards ({_last_time_boot_ms} -> {time_boot_ms}), "
            "indicating a reboot/reconnect since Home was last verified."
        )
    _last_time_boot_ms = time_boot_ms


def _check_home_drift(home_position: Optional[dict]) -> None:
    """Invalidates the verification latch if the live HOME_POSITION reading
    has drifted more than HOME_DRIFT_INVALIDATION_M from the position last
    confirmed by set_home_current_position(), without an intervening
    successful call to it -- see module docstring."""
    if not _verified or _verified_home is None or home_position is None:
        return
    distance = _haversine_m(
        _verified_home["latitude"], _verified_home["longitude"],
        home_position["latitude"], home_position["longitude"],
    )
    if distance > HOME_DRIFT_INVALIDATION_M:
        _invalidate(
            f"HOME_POSITION drifted {distance:.1f}m from the last verified location "
            f"(threshold {HOME_DRIFT_INVALIDATION_M}m) without a new Set Home."
        )


def set_home_current_position(command_id: str, tolerance_m: Optional[float] = None,
                               freshness_s: Optional[float] = None) -> dict:
    """
    Full "Set Home Here" flow:

      1. mavlink2rest/Pixhawk must be reachable.
      2. Read the Scout's own current GLOBAL_POSITION_INT; it must be fresh
         (age <= freshness_s) and a valid, non-zero lat/lon.
      3. Send MAV_CMD_DO_SET_HOME (param1=1, "use current location" -- the
         Pixhawk uses its own live position estimate, avoiding any relay
         lag between our reading and the instant the command executes) and
         wait for a matching COMMAND_ACK; it must be MAV_RESULT_ACCEPTED.
      4. Force and wait for an updated HOME_POSITION broadcast
         (MAV_CMD_GET_HOME_POSITION).
      5. The updated HOME_POSITION must be within tolerance_m of the
         position read in step 2.

    Only when every one of those holds is the verification latch set (see
    module docstring) and {"accepted": true, "verified": true, ...}
    returned. Every other path returns {"accepted": false, "verified":
    false, "error": {"code", "message"}, ...} with whatever fields were
    actually determined before the failure (never fabricated) -- this
    function never raises; a caller always gets a well-formed result.

    Never uploads, modifies, or renumbers the mission stored on the
    Pixhawk -- only COMMAND_LONG (MAV_CMD_DO_SET_HOME /
    MAV_CMD_GET_HOME_POSITION) is ever posted here, no MISSION_* message.
    """
    tolerance_m = DEFAULT_VERIFICATION_TOLERANCE_M if tolerance_m is None else tolerance_m
    freshness_s = DEFAULT_POSITION_FRESHNESS_S if freshness_s is None else freshness_s

    _log("received_request", command_id=command_id, tolerance_m=tolerance_m, freshness_s=freshness_s)

    with _lock:
        if not mavlink2rest_reachable():
            _log("final_result", command_id=command_id, status="failed", reason="PIXHAWK_UNREACHABLE")
            return _result(False, False, command_id, "PIXHAWK_UNREACHABLE",
                            "mavlink2rest/Pixhawk is not reachable.")

        position, error_code, error_message = _read_vehicle_position(freshness_s)
        if position is None:
            _log("final_result", command_id=command_id, status="failed", reason=error_code)
            return _result(False, False, command_id, error_code, error_message)

        _log("position_selected", command_id=command_id, position=position)
        _check_reboot(position.get("time_boot_ms"))

        home_before = _fetch_home_position()
        _log("home_before", command_id=command_id, home=home_before)

        requested_position = {"latitude": position["latitude"], "longitude": position["longitude"]}
        overall_deadline = (
            time.time() + _ACK_TIMEOUT_S * _ACK_MAX_RETRIES + _HOME_TIMEOUT_S * _HOME_MAX_RETRIES + 2.0
        )

        ack_envelope, ack_error = _wait_for_set_home_ack(overall_deadline)
        if ack_envelope is None:
            _log("ack_result", command_id=command_id, result="TIMEOUT")
            _log("final_result", command_id=command_id, status="failed", reason="ACK_TIMEOUT")
            return _result(False, False, command_id, "ACK_TIMEOUT", ack_error,
                            requested_position=requested_position)

        ack_result = _decode_enum(ack_envelope["message"].get("result"))
        _log("ack_result", command_id=command_id, result=ack_result)
        if ack_result != _ACK_ACCEPTED:
            _log("final_result", command_id=command_id, status="failed", reason="ACK_REJECTED")
            return _result(False, False, command_id, "ACK_REJECTED",
                            f"Pixhawk rejected MAV_CMD_DO_SET_HOME: {ack_result}",
                            requested_position=requested_position, ack_result=ack_result)

        home_envelope, home_error = _wait_for_updated_home(overall_deadline)
        if home_envelope is None:
            _log("final_result", command_id=command_id, status="failed", reason="HOME_POSITION_TIMEOUT")
            return _result(False, False, command_id, "HOME_POSITION_TIMEOUT", home_error,
                            requested_position=requested_position, ack_result=ack_result)

        try:
            home_msg = home_envelope["message"]
            home_after = {
                "latitude": round(home_msg["latitude"] / 1e7, 7),
                "longitude": round(home_msg["longitude"] / 1e7, 7),
                "altitude": round(home_msg["altitude"] / 1000.0, 3),
            }
        except (KeyError, TypeError):
            _log("final_result", command_id=command_id, status="failed", reason="HOME_POSITION_MALFORMED")
            return _result(False, False, command_id, "HOME_POSITION_TIMEOUT",
                            "Updated HOME_POSITION reply was malformed.",
                            requested_position=requested_position, ack_result=ack_result)

        _log("home_after", command_id=command_id, home=home_after)

        distance = _haversine_m(
            requested_position["latitude"], requested_position["longitude"],
            home_after["latitude"], home_after["longitude"],
        )
        _log("verification_distance", command_id=command_id, distance_m=round(distance, 2))

        if distance > tolerance_m:
            _log("final_result", command_id=command_id, status="failed", reason="VERIFICATION_TOLERANCE_EXCEEDED")
            return _result(False, False, command_id, "VERIFICATION_TOLERANCE_EXCEEDED",
                            f"Updated HOME_POSITION is {distance:.1f}m from the requested position, "
                            f"exceeding the {tolerance_m:.1f}m tolerance.",
                            requested_position=requested_position, home_position=home_after,
                            verification_distance_m=round(distance, 2), ack_result=ack_result)

        _mark_verified(command_id, home_after, round(distance, 2))
        _log("final_result", command_id=command_id, status="success", distance_m=round(distance, 2))
        return _result(True, True, command_id, requested_position=requested_position, home_position=home_after,
                        verification_distance_m=round(distance, 2), ack_result=ack_result)


def get_home_status() -> dict:
    """
    GET /agent/home_status -- current Home verification/readiness, for the
    operator to confirm before starting AUTO or relying on RTL. Also
    opportunistically re-evaluates the invalidation triggers (reboot, Home
    drift) so a status poll can surface a lost verification even if nothing
    else calls set_home_current_position() again.
    """
    reachable = mavlink2rest_reachable()
    if not reachable:
        return {
            "reachable": False,
            "vehicle_position": None,
            "home_position": None,
            "distance_from_vehicle_m": None,
            "verified": _verified,
            "verified_at": _verified_at,
            "verification_method": "set_home_current_position" if _verified else None,
            "verification_distance_m": _verified_distance_m if _verified else None,
            "ready_for_auto": False,
            "ready_for_rtl": False,
            "reason": "mavlink2rest/Pixhawk is not reachable.",
        }

    with _lock:
        pos_envelope = _safe_get(_GLOBAL_POSITION_INT_PATH)
        vehicle_position = None
        time_boot_ms = None
        if pos_envelope is not None:
            try:
                msg = pos_envelope["message"]
                epoch = last_update_epoch(pos_envelope)
                vehicle_position = {
                    "latitude": round(msg["lat"] / 1e7, 7),
                    "longitude": round(msg["lon"] / 1e7, 7),
                    "age_s": round(time.time() - epoch, 3) if epoch is not None else None,
                }
                time_boot_ms = msg.get("time_boot_ms")
            except (KeyError, TypeError):
                vehicle_position = None

        _check_reboot(time_boot_ms)

        home = _fetch_home_position()
        home_position = None
        if home is not None:
            home_epoch = last_update_epoch(_safe_get(_HOME_POSITION_PATH))
            home_position = dict(home)
            home_position["age_s"] = round(time.time() - home_epoch, 3) if home_epoch is not None else None
            home_position["source"] = "pixhawk"

        _check_home_drift(home)

        distance = None
        if vehicle_position is not None and home is not None:
            distance = round(_haversine_m(
                vehicle_position["latitude"], vehicle_position["longitude"],
                home["latitude"], home["longitude"],
            ), 2)

        reason = None
        if not _verified:
            reason = "Home has not been verified this runtime -- perform Set Home Here before AUTO/RTL/RESUME."
        elif home_position is None:
            reason = "HOME_POSITION is not currently available from the Pixhawk."

        ready = _verified and home_position is not None

        return {
            "reachable": True,
            "vehicle_position": vehicle_position,
            "home_position": home_position,
            "distance_from_vehicle_m": distance,
            "verified": _verified,
            "verified_at": _verified_at,
            "verification_method": "set_home_current_position" if _verified else None,
            "verification_distance_m": _verified_distance_m if _verified else None,
            "ready_for_auto": ready,
            "ready_for_rtl": ready,
            "reason": reason,
        }


def is_ready_for_auto_or_rtl():
    """Convenience boolean+reason for app.py's /nav/AutoModeOn, /nav/rtl,
    /nav/resume gates -- LOITER/MANUAL/HOLD/PAUSE/ARM/DISARM must never call
    this (see module docstring and app.py's /nav/loiter, /nav/hold,
    /nav/manual, which never do)."""
    status = get_home_status()
    return status["ready_for_auto"], status["reason"]
