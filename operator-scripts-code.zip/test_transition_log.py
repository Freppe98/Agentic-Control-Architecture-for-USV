"""
Standalone tests for transition_log.py -- the rolling communication/mission/
authority transition audit trail. No pytest dependency:

    python3 test_transition_log.py
"""
import unittest

import transition_log


class TestTransitionLog(unittest.TestCase):
    def setUp(self):
        transition_log._transitions.clear()

    def test_empty_log_has_no_last_transition(self):
        self.assertIsNone(transition_log.last())

    def test_record_transition_is_retrievable(self):
        transition_log.record_transition("communication", "CONNECTED", "PARTITIONED", "Heartbeat timeout")
        entry = transition_log.last()
        self.assertEqual(entry["type"], "communication")
        self.assertEqual(entry["from"], "CONNECTED")
        self.assertEqual(entry["to"], "PARTITIONED")
        self.assertEqual(entry["reason"], "Heartbeat timeout")
        self.assertIn("timestamp", entry)

    def test_get_recent_returns_in_order(self):
        transition_log.record_transition("mission", "IDLE", "TRANSIT", "Mission activated")
        transition_log.record_transition("mission", "TRANSIT", "SEARCH", "First waypoint reached")
        recent = transition_log.get_recent()
        self.assertEqual([e["to"] for e in recent], ["TRANSIT", "SEARCH"])

    def test_log_bounded_to_max_transitions(self):
        for i in range(transition_log.MAX_TRANSITIONS + 20):
            transition_log.record_transition("mission", str(i), str(i + 1), "test")
        self.assertEqual(len(transition_log.get_recent()), transition_log.MAX_TRANSITIONS)
        # oldest entries are dropped, not the newest
        self.assertEqual(transition_log.last()["to"], str(transition_log.MAX_TRANSITIONS + 20))


if __name__ == "__main__":
    unittest.main(verbosity=2)
