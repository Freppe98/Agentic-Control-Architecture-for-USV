#VPN alive?

#RTT

#Packet loss

#CONNECTED

#PARTITIONED

#DISCONNECTED

import subprocess
import requests
from config import OPERATOR_URLS, OPERATOR_CONNECT_TIMEOUT

_vpn_check_warned = False


def internet_ok():
    return subprocess.run(
        ["ping", "-c", "1", "-W", "1", "8.8.8.8"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    ).returncode == 0


def vpn_ok():
    global _vpn_check_warned
    # `wg show` needs root; the calling user has passwordless sudo for this on Scout.
    result = subprocess.run(["sudo", "-n", "wg", "show"], capture_output=True, text=True)
    if result.returncode != 0 and not _vpn_check_warned:
        # Distinguish "the command itself failed" (e.g. passwordless sudo
        # isn't set up on this Pi) from "no handshake" -- otherwise this
        # silently misreports every PARTITIONED period as DISCONNECTED.
        _vpn_check_warned = True
        print(
            f"[COMM] 'sudo -n wg show' failed (rc={result.returncode}) "
            f"stderr={result.stderr.strip()!r} -- check passwordless sudo "
            "is configured for wg on this Pi; PARTITIONED will misreport "
            "as DISCONNECTED until this is fixed."
        )
    return "latest handshake" in result.stdout


def operator_ok():
    for url in OPERATOR_URLS:
        try:
            r = requests.get(f"{url}/agent/status", timeout=OPERATOR_CONNECT_TIMEOUT)
            if r.status_code < 500:
                return True
        except Exception:
            pass
    return False


def get_comm_state():
    if operator_ok():
        return "CONNECTED"

    if not internet_ok():
        return "DISCONNECTED"

    if vpn_ok():
        return "PARTITIONED"

    return "DISCONNECTED"


class CommunicationMonitor:
    """
    Tracks the Local Agent's own perceived communication state over time.

    The reported comm_state is always one of CONNECTED / PARTITIONED /
    DISCONNECTED -- that is the model. RECOVERED is not a persisted state,
    it is the edge of transitioning back into CONNECTED after having been
    PARTITIONED or DISCONNECTED, exposed via `just_recovered` so the caller
    can trigger a one-time backlog flush.
    """

    def __init__(self):
        self.state = None
        self.previous_state = None
        self.just_recovered = False

    def poll(self) -> str:
        self.previous_state = self.state
        current = get_comm_state()

        self.just_recovered = (
            self.previous_state in ("PARTITIONED", "DISCONNECTED")
            and current == "CONNECTED"
        )
        self.state = current
        return current