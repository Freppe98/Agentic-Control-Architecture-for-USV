import os

USV_ID = "usv-2"
USV_NAME = "Scout"

LOCAL_FLASK_URL = "http://127.0.0.1:8080"

# Fallback operator endpoints, used only if neither of the overrides below
# is set. Keep these in sync with whichever operator station is the
# "default" one, but don't rely on editing this list for day-to-day
# switching -- use OPERATOR_URLS env var or local_config.py instead.
DEFAULT_OPERATOR_URLS = [
    "http://10.0.0.23:8200",  # desktop (known working)
    "http://10.0.0.24:8200",  # laptop
]


def _parse_operator_urls(value: str):
    return [u.strip() for u in value.split(",") if u.strip()]


def _load_operator_urls():
    """
    Resolve OPERATOR_URLS without requiring a source edit per machine.

    Precedence (highest wins):
      1. OPERATOR_URLS environment variable, comma-separated
      2. local_config.py (gitignored, machine-specific, see
         local_config.example.py)
      3. DEFAULT_OPERATOR_URLS above
    """
    env_value = os.environ.get("OPERATOR_URLS")
    if env_value:
        return _parse_operator_urls(env_value), "environment (OPERATOR_URLS)"

    try:
        import local_config
        local_urls = getattr(local_config, "OPERATOR_URLS", None)
        if local_urls:
            return list(local_urls), "local_config.py"
    except ImportError:
        pass

    return list(DEFAULT_OPERATOR_URLS), "default (config.DEFAULT_OPERATOR_URLS)"


OPERATOR_URLS, OPERATOR_URLS_SOURCE = _load_operator_urls()

CONNECTED_INTERVAL = 1
PARTITIONED_INTERVAL = 10
DISCONNECTED_INTERVAL = 5

OPERATOR_CONNECT_TIMEOUT = 2
OPERATOR_READ_TIMEOUT = 3

# Inbound HTTP server the operator station polls for on-demand diagnostics/
# system_check (GET /agent/diagnostics, POST /agent/system_check) -- separate
# from LOCAL_FLASK_URL above, which is the vehicle Flask service the Local
# Agent calls *out* to. Read-only surface only; see agent_server.py.
LOCAL_AGENT_HTTP_HOST = os.environ.get("LOCAL_AGENT_HTTP_HOST", "0.0.0.0")
LOCAL_AGENT_HTTP_PORT = int(os.environ.get("LOCAL_AGENT_HTTP_PORT", "8090"))

BUFFER_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "agent_buffer.jsonl")

# Upper bound on how many undelivered messages buffer.py will hold. Without
# a cap, a send that fails for a reason that will never resolve on its own
# (e.g. the operator backend 404/405ing a real endpoint -- a route mismatch,
# not a connectivity gap) would grow agent_buffer.jsonl without bound, since
# buffer.py's own flush retries forever and never ages anything out. Once
# full, buffer_message() drops the oldest entries first -- the most recent
# backlog is more useful to a reconnecting operator than the oldest.
MAX_BUFFERED_MESSAGES = 500

# Persisted record of operator command_ids already processed, so a command
# re-delivered by the operator backend (e.g. re-queued after a poll retry)
# is never executed twice. Only the most recent N ids are kept -- commands
# carry their own expires_at, so we only need enough history to catch a
# retry of a recently-issued command, not a full audit log.
COMMAND_LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "command_log.jsonl")
MAX_TRACKED_COMMAND_IDS = 200

# Persisted authoritative terminal result per operator command_id -- the
# actual command_result payload (status/reason/result/lifecycle), not just
# the bare id COMMAND_LOG_FILE tracks. Lets a redelivered command_id resend
# the exact original result (see command_results.py) instead of fabricating
# a fresh generic "duplicate" rejection on every poll. Survives a Local
# Agent restart, same as COMMAND_LOG_FILE. Entries are removed once the
# operator backend has successfully acknowledged receipt, not on any fixed
# expiry.
COMMAND_RESULTS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "command_results.json")

# Decision engine thresholds (decision_engine.py) -- drive current_decision
# and watch_conditions. Battery/GPS numbers match the WARNING/FAIL tiers the
# vehicle Flask service's own diagnostics already use
# (services/diagnostics_service.py: battery WARNING <=30%, GPS FAIL below a
# 2D fix) so the same number doesn't mean two different things on two sides
# of the same status payload.
BATTERY_RTL_THRESHOLD_PERCENT = 30
GPS_MIN_FIX_TYPE = 2  # ArduPilot GPS_FIX_TYPE: 0/1=no fix, 2=2D, 3=3D+
# Mirrors services/mavlink_health.py's HEARTBEAT_TIMEOUT_S on the vehicle
# Flask side (same 1Hz-nominal/3-missed-periods convention). Used only to
# label the watch condition's threshold value -- mavlink_connected itself is
# trusted as-is from payload.mavlink, not recomputed here.
MAVLINK_HEARTBEAT_TIMEOUT_S = 3.0