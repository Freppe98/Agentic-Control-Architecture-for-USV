"""
Flask Application
Uses HTTP clients to communicate with GPIO and Sensor services
Runs with gunicorn (1 worker, gthread, multiple threads)
"""
from flask import Flask, render_template, current_app, g, jsonify, request, send_file, send_from_directory, abort, Response
from flask_cors import CORS
from flask_socketio import SocketIO, emit
from pathlib import Path
import time
import requests
import traceback
import datetime
import os
import shutil
import zipfile
import tempfile

import sys
import os
import json
import socket

import services.state as scout_state
from services.event_log import add_event
from services.agent_state import build_agent_state, init as init_agent_state
from services import diagnostics_service
from services import mission_service
from services import set_home_service
from services import mode_verification
from routes.agent_routes import agent_bp
from shapely.geometry import Polygon, LineString
from shapely.ops import transform
import pyproj
import numpy as np

# Add parent directory (project root) to path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(os.path.dirname(current_dir))
sys.path.insert(0, parent_dir)

BASE_DIR = Path(__file__).resolve().parent  
TEMPLATE_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

from influxdbData import influxdb
from dataAnalysis.MissionReport.map_plots_influx import MissionReport
from other import LEDstrip

# Configuration
SENSOR_SERVICE_URL = os.getenv('SENSOR_SERVICE_URL', 'http://sensor-service:6001')
GPIO_SOCKET_PATH = "/run/gpio/gpio_socket"  # Unix socket for GPIO (shared volume)

# RealSense camera streams (running on host, accessed via host.docker.internal)
REALSENSE_RGB_URL = os.getenv('REALSENSE_RGB_URL', 'http://host.docker.internal:5001/video_feed')
REALSENSE_DEPTH_URL = os.getenv('REALSENSE_DEPTH_URL', 'http://host.docker.internal:5002/video_feed')

# Global state
take_sensitive_measurements = False
take_Any_Measurements = True
lightEnabled = False
mission_active = False
current_mission_id = None

# Time between each measurement in seconds
measurementDelay = 1

cords = {
    "lat": None,
    "lon": None,
    "timeStamp": None
}

# Configure Flask to look for templates and static files in the project root

app = Flask(
    __name__,
    template_folder=str(TEMPLATE_DIR),
    static_folder=str(STATIC_DIR),
)
CORS(app)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, async_mode='threading', cors_allowed_origins="*")
app.register_blueprint(agent_bp)

influx = influxdb.InfluxdbManager()
ledStrip = LEDstrip.LEDStripManager()

# Sampler flags: 0 = unused, 1 = in use, 2 = used
araryofsamplerflags = [0, 0, 0, 0]

# Panel Communications
cameraMode = 0

# --- RealSense TCP client configuration ---
REALSENSE_HOST = "host.docker.internal"  # Use this if container; '127.0.0.1' if running on host
REALSENSE_RGB_PORT = 5001
REALSENSE_DEPTH_PORT = 5002

#--- Saved Mission File
MISSIONS_DIR = BASE_DIR / "saved_missions"
MISSIONS_DIR.mkdir(exist_ok=True)

def tcp_frame_generator(host, port):
    """TCP client to receive JPEG frames from host RealSense service."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    while True:
        # Read length of the incoming frame
        raw_len = s.recv(4)
        if not raw_len:
            continue
        msg_len = struct.unpack(">L", raw_len)[0]

        # Read the frame data
        data = b''
        while len(data) < msg_len:
            packet = s.recv(msg_len - len(data))
            if not packet:
                break
            data += packet

        # Yield for HTTP MJPEG streaming
        yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + data + b'\r\n')

def call_sensor_service(endpoint, method='GET', json_data=None):
    """Helper function to call sensor service with error handling"""
    try:
        url = f"{SENSOR_SERVICE_URL}{endpoint}"
        if method == 'GET':
            response = requests.get(url, timeout=5)
        elif method == 'POST':
            response = requests.post(url, json=json_data, timeout=10)
        else:
            return None
        
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error calling sensor service {endpoint}: {e}")
        return None
    except Exception as e:
        print(f"Unexpected error calling sensor service: {e}")
        traceback.print_exc()
        return None


def call_gpio_service(command, retries=3, delay=0.5):
    """Helper function to call GPIO service via Unix socket with error handling"""
    import socket
    for attempt in range(retries):
        client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        client.settimeout(3.0)
        try:
            client.connect(GPIO_SOCKET_PATH)
            client.sendall(command.encode('utf-8'))
            response = client.recv(128)
            return response.decode('utf-8')
        except socket.timeout:
            if attempt < retries - 1:
                time.sleep(delay)
                continue
            return "Timeout occurred"
        except ConnectionRefusedError:
            if attempt < retries - 1:
                time.sleep(delay)
                continue
            return "Connection refused after retries"
        except Exception as e:
            print(f"Error calling GPIO service: {e}")
            if attempt < retries - 1:
                time.sleep(delay)
                continue
            return f"Error: {str(e)}"
        finally:
            try:
                client.close()
            except:
                pass
    return "Failed after retries"


def gpio_set_pin(pin_name, state):
    """Set GPIO pin state"""
    msg = f"S{1 if state else 0}{pin_name}"
    return call_gpio_service(msg)


def samplerLoop():
    """Loop to handle sampler activation requests"""
    print("Starting samplerLoop")
    global araryofsamplerflags
    while True:
        try:
            time.sleep(1)
            for i in range(len(araryofsamplerflags)):
                if araryofsamplerflags[i] == 1:
                    print(f"Running activate sampler {i}")
                    try:
                        result = call_sensor_service('/sampler/activate', method='POST', 
                                                    json_data={'sampler_number': i})
                        if result and result.get('status') == 'success':
                            hardware_activated = result.get('hardware_activated', True)
                            if hardware_activated:
                                print(f"Sampler {i} activated successfully (hardware)")
                                araryofsamplerflags[i] = 2
                                add_event('SAMPLER_ACTIVATED', {'sampler': i})
                            else:
                                reason = result.get('reason', 'unknown')
                                print(f"WARNING: Sampler {i} request succeeded but hardware NOT activated. Reason: {reason}")
                                araryofsamplerflags[i] = 0  # Reset so user can try again
                        else:
                            print(f"Failed to activate sampler {i}")
                            araryofsamplerflags[i] = 0  # Reset on failure
                    except Exception as e:
                        print(f"Error in activate_sampler({i}): {e}")
                        traceback.print_exc()
                        araryofsamplerflags[i] = 0
        except Exception as e:
            print(f"Error in samplerLoop iteration: {e}")
            traceback.print_exc()
            time.sleep(1)


def MeasuringLoop():
    """Main measurement loop"""
    print("Starting measurement loop")
    global influx, measurementDelay, take_sensitive_measurements, cords, current_mission_id
    while True:
        try:
            loop_start = time.time()
            if not take_Any_Measurements or not take_sensitive_measurements:
                time.sleep(1)
                continue

            # Get measurements from sensor service
            result = call_sensor_service('/measurements', method='POST',
                                       json_data={
                                           'sensitive_measurements': take_sensitive_measurements,
                                           'mission_id': current_mission_id
                                       })

            if not result:
                print("Failed to get measurements from sensor service")
                time.sleep(measurementDelay)
                continue

            data = result

            # Update measurement cache for build_agent_state()
            scout_state.latest_measurements['temperature']  = data.get('temperature')
            scout_state.latest_measurements['ph']           = data.get('ph')
            scout_state.latest_measurements['conductivity'] = data.get('conductivity')
            scout_state.latest_measurements['turbidity']    = data.get('turbidity')
            scout_state.latest_measurements['last_sample']  = round(time.time(), 2)
            
            # Other data to be sent to the front end
            data["sensorsEnabled"] = take_sensitive_measurements
            data["latitude"] = cords["lat"]
            data["longitude"] = cords["lon"]

            # The timestamp is no longer used as influxdb handles that
            if "timestamp" in data and isinstance(data["timestamp"], str):
                pass  # Already a string
            elif "timestamp" in data:
                data["timestamp"] = data["timestamp"].strftime("%Y-%m-%d %H:%M:%S")

            # Save the measurements to the database
            # try:
            #     if influx:
            #         influx.SavePoint(data, mission_id=current_mission_id)
            # except Exception as e:
            #     print(f"Error saving to InfluxDB: {e}")
            #     traceback.print_exc()

            # The front end expects a matrix so more datapoints can be sent at the same time
            data = [data]
            
            # Send the new data to the frontend
            if socketio.server.manager.get_participants('/', '/'):
                socketio.emit('response_data', data)
                print("Taking and sending new measurements")
            else:
                print("No clients connected, skipping emit")

        except Exception as e:
            print(f"Error in measurement Loop iteration: {e}")
            traceback.print_exc()

        # Wait before taking the next measurement
        time.sleep(measurementDelay)

        loop_duration = time.time() - loop_start
        print(f"Measurement loop iteration took {loop_duration:.2f} seconds")


##Socket connection to front end
@socketio.on('connect')
def handle_connect(auth):
    print("Browser Connected to backend")


# Gets a command from the web browser
@socketio.on('webCommand')
def webCommand(command, value):
    global take_sensitive_measurements, cameraMode, buzzerEnabled, ledStrip
    if (command == None or value == None):
        print("Invalid Command received")
        log = ["Error", None, "Backend received an invalid request"]
        SendLogToFrontEnd(log=log)
        return
    print(f'Set {str(command)} to {str(value)}')

    if(command == 'toggleSensors'):
        log = ["Info", None, ""]
        try:
            if(value == 1):
                take_sensitive_measurements = True
                gpio_set_pin("Sensors", True)
                log[2] = "Sensors enabled"
                add_event('SENSORS_ENABLED')
            else:
                take_sensitive_measurements = False
                log[2] = "Sensors disabled"
                gpio_set_pin("Sensors", False)
                add_event('SENSORS_DISABLED')
        except Exception as e:
            print(f"Error toggling sensors: {e}")
            traceback.print_exc()
            log[2] = f"Error: {str(e)}"
        SendLogToFrontEnd(log=log)
    
    elif(command == 'toggleMission'):
        log = ["Info", None, ""]
        if(value == 1):
            log[2] = "Mission recording started"
        else:
            log[2] = "Mission recording stopped"
        SendLogToFrontEnd(log=log)
    
    elif(command == 'Buzzer'):
        log = ["Info", None, ""]
        try:
            if(value == 1):
                lightEnabled = True
                gpio_set_pin("Light", True)
                log[2] = "Light Enabled"
            else:
                lightEnabled = False
                gpio_set_pin("Light", False)
                log[2] = "Light Disabled"
        except Exception as e:
            print(f"Error toggling light: {e}")
            traceback.print_exc()
        SendLogToFrontEnd(log=log)

    elif(command == 'toggleLed'):
        log = ["Info", None, ""]
        try:
            if (value == 1):
                log[2] = "Led Enabled"
                ledStrip.StartLightThread()
            elif (value == 0):
                log[2] = "Led Disabled"
                ledStrip.StopLightThread()
        except Exception as e:
            print(f"Error toggling LED: {e}")
            traceback.print_exc()
            log[2] = f"Error: {str(e)}"
        SendLogToFrontEnd(log=log)


@socketio.on('request_log')
def SendLogToFrontEnd(log=None):
    if log in (None, {}, ''):
        currentDateAndTime = datetime.datetime.now()
        time = currentDateAndTime.strftime("%H:%M:%S")
        log = ["Info", time, "Connected To Backend"]

    if (log[1] == None or log[1].lower() == "now"):
        log[1] = datetime.datetime.now().strftime("%H:%M:%S")

    emit('response_Log', log)


# Send data from a day to webpage
@socketio.on('request_data')
def sendData(arg=None):
    global influx
    if arg in (None, {}, ''):
        arg = {}
    
    day = arg.get('date', 'today')
    
    try:
        # Read data points from InfluxDB (last 10 minutes by default, or specified time range)
        time_minutes = arg.get('minutes', 10) if isinstance(arg, dict) else 10
        tables = influx.ReadDataPoints(time_minutes)
        
        # Convert InfluxDB tables to dashboard format
        # InfluxDB returns data in a pivoted format where each record has _time, _field, _value
        # We need to group by _time and create one object per timestamp with all fields
        data_points_dict = {}
        
        if tables:
            for table in tables:
                for record in table.records:
                    # Get timestamp, field name, and value
                    timestamp = record.values.get('_time')
                    field = record.values.get('_field')
                    value = record.values.get('_value')
                    
                    # Convert timestamp to string key for grouping
                    if isinstance(timestamp, datetime.datetime):
                        timestamp_str = timestamp.strftime("%Y-%m-%d %H:%M:%S")
                    elif hasattr(timestamp, 'strftime'):
                        timestamp_str = timestamp.strftime("%Y-%m-%d %H:%M:%S")
                    else:
                        timestamp_str = str(timestamp)
                    
                    # Get or create data point for this timestamp
                    if timestamp_str not in data_points_dict:
                        data_points_dict[timestamp_str] = {'timestamp': timestamp_str}
                    
                    # Add field value to point (skip internal InfluxDB fields)
                    if field and not field.startswith('_'):
                        data_points_dict[timestamp_str][field] = value
            
            # Convert to list and sort by timestamp
            data_points = list(data_points_dict.values())
            data_points.sort(key=lambda x: x.get('timestamp', ''))
            
            # Send data to frontend (frontend expects array format)
            if data_points:
                socketio.emit('response_data', data_points)
                print(f"Sent {len(data_points)} historical data points to dashboard")
            else:
                print("No historical data found")
                # Send empty array so frontend knows request completed
                socketio.emit('response_data', [])
    except Exception as e:
        print(f"Error reading data points: {e}")
        traceback.print_exc()
        # Send error message to frontend (frontend will handle empty array or error)
        try:
            socketio.emit('response_data', [])
        except:
            pass


# Request what days have databases
@socketio.on('request_history')
def SendDataBaseList():   
    return "1"


@app.route('/panel', methods=['POST'])
def panel():
    global cords
    try:
        data = request.get_json()
        cords["lat"] = data.get("lat")
        cords["lon"] = data.get("lon")
        cords["timeStamp"] = data.get("cordTime")

        ret = {}
        ret["CameraMode"] = cameraMode
        
        return jsonify(ret)
    except Exception as e:
        print(f"Error in panel endpoint: {e}")
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


@app.route("/")
def home():
    return render_template('index.html')

def proxy_mjpeg_stream(url):
    """Proxy an MJPEG stream from the host RealSense service."""
    try:
        response = requests.get(url, stream=True, timeout=10)
        response.raise_for_status()
        
        def generate():
            try:
                for chunk in response.iter_content(chunk_size=4096):
                    if chunk:
                        yield chunk
            except Exception as e:
                print(f"Stream proxy error: {e}")
            finally:
                response.close()
        
        return Response(
            generate(),
            mimetype='multipart/x-mixed-replace; boundary=frame',
            headers={
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Access-Control-Allow-Origin': '*'
            }
        )
    except requests.exceptions.RequestException as e:
        print(f"Failed to connect to camera stream at {url}: {e}")
        return jsonify({"error": "Camera stream unavailable"}), 503


@app.route('/camera/rgb')
def camera_rgb():
    """Proxy MJPEG stream for RGB frames from host RealSense service."""
    return proxy_mjpeg_stream(REALSENSE_RGB_URL)


@app.route('/camera/depth')
def camera_depth():
    """Proxy MJPEG stream for Depth frames from host RealSense service."""
    return proxy_mjpeg_stream(REALSENSE_DEPTH_URL)


# Extracting data from InfluxDB for download past 12h
@app.route('/getdata')
def getdata():
    global influx
    try:
        influx.getdatabase()
        data_dir = os.path.join(current_app.root_path, 'data')
        filename = 'data_download.txt'
        return send_from_directory(directory=data_dir, path=filename, as_attachment=True)
    except Exception as e:
        print(f"Error executing function: {e}")
        traceback.print_exc()
        return str(e), 500


# Adding custom Mission ID for filtering
@app.route('/start_mission', methods=['POST'])
def start_mission():
    global mission_active, current_mission_id
    try:
        data = request.get_json()
        name = data.get("name", "Unnamed")
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M")
        current_mission_id = f"{timestamp}_{name}"
        mission_active = True
        add_event('MISSION_STARTED', {'mission_id': current_mission_id})
        print(f"Mission started: {current_mission_id}")
        return "Mission started", 200
    except Exception as e:
        print(f"Error starting mission: {e}")
        traceback.print_exc()
        return str(e), 500


@app.route('/stop_mission', methods=['POST'])
def stop_mission():
    global mission_active, current_mission_id
    try:
        add_event('MISSION_STOPPED')
        mission_active = False
        current_mission_id = None
        print("Mission stopped")
        return "Mission stopped", 200
    except Exception as e:
        print(f"Error stopping mission: {e}")
        traceback.print_exc()
        return str(e), 500


# Show all Missions in the dropdown menu
@app.route('/get_missions')
def get_missions():
    try:
        mission_ids = influx.get_all_mission_ids()
        return jsonify(mission_ids)
    except Exception as e:
        print(f"Error in /get_missions route: {e}")
        traceback.print_exc()
        return jsonify([]), 500


# Start Download of selected Mission by saving file in "data" and sending it to frontend
@app.route('/download_mission')
def download_mission():
    try:     
        mission_id = request.args.get('id')
        if not mission_id:
            return 'Missing mission ID', 400

        filename1 = f"{mission_id}.txt"
        data_dir = os.path.join(current_app.root_path, 'data')
        file1 = os.path.join(data_dir, filename1)
        output_report_path = os.path.join(data_dir, f"{mission_id}_Mission_Report.docx")

        if not os.path.isfile(file1) or not os.path.isfile(output_report_path):
            if not os.path.isfile(file1):
                influx.GetMissionData(mission_id)
            MissionReport(data_file_path=file1, output_report_path=output_report_path)

        if not os.path.isfile(file1) or not os.path.isfile(output_report_path):
            return abort(404, description="One or both files not found.")
        
        # Create a temporary zip file
        with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp_zip:
            with zipfile.ZipFile(tmp_zip, 'w') as zf:
                zf.write(file1, arcname=filename1)
                zf.write(output_report_path, arcname=os.path.basename(output_report_path))
            zip_path = tmp_zip.name

        return send_from_directory(directory=os.path.dirname(zip_path), path=os.path.basename(zip_path), as_attachment=True, download_name=f"{mission_id}_AqualityONE_data.zip")

    except Exception as e:
        print(f"Error in /download_mission: {e}")
        traceback.print_exc()
        return str(e), 500


# Get the ID from the Dome Cam button
@app.route("/rotate_dome_cam")
def dome_cam():
    global dcm
    try:
        cam_direction = request.args.get('id')
        
        if cam_direction in ['LL', 'L', 'C', 'R', 'RR']:
            result = call_sensor_service('/dome/rotate', method='POST',
                                        json_data={'direction': cam_direction})
            if result and result.get('status') == 'success':
                print(f"Dome camera rotated to {cam_direction}")
            else:
                print(f"Failed to rotate dome camera: {result}")
        else:
            print("Invalid direction")
        
        return jsonify({"status": "success", "direction": cam_direction}), 200
    except Exception as e:
        print(f"Error rotating dome camera: {e}")
        traceback.print_exc()
        return jsonify({"status": "error", "message": "Failed to rotate"}), 500


# Get the ID from every Sample button
@app.route("/control_sampler") 
def sampeler():
    try:
        sample_number = request.args.get('id')
        sample_number = int(sample_number)
        
        if(araryofsamplerflags[sample_number] == 2 or araryofsamplerflags[sample_number] == 1):
            return jsonify({"status": "already_in_use", "sampler": sample_number}), 200

        araryofsamplerflags[sample_number] = 1
        
        return jsonify({"status": "queued", "sampler": sample_number}), 200
    except Exception as e:
        print(f"Error controlling sampler: {e}")
        traceback.print_exc()
        return jsonify({"status": "error", "error": str(e)}), 500


# Get the ID from the Reload button and set array to 0,0,0,0
@app.route("/reload_sampler")
def reload_sampler():
    global araryofsamplerflags, influx
    try:
        araryofsamplerflags = [0, 0, 0, 0]
        if influx:
            influx.SavePoint({"sampler0": 0, "sampler1": 0, "sampler2": 0, "sampler3": 0})
        return jsonify({"status": "success", "message": "Samplers reloaded"}), 200
    except Exception as e:
        print(f"Error reloading sampler: {e}")
        traceback.print_exc()
        return jsonify({"status": "error", "error": str(e)}), 500

# ── NAVIGATION (mavlink2rest) ─────────────────────
MAVLINK2REST = 'http://host.docker.internal:6040'

def mav_get(path):
    r = requests.get(f'{MAVLINK2REST}{path}', timeout=1.0)
    return r.json()

def mav_post(data):
    wrapped = {
        "header": {"system_id": 255, "component_id": 240, "sequence": 0},
        "message": data
    }
    r = requests.post(f'{MAVLINK2REST}/mavlink', json=wrapped, timeout=5)
    return r

def _get_app_state() -> dict:
    return {
        'mission_active':            mission_active,
        'current_mission_id':        current_mission_id,
        'take_sensitive_measurements': take_sensitive_measurements,
        'measurementDelay':          measurementDelay,
    }

init_agent_state(
    mav_get_fn=mav_get,
    sensor_url=SENSOR_SERVICE_URL,
    gpio_socket_path=GPIO_SOCKET_PATH,
    app_state_getter=_get_app_state,
)

diagnostics_service.init(
    mav_get_fn=mav_get,
    mavlink_base_url=MAVLINK2REST,
    realsense_rgb_url=REALSENSE_RGB_URL,
    realsense_depth_url=REALSENSE_DEPTH_URL,
    app_state_getter=_get_app_state,
)

mission_service.init(
    mav_get_fn=mav_get,
    mav_post_fn=mav_post,
    mavlink_base_url=MAVLINK2REST,
)

set_home_service.init(
    mav_get_fn=mav_get,
    mav_post_fn=mav_post,
    mavlink_base_url=MAVLINK2REST,
)

mode_verification.init(
    mav_get_fn=mav_get,
    mav_post_fn=mav_post,
)

@app.route('/nav/telemetry', methods=['GET'])
def nav_telemetry():
    try:
        return jsonify(build_agent_state()['telemetry'])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/nav/save_gps_log', methods=['GET'])
def save_gps_log():
    try:
        import csv
        filepath = BASE_DIR / 'gps_track.csv'
        with open(filepath, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['timestamp', 'lat', 'lng'])
            writer.writeheader()
            writer.writerows(scout_state.gps_log)
        return jsonify({
            'status': 'saved',
            'points': len(scout_state.gps_log),
            'file': str(filepath)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/nav/clear_gps_log', methods=['POST'])
def clear_gps_log():
    scout_state.gps_log.clear()
    return jsonify({'status': 'cleared'})

@app.route('/nav/set_param', methods=['POST'])
def nav_set_param():
    try:
        param_id = request.json.get('param_id')
        value = float(request.json.get('value'))
        
        # Safety limit for WP_SPEED
        if param_id == 'WP_SPEED' and value > 3.0:
            return jsonify({'error': 'Speed too high! Max 3.0 m/s'}), 400
        
        mav_post({
            'type': 'PARAM_SET',
            'param_id': param_id,
            'param_value': value,
            'param_type': 9,
            'target_system': 1,
            'target_component': 1
        })
        return jsonify({'status': 'success', 'param_id': param_id, 'value': value})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/nav/upload_mission', methods=['POST'])
def nav_upload_mission():
    try:
        import time as time_module
        start_time = time_module.time()
        mav_post({'type': 'COMMAND_LONG', 'param1': 0, 'param2': 0, 'param3': 0, 'param4': 0, 'param5': 0, 'param6': 0, 'param7': 0, 'command': {'type': 'MAV_CMD_COMPONENT_ARM_DISARM'}, 'target_system': 1, 'target_component': 1, 'confirmation': 0})
        geojson = request.json
        coords = geojson['features'][0]['geometry']['coordinates']
        loiter_times = geojson['features'][0]['properties'].get('loiter_times', [])
        mav_post({'type': 'MISSION_CLEAR_ALL', 'target_system': 1, 'target_component': 1, 'mission_type': {'type': 'MAV_MISSION_TYPE_MISSION'}})
        mav_post({'type': 'MISSION_COUNT', 'count': len(coords) + 1, 'target_system': 1, 'target_component': 1, 'mission_type': {'type': 'MAV_MISSION_TYPE_MISSION'}})
        mav_post({'type': 'MISSION_ITEM_INT', 'seq': 0, 'frame': {'type': 'MAV_FRAME_GLOBAL_RELATIVE_ALT'}, 'command': {'type': 'MAV_CMD_NAV_WAYPOINT'}, 'current': 1, 'autocontinue': 1, 'param1': 0, 'param2': 0, 'param3': 0, 'param4': 0, 'x': 0, 'y': 0, 'z': 0, 'target_system': 1, 'target_component': 1, 'mission_type': {'type': 'MAV_MISSION_TYPE_MISSION'}})
        for i, coord in enumerate(coords):
            lng, lat = coord[0], coord[1]
            loiter = loiter_times[i] if i < len(loiter_times) else 0
            mav_post({'type': 'MISSION_ITEM_INT', 'seq': i + 1, 'frame': {'type': 'MAV_FRAME_GLOBAL_RELATIVE_ALT'}, 'command': {'type': 'MAV_CMD_NAV_WAYPOINT'}, 'current': 0, 'autocontinue': 1, 'param1': loiter, 'param2': 0, 'param3': 0, 'param4': 0, 'x': int(lat * 1e7), 'y': int(lng * 1e7), 'z': 0, 'target_system': 1, 'target_component': 1, 'mission_type': {'type': 'MAV_MISSION_TYPE_MISSION'}})

        end_time = time_module.time()
        elapsed = round(end_time - start_time, 2)
        print(f"[TIMING] Mission upload took {elapsed} seconds for {len(coords)} waypoints")

        # ── Verify upload ─────────────────────────────────
        mav_post({
            'type': 'MISSION_REQUEST_LIST',
            'target_system': 1,
            'target_component': 1,
            'mission_type': {'type': 'MAV_MISSION_TYPE_MISSION'}
        })
        time.sleep(0.5)
        count_data = mav_get('/mavlink/vehicles/1/components/1/messages/MISSION_COUNT')
        actual_count = count_data['message']['count']
        expected_count = len(coords) + 1

        # Fetch all waypoints and check for duplicates
        fetched_seqs = []
        for seq in range(actual_count):
            mav_post({
                'type': 'MISSION_REQUEST_INT',
                'seq': seq,
                'target_system': 1,
                'target_component': 1,
                'mission_type': {'type': 'MAV_MISSION_TYPE_MISSION'}
            })
            time.sleep(0.05)
            item = mav_get('/mavlink/vehicles/1/components/1/messages/MISSION_ITEM_INT')
            fetched_seqs.append(item['message']['seq'])

        count_match = actual_count == expected_count
        unique = len(set(fetched_seqs)) == len(fetched_seqs)

        print(f"[VERIFY] expected={expected_count} actual={actual_count} count_match={count_match} unique={unique}")

        return jsonify({
            'status': 'success',
            'waypoints': len(coords),
            'upload_time_seconds': elapsed,
            'verification': {
                'expected': expected_count,
                'actual': actual_count,
                'count_match': count_match,
                'unique': unique
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Command types that navigate relative to, or return to, Pixhawk Home --
# an unverified (e.g. still-at-the-garage) Home would send the USV toward
# the wrong location under any of these. Checked via
# set_home_service.is_ready_for_auto_or_rtl() immediately before the mode
# change is ever sent; LOITER (/nav/loiter), MANUAL (/nav/manual), HOLD
# (/nav/hold), PAUSE (/nav/pause), ArmOn/Disarm never call this gate and
# must remain available regardless of Home verification -- see
# services/set_home_service.py module docstring.
def _require_verified_home():
    ready, reason = set_home_service.is_ready_for_auto_or_rtl()
    if not ready:
        return jsonify({'error': 'home_unverified', 'message': reason}), 409
    return None


@app.route('/nav/AutoModeOn', methods=['POST'])
def set_auto_mode():
    blocked = _require_verified_home()
    if blocked:
        return blocked
    try:
        return jsonify(mode_verification.set_mode_and_verify('AUTO'))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/nav/ArmOn', methods=['POST'])
def Arm_on():
    try:
        mav_post({
            'type': 'COMMAND_LONG',
            'param1': 1,
            'param2': 0,
            'param3': 0,
            'param4': 0,
            'param5': 0,
            'param6': 0,
            'param7': 0,
            'command': {'type': 'MAV_CMD_COMPONENT_ARM_DISARM'},
            'target_system': 1,
            'target_component': 1,
            'confirmation': 0
        })
        time.sleep(1)
        return jsonify({'status': 'Arm mode in on'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/nav/Disarm', methods=['POST'])  
def Disarm():
    try:
        mav_post({
            'type': 'COMMAND_LONG',
            'param1': 0,
            'param2': 0,
            'param3': 0,
            'param4': 0,
            'param5': 0,
            'param6': 0,
            'param7': 0,
            'command': {'type': 'MAV_CMD_COMPONENT_ARM_DISARM'},
            'target_system': 1,
            'target_component': 1,
            'confirmation': 0
        })
        time.sleep(1)
        return jsonify({'status': 'Arm mode in off'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
@app.route('/nav/start', methods=['POST'])
def nav_start():
    try:
        # Step 1: Disarm (clean state) -- ARM_DISARM, not a mode change, so
        # outside mode_verification's scope; unchanged.
        mav_post({'type': 'COMMAND_LONG', 'param1': 0, 'param2': 0, 'param3': 0, 'param4': 0, 'param5': 0, 'param6': 0, 'param7': 0, 'command': {'type': 'MAV_CMD_COMPONENT_ARM_DISARM'}, 'target_system': 1, 'target_component': 1, 'confirmation': 0})
        time.sleep(3)

        # Step 2: Set HOLD mode (clean mode before AUTO) -- the same shared
        # mode_verification every other mode route uses, not a fifth
        # hand-rolled COMMAND_LONG. Abort before arming if HOLD doesn't
        # actually verify -- proceeding to arm the vehicle on an unconfirmed
        # mode change would be exactly the "request sent != it happened"
        # mistake this whole module exists to catch.
        hold_result = mode_verification.set_mode_and_verify('HOLD')
        if not hold_result['verified']:
            return jsonify({'status': 'failed', 'stage': 'HOLD', 'result': hold_result}), 502
        time.sleep(1)

        # Step 3: Arm
        mav_post({'type': 'COMMAND_LONG', 'param1': 1, 'param2': 0, 'param3': 0, 'param4': 0, 'param5': 0, 'param6': 0, 'param7': 0, 'command': {'type': 'MAV_CMD_COMPONENT_ARM_DISARM'}, 'target_system': 1, 'target_component': 1, 'confirmation': 0})
        time.sleep(5)

        # Step 4: Set AUTO mode -- verified the same way; a mission must
        # never be reported "started" while the Pixhawk is still sitting in
        # HOLD/MANUAL because the AUTO request silently didn't take.
        auto_result = mode_verification.set_mode_and_verify('AUTO')
        if not auto_result['verified']:
            return jsonify({'status': 'failed', 'stage': 'AUTO', 'result': auto_result}), 502

        add_event('NAV_STARTED')
        return jsonify({'status': 'Mission started', 'hold': hold_result, 'auto': auto_result})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
@app.route('/nav/stop', methods=['POST'])
def nav_stop():
    try:
        # Disarm immediately
        mav_post({'type': 'COMMAND_LONG', 'param1': 0, 'param2': 0, 'param3': 0, 'param4': 0, 'param5': 0, 'param6': 0, 'param7': 0, 'command': {'type': 'MAV_CMD_COMPONENT_ARM_DISARM'}, 'target_system': 1, 'target_component': 1, 'confirmation': 0})
        add_event('NAV_STOPPED')
        return jsonify({'status': 'Stopped'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# RTL -- a request being sent is never reported as success here; see
# services/mode_verification.py's module docstring for the root cause this
# fixed and set_mode_and_verify()'s docstring for what accepted/verified
# actually mean.
@app.route('/nav/rtl', methods=['POST'])
def nav_rtl():
    blocked = _require_verified_home()
    if blocked:
        return blocked
    try:
        result = mode_verification.set_mode_and_verify('RTL')
        add_event('RTL_COMMANDED' if result['verified'] else 'RTL_NOT_VERIFIED', detail={'reason': result['reason']} if result['reason'] else None)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
@app.route('/mission')
def mission_planner():
    return send_from_directory(str(STATIC_DIR), 'index.html')

def compute_return_path(polygon_coords, spacing_meters, safety_meters, last_waypoint, home_coord, no_go_zones=None):
    from shapely.geometry import Point
    import heapq

    coords_deg = [(c[0], c[1]) for c in polygon_coords]
    if coords_deg[0] != coords_deg[-1]:
        coords_deg.append(coords_deg[0])
    poly_deg = Polygon(coords_deg)

    centroid = poly_deg.centroid
    utm_zone = int((centroid.x + 180) / 6) + 1
    hemi = 6 if centroid.y >= 0 else 7
    crs_proj = f"EPSG:32{hemi}{utm_zone:02d}"
    to_proj = pyproj.Transformer.from_crs("EPSG:4326", crs_proj, always_xy=True)
    to_deg  = pyproj.Transformer.from_crs(crs_proj, "EPSG:4326", always_xy=True)
    poly_proj = transform(to_proj.transform, poly_deg)

    if safety_meters > 0:
        poly_proj = poly_proj.buffer(-safety_meters)
        if poly_proj.is_empty:
            return []

    minx, miny, maxx, maxy = poly_proj.bounds
    step = spacing_meters
    cols = int((maxx - minx) / step) + 1
    rows = int((maxy - miny) / step) + 1

    # Grid: 0 = free (inside polygon), 1 = blocked (outside polygon)
    grid = []
    for r in range(rows):
        row = []
        y = miny + r * step
        for c in range(cols):
            x = minx + c * step
            row.append(0 if poly_proj.contains(Point(x, y)) else 1)
        grid.append(row)

    if no_go_zones:
        for zone_coords in no_go_zones:
            zone_deg = [(c[0], c[1]) for c in zone_coords]
            if zone_deg[0] != zone_deg[-1]:
                zone_deg.append(zone_deg[0])
            try:
                zone_poly = transform(to_proj.transform, Polygon(zone_deg))
                blocked_count = 0 
                for r in range(rows):
                    y = miny + r * step
                    for c in range(cols):
                        x = minx + c * step
                        if zone_poly.contains(Point(x, y)):
                            grid[r][c] = 1
                            blocked_count += 1
                print(f"[No-go] Blocked {blocked_count} cells for zone")
            except Exception:
                pass


    def to_grid(lng, lat):
        x, y = to_proj.transform(lng, lat)
        c = int(round((x - minx) / step))
        r = int(round((y - miny) / step))
        return r, c  # NOTE: no clamping, allows outside grid

    def to_coord(r, c):
        x = minx + c * step
        y = miny + r * step
        lng, lat = to_deg.transform(x, y)
        return [lng, lat]

    def is_free(r, c):
        # Outside grid bounds is allowed (drone is on shore)
        if r < 0 or r >= rows or c < 0 or c >= cols:
            return True
        return grid[r][c] == 0

    def nearest_free_inside(r, c):
        # Snap to nearest cell INSIDE the polygon
        if 0 <= r < rows and 0 <= c < cols and grid[r][c] == 0:
            return r, c
        for dist in range(1, max(rows, cols)):
            for dr in range(-dist, dist+1):
                for dc in range(-dist, dist+1):
                    nr, nc = r+dr, c+dc
                    if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] == 0:
                        return nr, nc
        return r, c

    def astar(start, goal):
        h = lambda a, b: abs(a[0]-b[0]) + abs(a[1]-b[1])
        open_set = [(h(start, goal), 0, start, None)]
        came_from = {}
        gscore = {start: 0}
        closed = set()
        while open_set:
            _, g, node, parent = heapq.heappop(open_set)
            if node in closed:
                continue
            came_from[node] = parent
            if node == goal:
                path, cur = [], node
                while cur is not None:
                    path.append(cur)
                    cur = came_from[cur]
                path.reverse()
                return path
            closed.add(node)
            for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
                nr, nc = node[0]+dr, node[1]+dc
                if is_free(nr, nc):
                    ng = g + 1
                    if (nr,nc) not in gscore or ng < gscore[(nr,nc)]:
                        gscore[(nr,nc)] = ng
                        heapq.heappush(open_set, (ng + h((nr,nc), goal), ng, (nr,nc), node))
        return None

    start_grid = to_grid(last_waypoint[0], last_waypoint[1])
    goal_grid  = to_grid(home_coord[0], home_coord[1])

    # For the A* path, we want to enter the polygon from start
    # and exit to the goal — snap intermediate entry/exit to polygon boundary
    start_inside = nearest_free_inside(*start_grid)
    goal_inside  = nearest_free_inside(*goal_grid)

    # Build full path: actual start -> polygon entry -> polygon path -> polygon exit -> actual goal
    path = astar(start_inside, goal_inside)
    if not path:
        return []

    # Prepend actual start and append actual goal (outside polygon)
    full_path = [start_grid] + path + [goal_grid]

    # Deduplicate consecutive identical points
    deduped = [full_path[0]]
    for p in full_path[1:]:
        if p != deduped[-1]:
            deduped.append(p)

    return [to_coord(r, c) for r, c in deduped]

def run_lawnmower(polygon_coords, spacing_meters, angle_deg=90, safety_meters=0):
    """Generate lawnmower waypoints for a polygon."""
    from shapely.geometry import Polygon, LineString, MultiLineString
    from shapely.ops import transform, unary_union
    from shapely.affinity import rotate
    import pyproj
    import numpy as np

    # Build polygon in degrees
    coords_deg = [(c[0], c[1]) for c in polygon_coords]
    if coords_deg[0] != coords_deg[-1]:
        coords_deg.append(coords_deg[0])
    poly_deg = Polygon(coords_deg)

    # Project to UTM
    centroid = poly_deg.centroid
    utm_zone = int((centroid.x + 180) / 6) + 1
    hemi = 6 if centroid.y >= 0 else 7
    crs_proj = f"EPSG:32{hemi}{utm_zone:02d}"
    to_proj = pyproj.Transformer.from_crs("EPSG:4326", crs_proj, always_xy=True)
    to_deg  = pyproj.Transformer.from_crs(crs_proj, "EPSG:4326", always_xy=True)
    poly_proj = transform(to_proj.transform, poly_deg)

    # Apply shore margin
    if safety_meters > 0:
        poly_proj = poly_proj.buffer(-safety_meters)
        if poly_proj.is_empty:
            return []

    # Rotate polygon to align with angle
    math_angle = (90.0 - angle_deg) % 360.0
    centroid_proj = poly_proj.centroid
    poly_rot = rotate(poly_proj, -math_angle, origin=centroid_proj)

    # Generate parallel lines
    minx, miny, maxx, maxy = poly_rot.bounds
    width = maxx - minx
    y_values = np.arange(miny + spacing_meters / 2, maxy, spacing_meters)

    lines = []
    for i, y in enumerate(y_values):
        line = LineString([(minx - width, y), (maxx + width, y)])
        clipped = poly_rot.intersection(line)
        if clipped.is_empty:
            continue
        if isinstance(clipped, LineString):
            segments = [clipped]
        elif isinstance(clipped, MultiLineString):
            segments = list(clipped.geoms)
        else:
            continue
        segments.sort(key=lambda s: s.coords[0][0])
        # Alternate direction
        if i % 2 == 0:
            for seg in segments:
                lines.extend([seg.coords[0], seg.coords[-1]])
        else:
            for seg in reversed(segments):
                lines.extend([seg.coords[-1], seg.coords[0]])

    if not lines:
        return []

    # Rotate back and convert to degrees
    path_rot = LineString(lines)
    path_proj = rotate(path_rot, math_angle, origin=centroid_proj)
    path_deg = transform(to_deg.transform, path_proj)

    return [[c[0], c[1]] for c in path_deg.coords]


from lawnmower_with_obstacles import run_lawnmower_with_obstacles

@app.route('/nav/generate_lawnmower', methods=['POST'])
def generate_lawnmower_route():
    try:
        data = request.json
        coords    = data['coordinates']
        spacing   = float(data.get('spacing', 10))
        angle     = float(data.get('angle', 90))
        safety    = float(data.get('safety', 0))
        no_go     = data.get('no_go_zones', None)
        home     = data.get('home_coord', None)

        waypoints = run_lawnmower_with_obstacles(coords, spacing, angle, safety, no_go)

        return_path = []
        if home and waypoints:
            return_path = compute_return_path(
                coords, spacing, safety,
                last_waypoint=waypoints[-1],
                home_coord=home,
                no_go_zones=no_go
            )

        return jsonify({'status': 'success', 'waypoints': waypoints, 'return_path': return_path})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500
#---Save mission functions
@app.route('/missions/save', methods=['POST'])
def save_mission():
    try:
        data = request.get_json()
        name = data.get('name', '').strip()
        geojson = data.get('geojson')
        if not name:
            return jsonify({'error': 'Mission name required'}), 400
        safe_name = "".join(c for c in name if c.isalnum() or c in (' ', '-', '_')).strip()
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{timestamp}_{safe_name}.json"
        with open(MISSIONS_DIR / filename, 'w') as f:
            json.dump({'name': name, 'created': datetime.datetime.now().isoformat(), 'geojson': geojson}, f, indent=2)
        return jsonify({'status': 'saved', 'filename': filename})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/missions/list', methods=['GET'])
def list_missions():
    try:
        missions = []
        for f in sorted(MISSIONS_DIR.glob('*.json'), reverse=True):
            with open(f) as file:
                data = json.load(file)
                missions.append({'filename': f.name, 'name': data.get('name', f.stem), 'created': data.get('created', '')})
        return jsonify(missions)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/missions/load/<filename>', methods=['GET'])
def load_mission(filename):
    try:
        filepath = MISSIONS_DIR / Path(filename).name
        if not filepath.exists():
            return jsonify({'error': 'Mission not found'}), 404

        with open(filepath) as f:
            data = json.load(f)

        if not data.get('geojson') or 'features' not in data['geojson']:
            return jsonify({'error': 'Mission has invalid geojson'}), 400

        return jsonify(data)

    except Exception as e:
        return jsonify({'error': str(e)}), 500
@app.route('/missions/delete/<filename>', methods=['DELETE'])
def delete_mission(filename):
    try:
        filepath = MISSIONS_DIR / Path(filename).name
        if not filepath.exists():
            return jsonify({'error': 'Not found'}), 404
        filepath.unlink()
        return jsonify({'status': 'deleted'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/nav/fetch_mission', methods=['GET'])
def nav_fetch_mission():
    try:
        # First request the mission count from Pixhawk
        mav_post({
            'type': 'MISSION_REQUEST_LIST',
            'target_system': 1,
            'target_component': 1,
            'mission_type': {'type': 'MAV_MISSION_TYPE_MISSION'}
        })
        time.sleep(1)

        # Now read the count that Pixhawk responded with
        count_data = mav_get('/mavlink/vehicles/1/components/1/messages/MISSION_COUNT')
        count = count_data['message']['count']

        if count == 0:
            return jsonify({'waypoints': [], 'count': 0})

        waypoints = []
        for seq in range(count):
            # Request each item
            mav_post({
                'type': 'MISSION_REQUEST_INT',
                'seq': seq,
                'target_system': 1,
                'target_component': 1,
                'mission_type': {'type': 'MAV_MISSION_TYPE_MISSION'}
            })
            time.sleep(0.025)

            # Read the response
            item = mav_get('/mavlink/vehicles/1/components/1/messages/MISSION_ITEM_INT')
            lat    = item['message']['x'] / 1e7
            lng    = item['message']['y'] / 1e7
            loiter = item['message']['param1']
            seq_n  = item['message']['seq']
            waypoints.append({'seq': seq_n, 'lat': lat, 'lng': lng, 'loiter': loiter})
        seqs = [w['seq'] for w in waypoints]
        unique = len(set(seqs)) == len(seqs)
        print(f"[FETCH] count={count}, unique={unique}, seqs={seqs[:10]}...")
        return jsonify({'status': 'success', 'waypoints': waypoints, 'count': count})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/missions/overwrite/<filename>', methods=['PUT'])
def overwrite_mission(filename):
    try:
        filepath = MISSIONS_DIR / Path(filename).name
        if not filepath.exists():
            return jsonify({'error': 'Mission not found'}), 404

        # Read existing file to preserve the original name and created date
        with open(filepath) as f:
            existing = json.load(f)

        data = request.get_json()
        existing['geojson'] = data.get('geojson')

        # Delete old file, write new one with same filename
        filepath.unlink()
        with open(filepath, 'w') as f:
            json.dump(existing, f, indent=2)

        return jsonify({'status': 'overwritten', 'filename': filename})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
@app.route('/nav/pause', methods=['POST'])
def nav_pause():
    """MISSION_PAUSE -- implemented as a HOLD mode change, same as every
    other /nav/* mode route, so it goes through mode_verification too
    rather than a fifth hand-rolled copy of the same DO_SET_MODE call."""
    try:
        return jsonify(mode_verification.set_mode_and_verify('HOLD'))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/nav/resume', methods=['POST'])
def nav_resume():
    """MISSION_RESUME -- implemented as an AUTO mode change; Home-verification
    gate unchanged."""
    blocked = _require_verified_home()
    if blocked:
        return blocked
    try:
        return jsonify(mode_verification.set_mode_and_verify('AUTO'))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/nav/jump_to_waypoint', methods=['POST'])
def nav_jump_to_waypoint():
    try:
        seq = int(request.json.get('seq'))
        mav_post({'type': 'COMMAND_LONG', 'param1': seq,
                  'param2': 0, 'param3': 0, 'param4': 0, 'param5': 0, 'param6': 0, 'param7': 0,
                  'command': {'type': 'MAV_CMD_DO_SET_MISSION_CURRENT'},
                  'target_system': 1, 'target_component': 1, 'confirmation': 0})
        return jsonify({'status': 'Jumped to waypoint ' + str(seq)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/nav/clear_mission', methods=['POST'])
def nav_clear_mission():
    try:
        # Clear main mission
        mav_post({'type': 'MISSION_CLEAR_ALL', 'target_system': 1, 'target_component': 1,
                  'mission_type': {'type': 'MAV_MISSION_TYPE_MISSION'}})
        time.sleep(1)
        # Clear fence
        mav_post({'type': 'MISSION_CLEAR_ALL', 'target_system': 1, 'target_component': 1,
                  'mission_type': {'type': 'MAV_MISSION_TYPE_FENCE'}})
        time.sleep(1)
        # Clear rally points
        mav_post({'type': 'MISSION_CLEAR_ALL', 'target_system': 1, 'target_component': 1,
                  'mission_type': {'type': 'MAV_MISSION_TYPE_RALLY'}})
        time.sleep(1)
        return jsonify({'status': 'Mission cleared'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/nav/hold', methods=['POST'])
def nav_hold():
    try:
        return jsonify(mode_verification.set_mode_and_verify('HOLD'))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# LOITER (ArduRover custom_mode 5) -- one of the most important safety
# commands, and deliberately NEVER gated on Home verification (see
# _require_verified_home above and services/set_home_service.py's module
# docstring): it must remain available even when Home is unverified. Uses
# the same mode_verification.set_mode_and_verify() readback every mode
# route uses, but with shorter bounds -- LOITER must respond quickly since
# it's the safety fallback, not wait out RTL's full multi-second stability
# window.
@app.route('/nav/loiter', methods=['POST'])
def nav_loiter():
    try:
        result = mode_verification.set_mode_and_verify(
            'LOITER', ack_timeout_s=1.0, verify_timeout_s=2.0, stable_window_s=1.0,
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/nav/manual', methods=['POST'])
def nav_manual():
    try:
        return jsonify(mode_verification.set_mode_and_verify('MANUAL'))
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/nav/mission_count', methods=['GET'])
def nav_mission_count():
    try:
        mav_post({
            'type': 'MISSION_REQUEST_LIST',
            'target_system': 1,
            'target_component': 1,
            'mission_type': {'type': 'MAV_MISSION_TYPE_MISSION'}
        })
        time.sleep(0.5)
        data = mav_get('/mavlink/vehicles/1/components/1/messages/MISSION_COUNT')
        count = data['message']['count']
        return jsonify({'count': count, 'has_mission': count > 0})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/nav/mission_status', methods=['GET'])
def nav_mission_status():
    global mission_active, current_mission_id
    try:
        count_data = mav_get('/mavlink/vehicles/1/components/1/messages/MISSION_COUNT')
        current_data = mav_get('/mavlink/vehicles/1/components/1/messages/MISSION_CURRENT')
        hb = mav_get('/mavlink/vehicles/1/components/1/messages/HEARTBEAT')

        count = count_data.get('message', {}).get('count')
        current_waypoint = current_data.get('message', {}).get('seq')
        mode = hb.get('message', {}).get('custom_mode')

        return jsonify({
            'mission_active': mission_active,
            'current_mission_id': current_mission_id,
            'mission_count': count,
            'current_waypoint': current_waypoint,
            'current_waypoint_display': (
                f"{current_waypoint} / {count}"
                if current_waypoint is not None and count is not None
                else None
            ),
            'mission_state': 'SEARCH' if mission_active else 'IDLE',
            'mode': mode,
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    import threading
    
    # Start measurement loop in a thread
    measurement_thread = threading.Thread(target=MeasuringLoop, daemon=True)
    measurement_thread.start()
    
    # Start sampler loop in a thread
    sampler_thread = threading.Thread(target=samplerLoop, daemon=True)
    sampler_thread.start()
    
    # Turn on light on startup
    gpio_set_pin("Light", True)

    socketio.run(app, debug=False, port=8080, host='0.0.0.0')

