//window.dataPoints = [4,4,4];


document.addEventListener('DOMContentLoaded', function() {
    var socket = io();
    
    window.SendCommand = function(command, value){
        socket.emit('webCommand', command, value);
    };
    
    //Data requested on connection
    socket.on('connect', function() {
        console.log('Connected to server');
        // Request data
        socket.emit('request_data');

        //Request a list of available databases
        
        socket.emit('request_history');
        
        //Request an example log for verifying the connectio to the backend
        socket.emit('request_log');
        
    });

    socket.on('response_Log', function(data) {
        
        CreateLogElement(data);
        
    });
    

    //When a list of databases is received update the drop down
    socket.on('response_history', function(data) {
        LoadAvailableDatabaseList(data);
        
    });


    //Probably nothing
    socket.on('disconnect', function() {
        console.log('Disconnected from server');
    });

    //Request data
    window.request_data = function(day){
        socket.emit('request_data', {date:day});
    }
    

    

    //Handel data Response, 
    socket.on('response_data', function(data) {
        
        console.log('Received data:', data);
        // Process data
        if ('error' in data) {
            alert('Error when receiving data');
        } else {
            //Received sucsesfully
            
            //Update the map
            UpdateMapFromData(data);

            //Add values to the graph
            AddValues(data);

            //Update the datacolumn
            UpdateColumnValues(data);
            

            //Update the sensor slider
            ToggleSensorsBackEndRequest(data[0]["sensorsEnabled"]);
        }
    });




});

