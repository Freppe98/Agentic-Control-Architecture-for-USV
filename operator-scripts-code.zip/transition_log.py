"""
Rolling audit trail of real state transitions this Local Agent has observed
or made -- communication, mission, and control-authority changes -- each
with the concrete trigger that caused it, not a generic description.

Distinct from the `events` list built up in local_agent.py's main loop:
`events` is a short-lived human-readable feed capped at MAX_LOCAL_EVENTS and
cleared every time a status send succeeds (see local_agent.py), so the
operator only ever sees "what's new". This module is the complementary
persistent record -- it is never cleared, so every poll of GET /agent/state
(via the status message's `transitions` field) replays the same bounded
history, which is what lets the operator backend reconstruct "why is the
agent in the state it's in" after reconnecting, not just "what just happened".

In-memory only, same lifetime as everything else in this process -- a Local
Agent restart starts a fresh log, same as runtime_status.py's liveness clock.
"""
import time
from collections import deque

MAX_TRANSITIONS = 100

_transitions = deque(maxlen=MAX_TRANSITIONS)


def record_transition(transition_type: str, from_: str, to: str, reason: str) -> dict:
    """
    transition_type: "communication" | "mission" | "authority" -- the kind
    of state this transition belongs to, so the operator can filter/group.
    reason: the actual trigger, e.g. "Heartbeat timeout exceeded" or "Final
    waypoint reached", not a boilerplate "state changed" message.
    """
    entry = {
        "timestamp": round(time.time(), 2),
        "type": transition_type,
        "from": from_,
        "to": to,
        "reason": reason,
    }
    _transitions.append(entry)
    return entry


def get_recent(n: int = MAX_TRANSITIONS) -> list:
    return list(_transitions)[-n:]


def get_recent_by_type(transition_type: str, n: int = MAX_TRANSITIONS) -> list:
    """
    Same rolling log, filtered to one transition_type -- used for
    payload.agent.decision_timeline (type == "decision") so the Agent page
    gets a dedicated field instead of filtering payload.transitions itself.
    """
    return [e for e in _transitions if e["type"] == transition_type][-n:]


def last() -> "dict | None":
    return _transitions[-1] if _transitions else None
