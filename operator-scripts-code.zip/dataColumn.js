var valueDivs = document.getElementsByClassName("value");

//These two arrays store the range in which values are considered "good" (Green on the front end)
//TODO Allow the user to change these and load them from the server maybe?
//AtLeast not have them all be the same value.
///var minGoodValues =new Array(valueDivs.length).fill(2);
//var maxGoodValues =new Array(valueDivs.length).fill(8);


//DataCloumnTypes stores what should be shown in the datacolumn.
//Name, unit, id
var DataColumnTypes = [
    ["Water Depth","(mm)","depth"],
    ["Surface Temp", "(°C)","watertemperature"],
    ["Gondola Temp", "(°C)","gondolatemperature"],
    ["pH", "","pH"],
    ["CDOM", "(µg/L)","cDOM"],
    ["PAH", "(µg/L)","PAH"],
    ["Dissolved Oxygen", "(µg/L)","DO"],
    ["Nitrate", "(µg/L)","No3"],
    ["Turbidity", "(FAU)","Turbidity"],
    ["Voltage", "(V)","voltage"],
    ["Conductivity", "µS/cm","Conductivity"]
    
];

var DataColumn = document.getElementById("DataColumnHolder");
function GenerateHTML(){
    for(var i = 0; i < DataColumnTypes.length; i++){
        var template = `
        <div class="datapoints" onclick="SetGraph(this.querySelector('.value').id)">
            <div class="name">`+ DataColumnTypes[i][0]+`</div>
            <div class="unit">`+ DataColumnTypes[i][1]+`</div>
            <div class="value" id="`+ DataColumnTypes[i][2]+`"></div>
        </div>`
        DataColumn.innerHTML = DataColumn.innerHTML + template;

    }
}
GenerateHTML();

//Takes the last measurement values
function UpdateColumnValues(data){
    time = Date.now();
    //3 first values are timestamp and cordinates. These are not relevant for the data cloumn
    for (var i = 0; i < valueDivs.length; i++){
        if(data[0][valueDivs[i].id] != null){
            //Set the inner html
            console.log("ID:"+valueDivs[i].id+ "  value: " + data[0][valueDivs[i].id]);
            valueDivs[i].innerHTML = data[0][valueDivs[i].id].toFixed(2);
            
            //Set the time attribute used for turning the colums grey
            valueDivs[i].setAttribute("data-time", time);
            //Remove the grey
            valueDivs[i].parentElement.classList.remove("Grey");

        }
         



    }
}
//Give them all a time attribute to begin with
time = Date.now();
for (var i = 0; i < valueDivs.length; i++){
    valueDivs[i].setAttribute("data-time", time);
    
}


maxValueDelayMs = 3000; 
function CheckValueTimes(){
    now = Date.now();
    for (var i = 0; i < valueDivs.length; i++){
        if (now - parseInt(valueDivs[i].getAttribute("data-time")) > maxValueDelayMs){
            valueDivs[i].parentElement.classList.add("Grey");
            
        }
    }
}


setInterval(CheckValueTimes, 1000);



//Sliders

function valueSlider(id){
    //alert(id);
}