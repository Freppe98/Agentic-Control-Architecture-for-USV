"""
Vehicle-side (Flask/mavlink2rest-adjacent) half of the Vehicle Health page's
diagnostics. Covers only what this process can answer authoritatively --
mavlink2rest reachability, Pixhawk/GPS/battery/RC telemetry, the RealSense
camera streams, mission state, and this host's own cpu/memory/storage.

Deliberately read-only: every check here is a GET against mavlink2rest or a
liveness probe against another local service. Nothing in this module ever
calls mav_post or writes to Pixhawk.

Call init() once at app startup (same pattern as services/agent_state.py)
to register the mav_get function and service URLs, then build_diagnostics()
per request.

Status vocabulary (per component): OK, WARNING, FAIL, UNKNOWN. UNKNOWN means
"could not be determined" -- never invent a value to avoid it.
"""
import os
import shutil
import time
from typing import Callable, Optional

import requests

from services.health_service import ram_usage_percent, cpu_temp, service_reachable
from services.mavlink_message_utils import (
    message_age_seconds as _message_age_seconds,
    gps_fix_type_num,
    gps_satellites_visible,
)

_mav_get: Optional[Callable] = None
_mavlink_base_url: Optional[str] = None
_realsense_rgb_url: Optional[str] = None
_realsense_depth_url: Optional[str] = None
_get_app_state: Optional[Callable] = None


def init(
    mav_get_fn: Callable,
    mavlink_base_url: str,
    realsense_rgb_url: str,
    realsense_depth_url: str,
    app_state_getter: Callable,
) -> None:
    global _mav_get, _mavlink_base_url, _realsense_rgb_url, _realsense_depth_url, _get_app_state
    _mav_get = mav_get_fn
    _mavlink_base_url = mavlink_base_url
    _realsense_rgb_url = realsense_rgb_url
    _realsense_depth_url = realsense_depth_url
    _get_app_state = app_state_getter


def _status(status: str, message: str = None, evidence: Optional[dict] = None) -> dict:
    """
    `evidence` adds the raw measured values behind the status/message verdict
    (e.g. {"fix_type": 3, "satellites": 16}) -- the operator backend can
    derive its own PASS/WARN/FAIL from these numbers directly instead of only
    ever seeing this module's own thresholding. status/message are unchanged
    and still authoritative for existing consumers (e.g. build_system_check).
    """
    out = {"status": status, "measured_at": round(time.time(), 2)}
    if message:
        out["message"] = message
    if evidence:
        out.update(evidence)
    return out


def _safe_mav_get(path: str):
    try:
        return _mav_get(path)
    except Exception:
        return None


def mavlink2rest_reachable(timeout: float = 1.0) -> bool:
    """
    Distinguishes "mavlink2rest itself can't be reached" from "mavlink2rest
    is up but Pixhawk hasn't sent a given message yet" -- the two collapse
    to the same None if you only ever go through _safe_mav_get, which is
    fine for telemetry aggregation but not for a diagnostics page that's
    supposed to say *which* link is down.
    """
    if not _mavlink_base_url:
        return False
    try:
        requests.get(_mavlink_base_url, timeout=timeout)
        return True
    except Exception:
        return False


def _health_url_from_stream_url(stream_url: Optional[str]) -> Optional[str]:
    if not stream_url or not stream_url.endswith("/video_feed"):
        return None
    return stream_url[: -len("/video_feed")] + "/health"


def _diag_mavlink() -> dict:
    if mavlink2rest_reachable():
        return _status("OK", "mavlink2rest reachable")
    return _status("FAIL", "mavlink2rest unreachable")


def _diag_pixhawk(hb) -> dict:
    age = _message_age_seconds(hb)
    if not mavlink2rest_reachable():
        return _status("UNKNOWN", "cannot determine Pixhawk status -- mavlink2rest unreachable",
                        evidence={"available": None, "age_s": None})
    if hb is not None:
        return _status("OK", "heartbeat received",
                        evidence={"available": True, "age_s": round(age, 2) if age is not None else None})
    return _status("FAIL", "mavlink2rest reachable but no HEARTBEAT received",
                    evidence={"available": False, "age_s": None})


def _diag_gps(gps_raw) -> dict:
    if gps_raw is None:
        return _status("UNKNOWN", "GPS_RAW_INT not available", evidence={"fix_type": None, "satellites": None})
    fix_num = gps_fix_type_num(gps_raw)
    satellites = gps_satellites_visible(gps_raw)
    evidence = {"fix_type": fix_num, "satellites": satellites}
    try:
        if fix_num is None:
            fix_raw = gps_raw.get("message", {}).get("fix_type")
            return _status("UNKNOWN", f"unrecognized fix_type: {fix_raw!r}", evidence=evidence)
        if fix_num >= 3:
            return _status("OK", f"3D+ fix ({fix_num})", evidence=evidence)
        if fix_num == 2:
            return _status("WARNING", "2D fix only", evidence=evidence)
        return _status("FAIL", "no GPS fix", evidence=evidence)
    except Exception as e:
        return _status("UNKNOWN", f"could not parse GPS_RAW_INT: {e}", evidence=evidence)


def _diag_battery(bat) -> dict:
    if bat is None:
        return _status("UNKNOWN", "BATTERY_STATUS not available",
                        evidence={"remaining": None, "voltage": None, "current": None})
    try:
        remaining = bat["message"]["battery_remaining"]
        voltages = bat["message"].get("voltages", [])
        valid_voltages = [v for v in voltages if isinstance(v, int) and 0 < v < 65535]
        voltage = round(sum(valid_voltages) / 1000.0, 2) if valid_voltages else None
        current_raw = bat["message"].get("current_battery")
        current = round(current_raw / 100.0, 2) if isinstance(current_raw, int) and current_raw >= 0 else None
        evidence = {"remaining": remaining, "voltage": voltage, "current": current}

        if remaining is None or remaining < 0:
            return _status("UNKNOWN", "battery_remaining not reported", evidence=evidence)
        if remaining > 30:
            return _status("OK", f"{remaining}% remaining", evidence=evidence)
        if remaining > 15:
            return _status("WARNING", f"{remaining}% remaining", evidence=evidence)
        return _status("FAIL", f"{remaining}% remaining", evidence=evidence)
    except Exception as e:
        return _status("UNKNOWN", f"could not parse BATTERY_STATUS: {e}",
                        evidence={"remaining": None, "voltage": None, "current": None})


# RC_CHANNELS in ArduPilot streams several times a second while a receiver
# is actually connected; mavlink2rest itself never expires the cached
# message, so this is the only signal that distinguishes "receiving RC now"
# from "received RC at some point before the transmitter was switched off".
_RC_STALE_SECONDS = 5


def _diag_rc_receiver() -> dict:
    """
    RF link indication (e.g. RSSI) alone doesn't prove Pixhawk is actually
    getting RC input -- a receiver can report a healthy link while its
    channel output is disconnected or the autopilot isn't consuming it. PASS
    requires actual Pixhawk-side evidence: a non-zero RC_CHANNELS chancount
    *and* a recent update from mavlink2rest, not just message presence.
    """
    rc = _safe_mav_get("/mavlink/vehicles/1/components/1/messages/RC_CHANNELS")
    if rc is None:
        return _status("UNKNOWN", "RC_CHANNELS not available from mavlink2rest",
                        evidence={"chancount": None, "age_s": None})
    try:
        chancount = rc["message"].get("chancount", 0)
    except Exception as e:
        return _status("UNKNOWN", f"could not parse RC_CHANNELS: {e}", evidence={"chancount": None, "age_s": None})

    age = _message_age_seconds(rc)
    evidence = {"chancount": chancount, "age_s": round(age, 2) if age is not None else None}
    if not chancount:
        return _status("WARNING", "RC_CHANNELS present but chancount is 0", evidence=evidence)
    if age is None:
        return _status("UNKNOWN", f"{chancount} RC channels reported but update freshness could not be determined", evidence=evidence)
    if age > _RC_STALE_SECONDS:
        return _status("UNKNOWN", f"{chancount} RC channels reported but last update was {round(age, 1)}s ago (stale)", evidence=evidence)
    return _status("OK", f"{chancount} RC channels reported, last update {round(age, 2)}s ago", evidence=evidence)


def _diag_camera() -> dict:
    rgb_health = _health_url_from_stream_url(_realsense_rgb_url)
    depth_health = _health_url_from_stream_url(_realsense_depth_url)
    if not rgb_health and not depth_health:
        return _status("UNKNOWN", "camera health URL not configured")

    rgb_ok = service_reachable(rgb_health) if rgb_health else None
    depth_ok = service_reachable(depth_health) if depth_health else None

    results = [v for v in (rgb_ok, depth_ok) if v is not None]
    if all(results):
        return _status("OK", "RealSense stream(s) reachable")
    if any(results):
        return _status("WARNING", f"rgb={rgb_ok} depth={depth_ok}")
    return _status("FAIL", "RealSense streams unreachable")


def _diag_mission_service(mc, mcur) -> dict:
    try:
        app = _get_app_state()
        mission_active = app.get("mission_active")
        mission_id = app.get("current_mission_id")
        count = mc.get("message", {}).get("count") if mc else None
        current = mcur.get("message", {}).get("seq") if mcur else None
        return _status(
            "OK",
            f"mission_active={mission_active} mission_id={mission_id!r} "
            f"waypoint={current}/{count}",
        )
    except Exception as e:
        return _status("FAIL", f"mission state unavailable: {e}")


def _diag_storage() -> dict:
    try:
        disk = shutil.disk_usage("/")
        pct = round(100 * disk.used / disk.total, 1)
        evidence = {"used_percent": pct, "free_percent": round(100 - pct, 1)}
        if pct < 80:
            return _status("OK", f"{pct}% used", evidence=evidence)
        if pct < 90:
            return _status("WARNING", f"{pct}% used", evidence=evidence)
        return _status("FAIL", f"{pct}% used", evidence=evidence)
    except Exception as e:
        return _status("UNKNOWN", f"could not read disk usage: {e}",
                        evidence={"used_percent": None, "free_percent": None})


def _diag_cpu() -> dict:
    try:
        load1 = os.getloadavg()[0]
        cores = os.cpu_count() or 1
        ratio = load1 / cores
        temp = cpu_temp()
        evidence = {"load1": round(load1, 2), "cores": cores, "temp_c": temp}
        msg = f"load1={round(load1, 2)} cores={cores}"
        if temp is not None:
            msg += f" temp={temp}C"
        if ratio < 0.7:
            return _status("OK", msg, evidence=evidence)
        if ratio < 1.0:
            return _status("WARNING", msg, evidence=evidence)
        return _status("FAIL", msg, evidence=evidence)
    except Exception as e:
        return _status("UNKNOWN", f"could not read cpu load: {e}",
                        evidence={"load1": None, "cores": None, "temp_c": None})


def _diag_memory() -> dict:
    pct = ram_usage_percent()
    if pct is None:
        return _status("UNKNOWN", "could not read /proc/meminfo", evidence={"used_percent": None})
    evidence = {"used_percent": pct}
    if pct < 80:
        return _status("OK", f"{pct}% used", evidence=evidence)
    if pct < 90:
        return _status("WARNING", f"{pct}% used", evidence=evidence)
    return _status("FAIL", f"{pct}% used", evidence=evidence)


def build_diagnostics() -> dict:
    """
    The subset of Vehicle Health diagnostics this Flask process (the layer
    with the actual network path to mavlink2rest, RealSense, and this
    host's /proc,/sys) can answer. The Local Agent composes this together
    with its own communication/local_agent/network checks -- see
    motherpi/services/local_mission_agent/diagnostics.py.
    """
    hb = _safe_mav_get("/mavlink/vehicles/1/components/1/messages/HEARTBEAT")
    bat = _safe_mav_get("/mavlink/vehicles/1/components/1/messages/BATTERY_STATUS")
    gps_raw = _safe_mav_get("/mavlink/vehicles/1/components/1/messages/GPS_RAW_INT")
    mc = _safe_mav_get("/mavlink/vehicles/1/components/1/messages/MISSION_COUNT")
    mcur = _safe_mav_get("/mavlink/vehicles/1/components/1/messages/MISSION_CURRENT")

    return {
        "generated_at": round(time.time(), 2),
        "mavlink": _diag_mavlink(),
        "pixhawk": _diag_pixhawk(hb),
        "gps": _diag_gps(gps_raw),
        "battery": _diag_battery(bat),
        "rc_receiver": _diag_rc_receiver(),
        "camera": _diag_camera(),
        "mission_service": _diag_mission_service(mc, mcur),
        "storage": _diag_storage(),
        "cpu": _diag_cpu(),
        "memory": _diag_memory(),
    }
