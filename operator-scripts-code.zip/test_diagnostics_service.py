"""
Standalone tests for services/diagnostics_service.py and its
GET /agent/diagnostics route. No pytest dependency -- run directly:

    python3 test_diagnostics_service.py

Fakes mav_get/app_state/realsense reachability entirely -- no live
mavlink2rest, RealSense, or Pixhawk required. Builds a minimal Flask app
registering only agent_bp, same pattern as test_control_authority.py.
"""
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from flask import Flask

import services.diagnostics_service as diagnostics_service
from routes.agent_routes import agent_bp


def _hb():
    return {"message": {"custom_mode": 0}}


def _bat(remaining=80):
    return {"message": {"battery_remaining": remaining}}


def _gps(fix_type="GPS_FIX_TYPE_3D_FIX"):
    return {"message": {"fix_type": {"type": fix_type}}}


def _iso(age_seconds=0.0):
    ts = datetime.now(timezone.utc) - timedelta(seconds=age_seconds)
    return ts.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "000Z"


def _rc(chancount=8, age_seconds=0.0):
    return {
        "message": {"chancount": chancount},
        "status": {"time": {"last_update": _iso(age_seconds)}},
    }


def _mav_get_factory(responses):
    """responses: dict of {path_suffix: value_or_None}; missing key -> None."""
    def _mav_get(path):
        for suffix, value in responses.items():
            if path.endswith(suffix):
                if value is None:
                    raise RuntimeError("no data")
                return value
        raise RuntimeError(f"unexpected path: {path}")
    return _mav_get


def _init_diagnostics(responses, realsense_ok=True):
    diagnostics_service.init(
        mav_get_fn=_mav_get_factory(responses),
        mavlink_base_url="http://mavlink2rest.invalid",
        realsense_rgb_url="http://realsense.invalid:5001/video_feed",
        realsense_depth_url="http://realsense.invalid:5002/video_feed",
        app_state_getter=lambda: {"mission_active": False, "current_mission_id": None},
    )


class TestDiagMavlinkPixhawk(unittest.TestCase):
    def test_mavlink_unreachable_reports_fail_and_pixhawk_unknown(self):
        _init_diagnostics({"HEARTBEAT": _hb()})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=False):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["mavlink"]["status"], "FAIL")
        self.assertEqual(diag["pixhawk"]["status"], "UNKNOWN")

    def test_mavlink_reachable_but_no_heartbeat_is_pixhawk_fail(self):
        _init_diagnostics({"HEARTBEAT": None})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["mavlink"]["status"], "OK")
        self.assertEqual(diag["pixhawk"]["status"], "FAIL")

    def test_heartbeat_present_is_pixhawk_ok(self):
        _init_diagnostics({"HEARTBEAT": _hb()})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["pixhawk"]["status"], "OK")


class TestDiagGps(unittest.TestCase):
    def test_3d_fix_is_ok(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "GPS_RAW_INT": _gps("GPS_FIX_TYPE_3D_FIX")})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["gps"]["status"], "OK")

    def test_2d_fix_is_warning(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "GPS_RAW_INT": _gps("GPS_FIX_TYPE_2D_FIX")})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["gps"]["status"], "WARNING")

    def test_no_fix_is_fail(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "GPS_RAW_INT": _gps("GPS_FIX_TYPE_NO_FIX")})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["gps"]["status"], "FAIL")

    def test_missing_gps_message_is_unknown(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "GPS_RAW_INT": None})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["gps"]["status"], "UNKNOWN")


class TestDiagBattery(unittest.TestCase):
    def test_healthy_battery_is_ok(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "BATTERY_STATUS": _bat(80)})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["battery"]["status"], "OK")

    def test_low_battery_is_warning(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "BATTERY_STATUS": _bat(20)})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["battery"]["status"], "WARNING")

    def test_critical_battery_is_fail(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "BATTERY_STATUS": _bat(5)})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["battery"]["status"], "FAIL")

    def test_missing_battery_message_is_unknown(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "BATTERY_STATUS": None})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["battery"]["status"], "UNKNOWN")


class TestDiagRcReceiver(unittest.TestCase):
    def test_missing_rc_channels_is_unknown_not_fake(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "RC_CHANNELS": None})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["rc_receiver"]["status"], "UNKNOWN")

    def test_rc_channels_present_and_fresh_is_ok(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "RC_CHANNELS": _rc(8, age_seconds=0.2)})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["rc_receiver"]["status"], "OK")

    def test_rc_channels_zero_chancount_is_warning(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "RC_CHANNELS": _rc(0, age_seconds=0.2)})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["rc_receiver"]["status"], "WARNING")

    def test_rc_channels_stale_is_unknown_not_pass(self):
        """
        A transmitter switched off long ago still leaves a cached RC_CHANNELS
        message behind -- mavlink2rest never expires it. Channel count alone
        (or an RF link/RSSI indication) is not sufficient evidence of a live
        RC input; a stale last_update must not report OK/PASS.
        """
        _init_diagnostics({"HEARTBEAT": _hb(), "RC_CHANNELS": _rc(8, age_seconds=60)})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["rc_receiver"]["status"], "UNKNOWN")

    def test_rc_channels_without_timestamp_is_unknown_not_pass(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "RC_CHANNELS": {"message": {"chancount": 8}}})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["rc_receiver"]["status"], "UNKNOWN")


class TestDiagEvidenceFields(unittest.TestCase):
    """Raw evidence numbers alongside status/message (Priority 3: Scout
    exposes evidence, the operator backend derives its own PASS/WARN/FAIL)."""

    def test_pixhawk_evidence_has_available_and_age(self):
        _init_diagnostics({"HEARTBEAT": _hb()})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True), \
             patch.object(diagnostics_service, "_message_age_seconds", return_value=0.4):
            diag = diagnostics_service.build_diagnostics()
        self.assertIs(diag["pixhawk"]["available"], True)
        self.assertEqual(diag["pixhawk"]["age_s"], 0.4)

    def test_pixhawk_evidence_unknown_when_mavlink_unreachable(self):
        _init_diagnostics({"HEARTBEAT": _hb()})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=False):
            diag = diagnostics_service.build_diagnostics()
        self.assertIsNone(diag["pixhawk"]["available"])
        self.assertIsNone(diag["pixhawk"]["age_s"])

    def test_gps_evidence_has_numeric_fix_and_satellites(self):
        gps = {"message": {"fix_type": {"type": "GPS_FIX_TYPE_3D_FIX"}, "satellites_visible": 16}}
        _init_diagnostics({"HEARTBEAT": _hb(), "GPS_RAW_INT": gps})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["gps"]["fix_type"], 3)
        self.assertEqual(diag["gps"]["satellites"], 16)

    def test_battery_evidence_has_voltage_current_remaining(self):
        bat = {"message": {"battery_remaining": 80, "voltages": [12200, 65535], "current_battery": 350}}
        _init_diagnostics({"HEARTBEAT": _hb(), "BATTERY_STATUS": bat})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["battery"]["remaining"], 80)
        self.assertEqual(diag["battery"]["voltage"], 12.2)
        self.assertEqual(diag["battery"]["current"], 3.5)

    def test_storage_evidence_has_free_and_used_percent(self):
        _init_diagnostics({"HEARTBEAT": _hb()})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertIn("free_percent", diag["storage"])
        self.assertIn("used_percent", diag["storage"])
        self.assertAlmostEqual(diag["storage"]["free_percent"] + diag["storage"]["used_percent"], 100, delta=0.2)

    def test_cpu_evidence_has_load_cores_temp(self):
        _init_diagnostics({"HEARTBEAT": _hb()})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertIn("load1", diag["cpu"])
        self.assertIn("cores", diag["cpu"])
        self.assertIn("temp_c", diag["cpu"])

    def test_rc_evidence_has_chancount_and_age(self):
        _init_diagnostics({"HEARTBEAT": _hb(), "RC_CHANNELS": _rc(8, age_seconds=0.2)})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["rc_receiver"]["chancount"], 8)
        self.assertIsNotNone(diag["rc_receiver"]["age_s"])


class TestDiagCamera(unittest.TestCase):
    def test_both_streams_reachable_is_ok(self):
        _init_diagnostics({"HEARTBEAT": _hb()})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True), \
             patch.object(diagnostics_service, "service_reachable", return_value=True):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["camera"]["status"], "OK")

    def test_no_streams_reachable_is_fail(self):
        _init_diagnostics({"HEARTBEAT": _hb()})
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True), \
             patch.object(diagnostics_service, "service_reachable", return_value=False):
            diag = diagnostics_service.build_diagnostics()
        self.assertEqual(diag["camera"]["status"], "FAIL")


class TestDiagnosticsRoute(unittest.TestCase):
    def setUp(self):
        _init_diagnostics({
            "HEARTBEAT": _hb(), "BATTERY_STATUS": _bat(80),
            "GPS_RAW_INT": _gps(), "RC_CHANNELS": _rc(),
        })
        app = Flask(__name__)
        app.register_blueprint(agent_bp)
        self.client = app.test_client()

    def test_route_returns_all_components(self):
        with patch.object(diagnostics_service, "mavlink2rest_reachable", return_value=True), \
             patch.object(diagnostics_service, "service_reachable", return_value=True):
            resp = self.client.get("/agent/diagnostics")
        self.assertEqual(resp.status_code, 200)
        body = resp.get_json()
        for key in ("mavlink", "pixhawk", "gps", "battery", "rc_receiver",
                    "camera", "mission_service", "storage", "cpu", "memory"):
            self.assertIn(key, body, f"missing {key}")
            self.assertIn("status", body[key])
            self.assertIn("measured_at", body[key], f"{key} missing measured_at")


if __name__ == "__main__":
    unittest.main(verbosity=2)
