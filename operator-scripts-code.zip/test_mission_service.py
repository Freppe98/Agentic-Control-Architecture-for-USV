"""
Standalone tests for services/mission_service.py and its GET /agent/mission
route. No pytest dependency -- run directly:

    python3 test_mission_service.py

Fakes mav_get/mav_post entirely with a small stateful "fake vehicle" that
models mavlink2rest's actual behavior: MISSION_COUNT/MISSION_ITEM_INT only
change in the cache once a matching MISSION_REQUEST_LIST/MISSION_REQUEST_INT
has been posted and the (simulated) Pixhawk has had time to answer -- until
then mav_get keeps returning whatever was cached before, exactly the
"never expires a cached message" trap this module's freshness checking is
meant to defeat. Tokens are real RFC3339 timestamps (not opaque strings) so
the same absolute-time freshness proof mission_service.py actually uses
against a real mavlink2rest is genuinely exercised here, not bypassed by a
degraded "no timestamp available" fallback. No live mavlink2rest or Pixhawk
required.
"""
import time
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from flask import Flask

import services.mission_service as mission_service
from routes.agent_routes import agent_bp

_DEFAULT_MISSION_TYPE = "MAV_MISSION_TYPE_MISSION"
_DEFAULT_SOURCE = (1, 1)


class FakeVehicle:
    """
    Models mavlink2rest's message cache for MISSION_COUNT/MISSION_ITEM_INT/
    MISSION_CURRENT/HOME_POSITION under repeated GET, plus a mav_post that
    only causes the cache to advance (with a fresh last_update token) after
    `count_delay`/`item_delay` seconds -- so a caller that doesn't wait for
    a fresh token gets stale data, same as the real bridge. Also models the
    mission_type/source header fields mission_service.py's transaction
    freshness proof checks, and offers `inject_*` helpers that overwrite a
    cache slot with a fresh-looking token *without* going through the normal
    mav_post -> resolve flow -- simulating a reply mavlink2rest attributes
    to a slot that this particular download() call never actually asked
    for (contamination from an earlier/different transaction).
    """

    def __init__(self):
        self.count = 0
        self.items = {}  # seq -> dict of MISSION_ITEM_INT message fields (no 'seq' key needed)
        self.current_waypoint = None
        self.home = None
        self.count_delay = 0.0
        self.item_delay = 0.0
        self.count_never_responds = False
        self.unresponsive_seqs = set()
        self.post_log = []

        # mission_type / source every *normal* (non-injected) reply carries.
        self.count_mission_type = _DEFAULT_MISSION_TYPE
        self.item_mission_type = _DEFAULT_MISSION_TYPE
        self.count_source = _DEFAULT_SOURCE
        self.item_source = _DEFAULT_SOURCE
        self.include_header = True

        # requested seq -> seq actually placed in the *next* reply's own
        # `seq` field (defaults to identity, i.e. answers correctly).
        self.reply_seq_override = {}
        # requested seqs for which exactly one out-of-order/wrong reply is
        # delivered before the retry answers correctly -- models a delayed
        # answer to an earlier request arriving just ahead of the real one.
        self.stale_reply_once = set()
        self._stale_reply_consumed = set()

        self._token_n = 0
        self._count_cached = {"count": 0}
        self._count_cached_token = self._new_token()
        self._count_cached_source = self.count_source
        self._count_pending = None  # (ready_at, token)

        self._item_cached = {}
        self._item_cached_token = self._new_token()
        self._item_cached_source = self.item_source
        self._item_pending = None  # (ready_at, token, seq)

    def _new_token(self):
        """A real, strictly-increasing RFC3339 timestamp -- not an opaque
        counter -- so mission_service.py's arrival-time-vs-request-time
        proof is exercised for real rather than degrading to "no parseable
        timestamp" on every fake message."""
        self._token_n += 1
        ts = datetime.now(timezone.utc) + timedelta(microseconds=self._token_n)
        return ts.isoformat()

    def seed_stale_count(self, count, mission_type=None, source=None):
        """Pre-populate the cache with a value from some earlier, unrelated
        request -- simulating a cache that was never empty to begin with."""
        self._count_cached = {"count": count}
        self._count_cached_token = self._new_token()
        self._count_cached_source = source or self.count_source
        if mission_type is not None:
            self.count_mission_type = mission_type

    def seed_stale_item(self, seq, item, mission_type=None, source=None):
        """Pre-populate the single MISSION_ITEM_INT cache slot with a
        leftover value (e.g. from a previous mission's download) -- same
        idea as seed_stale_count but for items."""
        payload = dict(item)
        payload["seq"] = seq
        self._item_cached = payload
        self._item_cached_token = self._new_token()
        self._item_cached_source = source or self.item_source
        if mission_type is not None:
            self.item_mission_type = mission_type

    def inject_item(self, seq, item, mission_type=None, source=None):
        """Overwrites the MISSION_ITEM_INT cache slot with a brand-new,
        fresh-looking token *without* a matching mav_post -- simulating a
        reply mavlink2rest attributes to this slot that this download()
        call never asked for. Used to prove the transaction's mission_type/
        source checks (not just token-change + seq-match) are what reject
        it."""
        payload = dict(item)
        payload["seq"] = seq
        self._item_cached = payload
        self._item_cached_token = self._new_token()
        self._item_cached_source = source or self.item_source
        if mission_type is not None:
            self._item_cached_mission_type_override = mission_type
        else:
            self._item_cached_mission_type_override = None

    def mav_post(self, data):
        self.post_log.append(data)
        if data["type"] == "MISSION_REQUEST_LIST":
            if not self.count_never_responds:
                self._count_pending = (time.time() + self.count_delay, self._new_token())
        elif data["type"] == "MISSION_REQUEST_INT":
            seq = data["seq"]
            if seq not in self.unresponsive_seqs:
                self._item_pending = (time.time() + self.item_delay, self._new_token(), seq)

    def _resolve_count(self):
        if self._count_pending and time.time() >= self._count_pending[0]:
            _, token = self._count_pending
            self._count_cached_token = token
            self._count_cached = {"count": self.count}
            self._count_cached_source = self.count_source
            self._item_cached_mission_type_override = None
            self._count_pending = None

    def _resolve_item(self):
        if self._item_pending and time.time() >= self._item_pending[0]:
            _, token, requested_seq = self._item_pending
            reported_seq = self.reply_seq_override.get(requested_seq, requested_seq)
            if requested_seq in self.stale_reply_once and requested_seq not in self._stale_reply_consumed:
                self._stale_reply_consumed.add(requested_seq)
                reported_seq = requested_seq - 1 if requested_seq > 0 else requested_seq + 1
            self._item_cached_token = token
            item = dict(self.items.get(requested_seq, {}))
            item["seq"] = reported_seq
            self._item_cached = item
            self._item_cached_source = self.item_source
            self._item_cached_mission_type_override = None
            self._item_pending = None

    def mav_get(self, path):
        if path.endswith("MISSION_COUNT"):
            self._resolve_count()
            message = dict(self._count_cached)
            message.setdefault("mission_type", {"type": self.count_mission_type})
            envelope = {"message": message, "status": {"time": {"last_update": self._count_cached_token}}}
            if self.include_header:
                envelope["header"] = {"system_id": self._count_cached_source[0],
                                       "component_id": self._count_cached_source[1]}
            return envelope
        if path.endswith("MISSION_ITEM_INT"):
            self._resolve_item()
            message = dict(self._item_cached)
            mission_type = getattr(self, "_item_cached_mission_type_override", None) or self.item_mission_type
            message.setdefault("mission_type", {"type": mission_type})
            envelope = {"message": message, "status": {"time": {"last_update": self._item_cached_token}}}
            if self.include_header:
                envelope["header"] = {"system_id": self._item_cached_source[0],
                                       "component_id": self._item_cached_source[1]}
            return envelope
        if path.endswith("MISSION_CURRENT"):
            if self.current_waypoint is None:
                raise RuntimeError("no data")
            return {"message": {"seq": self.current_waypoint}, "status": {"time": {"last_update": self._new_token()}}}
        if path.endswith("HOME_POSITION"):
            if self.home is None:
                raise RuntimeError("no data")
            return {"message": self.home, "status": {"time": {"last_update": self._new_token()}}}
        raise RuntimeError(f"unexpected path: {path}")


def _waypoint_item(lat, lng, alt=0.0, loiter=0, command="MAV_CMD_NAV_WAYPOINT",
                    frame="MAV_FRAME_GLOBAL_RELATIVE_ALT", autocontinue=1):
    return {
        "x": int(lat * 1e7), "y": int(lng * 1e7), "z": alt,
        "param1": loiter,
        "command": {"type": command},
        "frame": {"type": frame},
        "autocontinue": autocontinue,
    }


def _init(vehicle, reachable=True, reset=True):
    mission_service.init(
        mav_get_fn=vehicle.mav_get,
        mav_post_fn=vehicle.mav_post,
        mavlink_base_url="http://mavlink2rest.invalid",
    )
    # Each test starts with an empty last-known-good cache -- otherwise a
    # successful download in an earlier test would leak into this one's
    # "no cache exists yet" expectations, since the cache is process-global
    # by design (see mission_service.py's reset_last_known_good() docstring).
    # reset=False lets a single test deliberately carry a cache forward from
    # an earlier _init() call within the *same* test (see
    # TestLastKnownGoodCache), matching how a real long-lived process would.
    if reset:
        mission_service.reset_last_known_good()
    return patch.object(mission_service, "mavlink2rest_reachable", return_value=reachable)


class FastTimeoutsMixin:
    """Shrinks every timeout/retry/poll constant so timeout-path tests run
    in well under a second instead of tens of seconds."""

    def setUp(self):
        self._patches = [
            patch.object(mission_service, "_POLL_INTERVAL_S", 0.001),
            patch.object(mission_service, "_COUNT_TIMEOUT_S", 0.05),
            patch.object(mission_service, "_ITEM_TIMEOUT_S", 0.05),
            patch.object(mission_service, "_COUNT_MAX_RETRIES", 2),
            patch.object(mission_service, "_ITEM_MAX_RETRIES", 2),
            patch.object(mission_service, "_OVERALL_TIMEOUT_S", 0.5),
        ]
        for p in self._patches:
            p.start()

    def tearDown(self):
        for p in self._patches:
            p.stop()


class TestZeroWaypointMission(FastTimeoutsMixin, unittest.TestCase):
    def test_zero_waypoint_mission_is_available_and_valid(self):
        vehicle = FakeVehicle()
        vehicle.count = 0
        with _init(vehicle):
            result = mission_service.download_mission()
        self.assertTrue(result["available"])
        self.assertTrue(result["reachable"])
        self.assertEqual(result["mission_count"], 0)
        self.assertEqual(result["waypoints"], [])
        self.assertFalse(result["mission_loaded"])
        self.assertTrue(result["mission_valid"])
        self.assertIsNone(result["error"])


class TestNormalMission(FastTimeoutsMixin, unittest.TestCase):
    def test_normal_mission_decodes_all_waypoint_fields(self):
        vehicle = FakeVehicle()
        vehicle.count = 3
        vehicle.items = {
            0: _waypoint_item(57.1, 11.1, alt=0.0, loiter=5),
            1: _waypoint_item(57.2, 11.2, alt=2.5, loiter=0),
            2: _waypoint_item(57.3, 11.3, alt=1.0, loiter=0, command="MAV_CMD_NAV_RETURN_TO_LAUNCH"),
        }
        vehicle.current_waypoint = 1
        vehicle.home = {"latitude": 571000000, "longitude": 111000000, "altitude": 12300}
        with _init(vehicle):
            result = mission_service.download_mission()

        self.assertTrue(result["available"])
        self.assertEqual(result["mission_count"], 3)
        self.assertTrue(result["mission_loaded"])
        self.assertTrue(result["mission_valid"])
        self.assertIsNone(result["error"])
        self.assertEqual(result["current_waypoint"], 1)
        self.assertEqual(result["home_position"], {"latitude": 57.1, "longitude": 11.1, "altitude": 12.3})

        self.assertEqual(len(result["waypoints"]), 3)
        wp0 = result["waypoints"][0]
        self.assertEqual(wp0["sequence"], 0)
        self.assertAlmostEqual(wp0["latitude"], 57.1, places=6)
        self.assertAlmostEqual(wp0["longitude"], 11.1, places=6)
        self.assertEqual(wp0["command"], "MAV_CMD_NAV_WAYPOINT")
        self.assertEqual(wp0["frame"], "MAV_FRAME_GLOBAL_RELATIVE_ALT")
        self.assertIs(wp0["autocontinue"], True)
        self.assertEqual(wp0["loiter_time"], 5)

        # Non-NAV_WAYPOINT command: param1 doesn't mean "loiter time" there,
        # must not be reported as one.
        wp2 = result["waypoints"][2]
        self.assertEqual(wp2["command"], "MAV_CMD_NAV_RETURN_TO_LAUNCH")
        self.assertIsNone(wp2["loiter_time"])

    def test_never_posts_a_mission_write_message(self):
        """Read-only: only *_REQUEST_* messages (asking the Pixhawk to report
        its own state) and the closing MISSION_ACK (a transfer-session close,
        never mission content) may ever be posted -- never MISSION_COUNT/
        MISSION_ITEM_INT/MISSION_CLEAR_ALL, which would write mission data."""
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 1: _waypoint_item(3.0, 4.0)}
        with _init(vehicle):
            mission_service.download_mission()
        posted_types = {p["type"] for p in vehicle.post_log}
        self.assertTrue(posted_types <= {"MISSION_REQUEST_LIST", "MISSION_REQUEST_INT", "MISSION_ACK"})

    def test_successful_download_closes_with_an_accepted_mission_ack(self):
        """A fully valid download must send exactly one closing MISSION_ACK,
        addressed to the Pixhawk, carrying MAV_MISSION_ACCEPTED under
        `mavtype` (not `type` -- see mission_service.py module docstring for
        why `type` would collide with mavlink2rest's own message-name key)."""
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 1: _waypoint_item(3.0, 4.0)}
        with _init(vehicle):
            result = mission_service.download_mission()
        self.assertTrue(result["mission_valid"])
        acks = [p for p in vehicle.post_log if p["type"] == "MISSION_ACK"]
        self.assertEqual(len(acks), 1)
        self.assertEqual(acks[0]["target_system"], 1)
        self.assertEqual(acks[0]["target_component"], 1)
        self.assertEqual(acks[0]["mavtype"], {"type": "MAV_MISSION_ACCEPTED"})

    def test_count_never_arriving_still_closes_with_a_cancelled_mission_ack(self):
        """Even when MISSION_COUNT never arrives, this attempt must still
        close out with MISSION_ACK(MAV_MISSION_OPERATION_CANCELLED) so
        ArduPilot's mission-sender state doesn't stay wedged open for the
        next attempt (the confirmed real failure this closing ack fixes)."""
        vehicle = FakeVehicle()
        vehicle.count_never_responds = True
        with _init(vehicle):
            mission_service.download_mission()
        acks = [p for p in vehicle.post_log if p["type"] == "MISSION_ACK"]
        self.assertEqual(len(acks), 1)
        self.assertEqual(acks[0]["mavtype"], {"type": "MAV_MISSION_OPERATION_CANCELLED"})


class TestStaleCache(FastTimeoutsMixin, unittest.TestCase):
    def test_preexisting_stale_cache_is_not_returned_as_the_answer(self):
        """
        A MISSION_COUNT (and MISSION_ITEM_INT) left over from some earlier,
        unrelated request must never be mistaken for the response to *this*
        download -- only a message whose last_update token changed after
        this download's own MISSION_REQUEST_LIST/INT is accepted.
        """
        vehicle = FakeVehicle()
        vehicle.seed_stale_count(99)  # leftover from a previous operation
        vehicle.count = 5  # the real, current count
        vehicle.items = {i: _waypoint_item(1.0 + i, 2.0 + i) for i in range(5)}
        with _init(vehicle):
            result = mission_service.download_mission()
        self.assertEqual(result["mission_count"], 5)
        self.assertNotEqual(result["mission_count"], 99)
        self.assertEqual(len(result["waypoints"]), 5)


class TestDelayedResponses(FastTimeoutsMixin, unittest.TestCase):
    def test_succeeds_despite_delay_within_timeout_budget(self):
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 1: _waypoint_item(3.0, 4.0)}
        vehicle.count_delay = 0.02
        vehicle.item_delay = 0.01
        with _init(vehicle):
            result = mission_service.download_mission()
        self.assertTrue(result["available"])
        self.assertTrue(result["mission_valid"])
        self.assertEqual(len(result["waypoints"]), 2)


class TestTimeout(FastTimeoutsMixin, unittest.TestCase):
    def test_mission_count_never_arriving_reports_unavailable_not_fake(self):
        vehicle = FakeVehicle()
        vehicle.count_never_responds = True
        with _init(vehicle):
            result = mission_service.download_mission()
        self.assertFalse(result["available"])
        self.assertTrue(result["reachable"])
        self.assertIsNone(result["mission_count"])
        self.assertIsNotNone(result["error"])
        self.assertIn("mission_count", result["error"].lower())

    def test_one_missing_item_yields_partial_waypoints_and_invalid_flag(self):
        vehicle = FakeVehicle()
        vehicle.count = 3
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 2: _waypoint_item(5.0, 6.0)}
        vehicle.unresponsive_seqs = {1}
        with _init(vehicle):
            result = mission_service.download_mission()
        self.assertTrue(result["available"])
        self.assertFalse(result["mission_valid"])
        self.assertEqual(len(result["waypoints"]), 1)  # only seq 0 confirmed
        self.assertIsNotNone(result["error"])

    def test_mavlink2rest_unreachable_reports_unavailable_not_fake(self):
        vehicle = FakeVehicle()
        with _init(vehicle, reachable=False):
            result = mission_service.download_mission()
        self.assertFalse(result["available"])
        self.assertFalse(result["reachable"])
        self.assertIsNone(result["mission_count"])
        self.assertEqual(result["waypoints"], [])


class TestCurrentWaypoint(FastTimeoutsMixin, unittest.TestCase):
    def test_reports_current_waypoint_when_available(self):
        vehicle = FakeVehicle()
        vehicle.count = 0
        vehicle.current_waypoint = 4
        with _init(vehicle):
            result = mission_service.download_mission()
        self.assertEqual(result["current_waypoint"], 4)

    def test_current_waypoint_null_when_never_broadcast(self):
        vehicle = FakeVehicle()
        vehicle.count = 0
        with _init(vehicle):
            result = mission_service.download_mission()
        self.assertIsNone(result["current_waypoint"])


class TestMultipleSequentialDownloads(FastTimeoutsMixin, unittest.TestCase):
    def test_repeated_downloads_each_return_correct_fresh_data(self):
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 2.0)}
        with _init(vehicle):
            first = mission_service.download_mission()
            second = mission_service.download_mission()
            third = mission_service.download_mission()

        for result in (first, second, third):
            self.assertTrue(result["available"])
            self.assertTrue(result["mission_valid"])
            self.assertEqual(result["mission_count"], 1)
            self.assertEqual(len(result["waypoints"]), 1)

        # Each download re-requested independently rather than short-circuiting
        # on a cached result from the previous call.
        list_requests = [p for p in vehicle.post_log if p["type"] == "MISSION_REQUEST_LIST"]
        self.assertEqual(len(list_requests), 3)


def _bare_item_missing_command():
    """A MISSION_ITEM_INT payload missing `command` entirely -- undecodable,
    should be reported as unsupported rather than guessed at."""
    return {"x": 10000000, "y": 20000000, "z": 0.0, "param1": 0,
            "frame": {"type": "MAV_FRAME_GLOBAL_RELATIVE_ALT"}, "autocontinue": 1}


class TestMissionHash(unittest.TestCase):
    def test_same_mission_produces_same_hash(self):
        wps = [mission_service._decode_waypoint({"message": {**_waypoint_item(1.0, 2.0, loiter=3), "seq": 0}})]
        h1 = mission_service.compute_mission_hash(wps)
        h2 = mission_service.compute_mission_hash(wps)
        self.assertEqual(h1, h2)

    def test_changing_a_field_changes_the_hash(self):
        wp_a = mission_service._decode_waypoint({"message": {**_waypoint_item(1.0, 2.0), "seq": 0}})
        wp_b = mission_service._decode_waypoint({"message": {**_waypoint_item(1.0, 2.5), "seq": 0}})
        self.assertNotEqual(mission_service.compute_mission_hash([wp_a]),
                             mission_service.compute_mission_hash([wp_b]))

    def test_hash_is_order_independent_sorted_by_sequence(self):
        wp0 = mission_service._decode_waypoint({"message": {**_waypoint_item(1.0, 2.0), "seq": 0}})
        wp1 = mission_service._decode_waypoint({"message": {**_waypoint_item(3.0, 4.0), "seq": 1}})
        self.assertEqual(
            mission_service.compute_mission_hash([wp0, wp1]),
            mission_service.compute_mission_hash([wp1, wp0]),
        )

    def test_empty_mission_hash_is_deterministic(self):
        self.assertEqual(mission_service.compute_mission_hash([]), mission_service.compute_mission_hash([]))


class TestDuplicateSequenceDetection(unittest.TestCase):
    def test_detects_a_duplicate(self):
        wp0 = {"sequence": 0}
        wp0b = {"sequence": 0}
        wp1 = {"sequence": 1}
        self.assertEqual(mission_service._find_duplicate_sequences([wp0, wp1, wp0b]), [0])

    def test_no_duplicates_in_a_clean_list(self):
        self.assertEqual(mission_service._find_duplicate_sequences([{"sequence": 0}, {"sequence": 1}]), [])


class TestPixhawkMissionZeroWaypoint(FastTimeoutsMixin, unittest.TestCase):
    def test_zero_waypoint_mission(self):
        vehicle = FakeVehicle()
        vehicle.count = 0
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()
        self.assertFalse(result["mission_loaded"])
        self.assertTrue(result["mission_valid"])
        self.assertEqual(result["count"], 0)
        self.assertEqual(result["waypoints"], [])
        self.assertFalse(result["partial"])
        self.assertEqual(result["hash"], mission_service.compute_mission_hash([]))


class TestPixhawkMissionNormal(FastTimeoutsMixin, unittest.TestCase):
    def test_normal_mission_matches_direct_hash_and_fields(self):
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {0: _waypoint_item(1.0, 2.0, loiter=7), 1: _waypoint_item(3.0, 4.0)}
        vehicle.current_waypoint = 1
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()

        self.assertTrue(result["mission_loaded"])
        self.assertTrue(result["mission_valid"])
        self.assertEqual(result["count"], 2)
        self.assertEqual(result["current_seq"], 1)
        self.assertFalse(result["partial"])
        self.assertEqual(result["duplicate_sequences"], [])
        self.assertEqual(result["invalid_sequences"], [])
        self.assertEqual(result["unsupported_sequences"], [])
        self.assertIsNone(result["error"])
        self.assertEqual(result["hash"], mission_service.compute_mission_hash(result["waypoints"]))
        self.assertEqual(result["waypoints"][0]["loiter_time"], 7)
        self.assertEqual(result["waypoints"][0]["param1"], 7)

    def test_current_seq_never_estimated_null_when_unavailable(self):
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 2.0)}
        vehicle.current_waypoint = None
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()
        self.assertIsNone(result["current_seq"])


class TestPixhawkMissionInvalidCoordinates(FastTimeoutsMixin, unittest.TestCase):
    def test_out_of_range_latitude_flags_sequence_and_invalidates_hash(self):
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {
            0: _waypoint_item(1.0, 2.0),
            1: _waypoint_item(200.0, 2.0),  # invalid latitude, > 90
        }
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()
        self.assertFalse(result["mission_valid"])
        self.assertEqual(result["invalid_sequences"], [1])
        self.assertIsNone(result["hash"])
        # The item is still returned, not discarded -- never fabricate, but
        # also never silently drop data the vehicle actually reported.
        self.assertEqual(len(result["waypoints"]), 2)

    def test_non_position_command_coordinates_are_never_checked(self):
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(200.0, 2.0, command="MAV_CMD_DO_SET_SERVO")}
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()
        self.assertEqual(result["invalid_sequences"], [])


class TestPixhawkMissionUnsupportedItem(FastTimeoutsMixin, unittest.TestCase):
    def test_undecodable_item_is_reported_not_fabricated(self):
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {0: _bare_item_missing_command(), 1: _waypoint_item(3.0, 4.0)}
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()
        self.assertFalse(result["mission_valid"])
        self.assertEqual(result["unsupported_sequences"], [0])
        self.assertIsNone(result["hash"])
        # Download continued past the bad item instead of aborting.
        self.assertEqual(len(result["waypoints"]), 1)
        self.assertEqual(result["waypoints"][0]["sequence"], 1)


class TestPixhawkMissionTimeout(FastTimeoutsMixin, unittest.TestCase):
    def test_count_never_arriving_is_partial_and_unvalidated(self):
        vehicle = FakeVehicle()
        vehicle.count_never_responds = True
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()
        self.assertIsNone(result["mission_loaded"])
        self.assertIsNone(result["mission_valid"])
        self.assertIsNone(result["count"])
        self.assertIsNone(result["hash"])
        self.assertTrue(result["partial"])
        self.assertIsNotNone(result["error"])

    def test_item_timeout_yields_partial_true_and_invalid_hash_null(self):
        vehicle = FakeVehicle()
        vehicle.count = 3
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 2: _waypoint_item(5.0, 6.0)}
        vehicle.unresponsive_seqs = {1}
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()
        self.assertTrue(result["partial"])
        self.assertFalse(result["mission_valid"])
        self.assertIsNone(result["hash"])
        self.assertEqual(len(result["waypoints"]), 1)

    def test_mavlink2rest_unreachable(self):
        vehicle = FakeVehicle()
        with _init(vehicle, reachable=False):
            result = mission_service.download_pixhawk_mission()
        self.assertIsNone(result["mission_loaded"])
        self.assertFalse(result["reachable"])
        self.assertIsNone(result["hash"])


class TestPixhawkMissionMultipleSequentialDownloads(FastTimeoutsMixin, unittest.TestCase):
    def test_hash_stable_across_repeated_downloads_of_unchanged_mission(self):
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 1: _waypoint_item(3.0, 4.0)}
        with _init(vehicle):
            first = mission_service.download_pixhawk_mission()
            second = mission_service.download_pixhawk_mission()
        self.assertEqual(first["hash"], second["hash"])
        self.assertIsNotNone(first["hash"])

    def test_hash_changes_when_mission_content_changes_between_downloads(self):
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 2.0)}
        with _init(vehicle):
            first = mission_service.download_pixhawk_mission()
            vehicle.items = {0: _waypoint_item(9.0, 9.0)}
            second = mission_service.download_pixhawk_mission()
        self.assertNotEqual(first["hash"], second["hash"])


class TestPixhawkMissionRoute(unittest.TestCase):
    def setUp(self):
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 2.0)}
        mission_service.init(
            mav_get_fn=vehicle.mav_get,
            mav_post_fn=vehicle.mav_post,
            mavlink_base_url="http://mavlink2rest.invalid",
        )
        app = Flask(__name__)
        app.register_blueprint(agent_bp)
        self.client = app.test_client()

    def test_route_returns_full_schema(self):
        with patch.object(mission_service, "mavlink2rest_reachable", return_value=True):
            resp = self.client.get("/agent/pixhawk_mission")
        self.assertEqual(resp.status_code, 200)
        body = resp.get_json()
        for key in ("mission_loaded", "mission_valid", "count", "current_seq", "hash",
                    "waypoints", "partial", "duplicate_sequences", "invalid_sequences",
                    "unsupported_sequences", "error", "reachable", "fetched_at", "schema_version"):
            self.assertIn(key, body, f"missing {key}")


class TestMissionRoute(unittest.TestCase):
    def setUp(self):
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 2.0)}
        self.vehicle = vehicle
        mission_service.init(
            mav_get_fn=vehicle.mav_get,
            mav_post_fn=vehicle.mav_post,
            mavlink_base_url="http://mavlink2rest.invalid",
        )
        app = Flask(__name__)
        app.register_blueprint(agent_bp)
        self.client = app.test_client()

    def test_route_returns_full_schema(self):
        with patch.object(mission_service, "mavlink2rest_reachable", return_value=True):
            resp = self.client.get("/agent/mission")
        self.assertEqual(resp.status_code, 200)
        body = resp.get_json()
        for key in ("available", "reachable", "fetched_at", "mission_count", "current_waypoint",
                    "home_position", "waypoints", "mission_loaded", "mission_valid",
                    "last_fetch_age", "error", "mission_hash", "mission_version", "schema_version"):
            self.assertIn(key, body, f"missing {key}")


class TestRealBugStaleMissionCache(FastTimeoutsMixin, unittest.TestCase):
    """
    Reproduces the confirmed real-world bug: a 14-item mission is already
    sitting in mavlink2rest's MISSION_COUNT/MISSION_ITEM_INT cache slots
    (from some earlier, unrelated download), the Pixhawk has since been
    given a genuinely different mission via Mission Planner, and a fresh
    download() call must return *that* new mission -- never the leftover
    cached one, even though the stale MISSION_COUNT and MISSION_ITEM_INT
    both remain visible to any plain GET the whole time.
    """

    def test_pre_existing_full_stale_mission_is_ignored_for_a_same_size_new_one(self):
        vehicle = FakeVehicle()
        old_items = {i: _waypoint_item(56.679 + i * 0.001, 12.811 + i * 0.001) for i in range(14)}
        vehicle.seed_stale_count(14)
        vehicle.seed_stale_item(13, old_items[13])

        vehicle.count = 14
        vehicle.items = {i: _waypoint_item(56.650 + i * 0.001, 12.870 + i * 0.001) for i in range(14)}
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()

        self.assertTrue(result["mission_valid"])
        self.assertFalse(result["cached"])
        self.assertFalse(result["stale"])
        self.assertEqual(result["count"], 14)
        self.assertEqual(len(result["waypoints"]), 14)
        for i, wp in enumerate(result["waypoints"]):
            self.assertAlmostEqual(wp["latitude"], 56.650 + i * 0.001, places=6)
            self.assertAlmostEqual(wp["longitude"], 12.870 + i * 0.001, places=6)

    def test_total_unresponsiveness_after_stale_seed_fails_honestly_not_as_valid(self):
        """If the Pixhawk never answers at all, the pre-existing stale
        MISSION_COUNT must never be reported as this download's answer,
        even though it's sitting right there in the cache the whole time."""
        vehicle = FakeVehicle()
        vehicle.seed_stale_count(14)
        vehicle.seed_stale_item(13, _waypoint_item(56.679, 12.811))
        vehicle.count_never_responds = True
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()

        self.assertIsNone(result["mission_valid"])
        self.assertIsNone(result["count"])
        self.assertEqual(result["waypoints"], [])
        self.assertIsNotNone(result["error"])
        self.assertFalse(result["cached"])


class TestSameCountChangedCoordinates(FastTimeoutsMixin, unittest.TestCase):
    def test_same_waypoint_count_different_coordinates_returns_new_coordinates(self):
        vehicle = FakeVehicle()
        vehicle.count = 3
        vehicle.items = {i: _waypoint_item(1.0 + i, 2.0 + i) for i in range(3)}
        with _init(vehicle):
            first = mission_service.download_pixhawk_mission()
            vehicle.items = {i: _waypoint_item(50.0 + i, 12.0 + i) for i in range(3)}
            second = mission_service.download_pixhawk_mission()

        self.assertTrue(first["mission_valid"])
        self.assertTrue(second["mission_valid"])
        self.assertEqual(first["count"], second["count"])
        self.assertNotEqual(first["hash"], second["hash"])
        for i, wp in enumerate(second["waypoints"]):
            self.assertAlmostEqual(wp["latitude"], 50.0 + i, places=6)


class TestDifferentWaypointCount(FastTimeoutsMixin, unittest.TestCase):
    def test_waypoint_count_change_between_downloads_is_reflected(self):
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 1: _waypoint_item(3.0, 4.0)}
        with _init(vehicle):
            first = mission_service.download_pixhawk_mission()
            vehicle.count = 5
            vehicle.items = {i: _waypoint_item(10.0 + i, 20.0 + i) for i in range(5)}
            second = mission_service.download_pixhawk_mission()

        self.assertEqual(first["count"], 2)
        self.assertEqual(second["count"], 5)
        self.assertEqual(len(second["waypoints"]), 5)
        self.assertTrue(second["mission_valid"])


class TestDelayedOutOfOrderItems(FastTimeoutsMixin, unittest.TestCase):
    def test_one_out_of_order_reply_is_rejected_and_the_retry_succeeds(self):
        """The first reply to the seq=2 request reports seq=1 (a late
        answer to an earlier request arriving just ahead of the real one)
        -- must be rejected by the seq-match check, not accepted, and the
        retry that follows must succeed normally."""
        vehicle = FakeVehicle()
        vehicle.count = 3
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 1: _waypoint_item(3.0, 4.0), 2: _waypoint_item(5.0, 6.0)}
        vehicle.stale_reply_once = {2}
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()

        self.assertTrue(result["mission_valid"])
        self.assertEqual(len(result["waypoints"]), 3)
        self.assertAlmostEqual(result["waypoints"][2]["latitude"], 5.0)
        item_requests = [p for p in vehicle.post_log if p["type"] == "MISSION_REQUEST_INT" and p["seq"] == 2]
        self.assertGreaterEqual(len(item_requests), 2)  # the mismatch forced a retry


class TestDuplicateItemContent(FastTimeoutsMixin, unittest.TestCase):
    def test_identical_content_at_different_sequences_is_valid(self):
        """Two different sequence numbers legitimately holding the same
        waypoint content (e.g. a mission that revisits a point) is not a
        duplicate *sequence* and must not be flagged invalid."""
        vehicle = FakeVehicle()
        vehicle.count = 2
        same = _waypoint_item(1.0, 2.0)
        vehicle.items = {0: same, 1: same}
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()

        self.assertTrue(result["mission_valid"])
        self.assertEqual(result["duplicate_sequences"], [])
        self.assertEqual(len(result["waypoints"]), 2)


class TestWrongSequenceCachedItem(FastTimeoutsMixin, unittest.TestCase):
    def test_persistently_mismatched_seq_fails_honestly_naming_the_seq(self):
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 1: _waypoint_item(3.0, 4.0)}
        vehicle.reply_seq_override = {1: 5}  # every reply to seq=1 claims seq=5
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()

        self.assertFalse(result["mission_valid"])
        self.assertTrue(result["partial"])
        self.assertEqual(len(result["waypoints"]), 1)  # only seq 0 confirmed
        self.assertIn("seq=1", result["error"])


class TestWrongMissionType(FastTimeoutsMixin, unittest.TestCase):
    def test_item_carrying_wrong_mission_type_is_rejected(self):
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 2.0)}
        vehicle.item_mission_type = "MAV_MISSION_TYPE_FENCE"
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()

        self.assertFalse(result["mission_valid"])
        self.assertEqual(result["waypoints"], [])
        self.assertIn("seq=0", result["error"])

    def test_count_carrying_wrong_mission_type_is_rejected(self):
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 1: _waypoint_item(3.0, 4.0)}
        vehicle.count_mission_type = "MAV_MISSION_TYPE_RALLY"
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()

        self.assertIsNone(result["mission_valid"])
        self.assertIsNone(result["count"])
        self.assertIsNotNone(result["error"])

    def test_fresh_looking_contaminated_item_with_wrong_mission_type_does_not_satisfy_request(self):
        """A reply belonging to a different mission-type transfer (e.g. a
        fence upload) lands in the shared cache slot with a brand-new token
        and a *matching* seq right as our own request goes out -- exactly
        what token-changed + seq-match alone (the pre-fix check) accepted.
        The transaction's mission_type check must reject it and wait for
        the genuine answer instead."""
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 2.0)}
        vehicle.item_delay = 0.02  # leaves a window where only the
                                    # injected, contaminated value is cached
        original_post = vehicle.mav_post

        def contaminate_then_post(data):
            original_post(data)
            if data["type"] == "MISSION_REQUEST_INT" and data["seq"] == 0:
                vehicle.inject_item(0, _waypoint_item(99.0, 99.0), mission_type="MAV_MISSION_TYPE_FENCE")

        vehicle.mav_post = contaminate_then_post
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()

        self.assertTrue(result["mission_valid"])
        self.assertAlmostEqual(result["waypoints"][0]["latitude"], 1.0, places=6)


class TestWrongSourceSystem(FastTimeoutsMixin, unittest.TestCase):
    def test_item_from_wrong_source_system_is_rejected(self):
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 2.0)}
        vehicle.item_source = (9, 9)
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()

        self.assertFalse(result["mission_valid"])
        self.assertEqual(result["waypoints"], [])

    def test_count_from_wrong_source_system_is_rejected(self):
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 2.0)}
        vehicle.count_source = (9, 9)
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()

        self.assertIsNone(result["mission_valid"])
        self.assertIsNone(result["count"])

    def test_item_missing_header_is_not_rejected_for_that_reason_alone(self):
        """mavlink2rest's header shape is unverified against a live
        instance (see mission_service.py docstring) -- its *absence* must
        never by itself cause a rejection, only a genuine mismatch."""
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 2.0)}
        vehicle.include_header = False
        with _init(vehicle):
            result = mission_service.download_pixhawk_mission()

        self.assertTrue(result["mission_valid"])
        self.assertEqual(len(result["waypoints"]), 1)


class TestRepeatedImmediateRefresh(FastTimeoutsMixin, unittest.TestCase):
    def test_rapid_back_to_back_refreshes_each_return_correct_current_data(self):
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 1: _waypoint_item(3.0, 4.0)}
        with _init(vehicle):
            results = [mission_service.download_pixhawk_mission() for _ in range(5)]

        for result in results:
            self.assertTrue(result["mission_valid"])
            self.assertEqual(result["count"], 2)
            self.assertFalse(result["cached"])
        generations = [r["generation"] for r in results]
        self.assertEqual(generations, sorted(set(generations)))  # strictly increasing, no reuse


class TestTwoConsecutiveMissionChanges(FastTimeoutsMixin, unittest.TestCase):
    def test_each_of_three_fetches_tracks_the_mission_current_at_call_time(self):
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 1.0)}
        with _init(vehicle):
            first = mission_service.download_pixhawk_mission()
            vehicle.items = {0: _waypoint_item(2.0, 2.0)}
            second = mission_service.download_pixhawk_mission()
            vehicle.items = {0: _waypoint_item(3.0, 3.0)}
            third = mission_service.download_pixhawk_mission()

        self.assertAlmostEqual(first["waypoints"][0]["latitude"], 1.0)
        self.assertAlmostEqual(second["waypoints"][0]["latitude"], 2.0)
        self.assertAlmostEqual(third["waypoints"][0]["latitude"], 3.0)
        self.assertNotEqual(first["hash"], second["hash"])
        self.assertNotEqual(second["hash"], third["hash"])


class TestLastKnownGoodCache(FastTimeoutsMixin, unittest.TestCase):
    def test_serves_cached_mission_when_unreachable_after_a_prior_success(self):
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 1: _waypoint_item(3.0, 4.0)}
        with _init(vehicle):
            first = mission_service.download_pixhawk_mission()
        self.assertTrue(first["mission_valid"])
        self.assertFalse(first["cached"])

        with _init(vehicle, reachable=False, reset=False):
            second = mission_service.download_pixhawk_mission()

        self.assertFalse(second["mission_valid"])
        self.assertTrue(second["cached"])
        self.assertTrue(second["stale"])
        self.assertEqual(second["waypoints"], first["waypoints"])
        self.assertEqual(second["fetched_at"], first["fetched_at"])
        self.assertIsNotNone(second["error"])
        self.assertIn("unreachable", second["error"].lower())

    def test_no_fallback_available_on_a_first_ever_failure(self):
        vehicle = FakeVehicle()
        with _init(vehicle, reachable=False):
            result = mission_service.download_pixhawk_mission()

        self.assertFalse(result["cached"])
        self.assertFalse(result["stale"])
        self.assertIsNone(result["mission_valid"])

    def test_genuine_partial_read_of_new_mission_is_preferred_over_stale_cache(self):
        vehicle = FakeVehicle()
        vehicle.count = 2
        vehicle.items = {0: _waypoint_item(1.0, 2.0), 1: _waypoint_item(3.0, 4.0)}
        with _init(vehicle):
            first = mission_service.download_pixhawk_mission()
            self.assertTrue(first["mission_valid"])

            vehicle.count = 3
            vehicle.items = {0: _waypoint_item(9.0, 9.0)}
            vehicle.unresponsive_seqs = {1}
            second = mission_service.download_pixhawk_mission()

        self.assertFalse(second["mission_valid"])
        self.assertFalse(second["cached"])
        self.assertFalse(second["stale"])
        self.assertEqual(len(second["waypoints"]), 1)
        self.assertAlmostEqual(second["waypoints"][0]["latitude"], 9.0, places=6)

    def test_legacy_endpoint_also_caches_and_falls_back(self):
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 2.0)}
        with _init(vehicle):
            first = mission_service.download_mission()
        self.assertTrue(first["mission_valid"])

        with _init(vehicle, reachable=False, reset=False):
            second = mission_service.download_mission()

        self.assertFalse(second["mission_valid"])
        self.assertTrue(second["cached"])
        self.assertTrue(second["stale"])
        self.assertEqual(second["waypoints"], first["waypoints"])


class TestTransactionGeneration(FastTimeoutsMixin, unittest.TestCase):
    def test_every_call_gets_a_distinct_increasing_generation(self):
        vehicle = FakeVehicle()
        vehicle.count = 1
        vehicle.items = {0: _waypoint_item(1.0, 2.0)}
        with _init(vehicle):
            first = mission_service.download_pixhawk_mission()
            second = mission_service.download_pixhawk_mission()
        self.assertIsInstance(first["generation"], int)
        self.assertLess(first["generation"], second["generation"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
