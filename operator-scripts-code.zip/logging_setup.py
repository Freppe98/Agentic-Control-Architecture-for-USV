import logging
import os
import sys


_CONFIGURED = False


def configure_logging(service_name: str = "sensor-service") -> None:
    """
    Configure stdlib logging for container/systemd stdout.

    Idempotent: safe to call multiple times.
    """
    global _CONFIGURED
    if _CONFIGURED:
        return

    level_name = os.getenv("LOG_LEVEL", "INFO").upper().strip()
    level = getattr(logging, level_name, logging.INFO)

    fmt = os.getenv(
        "LOG_FORMAT",
        "%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    handler = logging.StreamHandler(stream=sys.stdout)
    handler.setFormatter(logging.Formatter(fmt))

    root = logging.getLogger()
    root.setLevel(level)

    # Avoid duplicate handlers when running under reloaders / multiple imports.
    if not any(isinstance(h, logging.StreamHandler) for h in root.handlers):
        root.addHandler(handler)

    # Make noisy libraries less chatty by default.
    logging.getLogger("werkzeug").setLevel(max(level, logging.WARNING))
    logging.getLogger("urllib3").setLevel(max(level, logging.WARNING))

    logging.getLogger(service_name).debug(
        "Logging configured (level=%s, format=%s)", level_name, fmt
    )

    _CONFIGURED = True
