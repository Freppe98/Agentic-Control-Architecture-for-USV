

var ogLog = document.getElementById("logTemplate");

var logHolder = document.getElementById("logList");
const currentDate = new Date(); 


ogLog.children[1].innerHTML = "Time:<b> "+ currentDate.getHours() + ":" +currentDate.getMinutes() +":"+currentDate.getSeconds()+ "</b>";
function CreateLogElement(data){
    //Data should be a list of 3 strings representing the type, the time and the content of the log
    var type = data[0];
    var time = data[1];
    var content = data[2];
    
    //Create a copy of the first log Which is hard coded in the html
    var newLog = ogLog.cloneNode(true);


    //Set the type of log
    newLog.children[0].innerHTML = data[0];

    //Set the timestamp
    newLog.children[1].innerHTML = "Time:<b> " + data[1] + "</b>";

    //Set the content
    newLog.children[2].innerHTML = data[2];


    //Append the new log to the logs    
    logHolder.prepend(newLog);

    

}
