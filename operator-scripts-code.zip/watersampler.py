import sys
from time import sleep
import logging

from logging_setup import configure_logging
from shared_servo import get_servo_kit, is_hardware_available
#from influxdbData import influxdb

configure_logging(service_name="sensor-service")
logger = logging.getLogger(__name__)

class SamplerManager:
    
    def __init__(self):
        self.kit = None
        self.hardware_available = is_hardware_available()
        self._initialized = False

        # # Database link
        # try:
        #     self.influx = influxdb.InfluxdbManager()
        # except Exception as e:
        #     print(f"[SamplerManager] InfluxDB not available: {e}")
        #     self.influx = None

        logger.info("[SamplerManager] Ready (using shared ServoKit instance)")

    def _ensure_initialized(self):
        """Get the shared ServoKit instance on first use"""
        if self._initialized:
            return
            
        logger.info("[SamplerManager] Getting shared ServoKit instance...")
        self.kit = get_servo_kit()
        
        if self.kit is None:
            self.hardware_available = False
            logger.warning("[SamplerManager] No hardware available - running in dummy mode")
        else:
            logger.info("[SamplerManager] Using shared ServoKit instance successfully!")
        
        self._initialized = True

    def activate_sampler(self, sample_number):
        try:
            sample_number = int(sample_number)
            logger.info("[SamplerManager] activate_sampler(%s) called", sample_number)

            # Initialize hardware on first use
            self._ensure_initialized()

            # # Save status to InfluxDB if available
            # try:
            #     if self.influx:
            #         self.influx.SavePoint({f"sampler{sample_number}": 1})
            # except Exception as e:
            #     print(f"[SamplerManager] Warning: Failed to save sampler status to InfluxDB: {e}")

            if not self.hardware_available or self.kit is None:
                logger.warning(
                    "[SamplerManager] Dummy mode - sampler %s NOT physically activated",
                    sample_number,
                )
                return {"activated": False, "reason": "hardware_not_available"}

            # Real activation if hardware is available
            if sample_number == 0:
                self.kit.continuous_servo[0].throttle = -0.9
                sleep(0.7)
                self.kit.continuous_servo[0].throttle = -0.1
                sleep(10)
                self.kit.continuous_servo[0].throttle = 0.9
                sleep(0.7)
                self.kit.continuous_servo[0].throttle = -0.1
                sleep(1)

            elif sample_number == 1:
                self.kit.continuous_servo[1].throttle = 0.9
                sleep(0.5)
                self.kit.continuous_servo[1].throttle = -0.1
                sleep(10)
                self.kit.continuous_servo[1].throttle = -0.5
                sleep(0.7)
                self.kit.continuous_servo[1].throttle = -0.1
                sleep(1)

            elif sample_number == 2:
                self.kit.continuous_servo[2].throttle = -0.5
                sleep(0.5)
                self.kit.continuous_servo[2].throttle = 0.1
                sleep(10)
                self.kit.continuous_servo[2].throttle = 0.9
                sleep(0.5)
                self.kit.continuous_servo[2].throttle = 0.1
                sleep(1)

            elif sample_number == 3:
                self.kit.continuous_servo[3].throttle = 0.9
                sleep(0.5)
                self.kit.continuous_servo[3].throttle = 0.1
                sleep(10)
                self.kit.continuous_servo[3].throttle = -0.5
                sleep(0.5)
                self.kit.continuous_servo[3].throttle = 0.1
                sleep(1)

            else:
                logger.warning("[SamplerManager] Invalid sample number (must be 0-3): %s", sample_number)
                raise ValueError(f"Invalid sample number: {sample_number}. Must be 0-3")

            logger.info("[SamplerManager] Sampler %s activated successfully!", sample_number)
            return {"activated": True}

        except Exception as e:
            logger.exception("[SamplerManager] Error activating sampler %s", sample_number)
            # In dummy mode, don't raise to keep service running
            if self.hardware_available:
                raise
            return {"activated": False, "reason": str(e)}


if __name__ =='__main__':
    ws = SamplerManager()
    if len(sys.argv) > 1:
        ws.activate_sampler(sys.argv[1])
    else:
        print("Usage: python SamplerManager.py <sample_number>")
