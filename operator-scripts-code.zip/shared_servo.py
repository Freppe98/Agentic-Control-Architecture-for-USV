"""
Shared ServoKit instance to avoid I2C bus conflicts.
Both SamplerManager and DomeCamManager use the same physical PCA9685 board,
so they must share the same ServoKit instance.
"""
import logging

from logging_setup import configure_logging

configure_logging(service_name="sensor-service")
logger = logging.getLogger(__name__)

try:
    from adafruit_servokit import ServoKit
    HW_AVAILABLE = True
except Exception as e:
    logger.warning("[SharedServo] PWM hardware library not available", exc_info=True)
    HW_AVAILABLE = False

# Global shared instance
_shared_kit = None
_initialized = False


def get_servo_kit():
    """Get or create the shared ServoKit instance."""
    global _shared_kit, _initialized
    
    if _initialized:
        return _shared_kit
    
    import os
    logger.info("[SharedServo] Initializing shared ServoKit instance...")
    logger.info("[SharedServo] /dev/i2c-1 exists: %s", os.path.exists("/dev/i2c-1"))
    logger.info("[SharedServo] HW_AVAILABLE: %s", HW_AVAILABLE)
    
    if HW_AVAILABLE:
        try:
            logger.info("[SharedServo] Attempting to initialize ServoKit(channels=16)...")
            _shared_kit = ServoKit(channels=16)
            logger.info("[SharedServo] ServoKit initialized successfully!")
        except Exception as e:
            logger.warning("[SharedServo] Failed to initialize ServoKit", exc_info=True)
            _shared_kit = None
    else:
        logger.warning("[SharedServo] Running in dummy mode (no PWM)")
        _shared_kit = None
    
    _initialized = True
    return _shared_kit


def is_hardware_available():
    """Check if hardware is available."""
    return HW_AVAILABLE
