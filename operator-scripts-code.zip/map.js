
var map = null;

var Positions = [];

var defaultzoom = 17


var mapInit = false

function ClearMap(){
    Positions = [];
    if(!map){
        return; 
    }

    map.eachLayer(function (layer) {
        
        if (!(layer instanceof L.TileLayer)) {
            map.removeLayer(layer);
        }
        
    });

}

function SetNewMapPoint(lat, long, zoom){
    if(isNaN(lat) || isNaN(long)){
        return;
    }
    Positions.push([long, lat]);
    
    //Create new map if not already exists
    
    if (!mapInit){
        mapInit = true;
        console.log("Creating new map");

        map = L.map('map').setView([long, lat], zoom);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);
    } else{
        //Update pos of map if it does exist
        
        map.setView([long, lat], zoom);
    }

    //Clear old marker
    map.eachLayer(function (layer) {
        if (!(layer instanceof L.TileLayer) && !(layer instanceof L.polyline)) {
            map.removeLayer(layer);
        }
    });

    //Add new marker
    L.marker([long, lat]).addTo(map);
    
    
            
    
    
    
    var polyline = L.polyline(Positions, {color: 'red'}).addTo(map);
    
}





function UpdateMapFromData(data){
    
    

    for (var i = 0; i < data.length; i++){
        if(data[i]["longitude"] == 'None' || data[i]["latitude"] == 'None' || data[i]["longitude"] == null || data[i]["latitude"] == null){
            continue;
        }
        
        SetNewMapPoint(parseFloat(data[i]["longitude"]),parseFloat(data[i]["latitude"]),17);
        
    }
}


