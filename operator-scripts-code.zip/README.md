# Sensor service

HTTP API on **:6001** for measurements, sampler, and dome. Runs in Docker; see [motherpi/README.md](../../README.md) for setup.

## Key files

| File | Purpose |
|------|---------|
| `sensor_service.py` | Entrypoint, Flask API (health, measurements, sampler, dome) |
| `measurements.py` | Measurement orchestration, sensor reads |
| `watersampler.py` | Sampler control (PCA9685 PWM) |
| `dome.py` | Dome camera rotation (same PWM board) |
| `shared_servo.py` | Shared ServoKit instance (avoid I2C contention) |
| `logging_setup.py` | Stdout logging config (`LOG_LEVEL`, `LOG_FORMAT`) |

## Hardware drivers (common failure points)

| Driver | Path | Device node (typical) |
|--------|------|------------------------|
| TriOS Modbus RTU | `motherpi/measuring/trios/trios.py` | `/dev/trios` |
| Ping sonar | `motherpi/measuring/pingsonar.py` | `/dev/pingSonar` |
| PFAS (serial) | `motherpi/measuring/PFAS.py` | `/dev/ttyACM0` |
| ADC (I2C) | `motherpi/measuring/Adc.py` | `/dev/i2c-1` |

Device nodes and degraded-mode behavior: see [PROJECT.md](../../../../PROJECT.md) (Degraded mode and robustness principles).

## Contract and logging

- **API contract and acceptance criteria:** [PROJECT.md](../../../../PROJECT.md) (Sensor service contract).
- **Logging format and conventions:** [LOGGING.md](../../../../LOGGING.md).
