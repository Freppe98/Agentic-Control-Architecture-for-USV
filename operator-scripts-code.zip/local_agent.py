import threading
import time

from config import (
    USV_ID, USV_NAME, OPERATOR_URLS, BUFFER_FILE, LOCAL_FLASK_URL,
    LOCAL_AGENT_HTTP_HOST, LOCAL_AGENT_HTTP_PORT,
)
from communication import CommunicationMonitor
from information_policy import telemetry_interval, allowed_groups
from api_client import get_vehicle_state, send_to_operator, get_pending_commands
from collectors import get_communication_status, get_agent_status, count_buffered_packets
from models import make_message, make_event
from buffer import buffer_message, flush_buffer
from state_machine import MissionRunner
from command_handler import process_command
import command_history
import command_log
import command_results
import runtime_status
import agent_server
import transition_log
import decision_engine
from transition_reasons import (
    comm_transition_reason, mission_transition_reason, authority_transition_reason,
)

MAX_LOCAL_EVENTS = 20
DEFAULT_CONTROL_AUTHORITY = "OPERATOR"


def _send_buffered(message):
    """Route a buffered message to its endpoint by message_type on flush."""
    endpoint = "/agent/command_result" if message.get("message_type") == "command_result" else "/agent/status"
    response = send_to_operator(endpoint, message)
    if message.get("message_type") == "command_result":
        # Operator has now acknowledged this command_id -- the stored
        # authoritative result (command_results.py) has done its job and a
        # future redelivery of this exact command_id is no longer expected
        # (deliver-once operator queue), so stop retaining it.
        command_id = (message.get("payload") or {}).get("command_id")
        if command_id:
            command_results.clear_result(command_id)
    return response


def _current_authority(vehicle_state):
    """
    Extract control authority from the vehicle_state already fetched this
    iteration (vehicle_state["agent"]["control_authority"], set by the
    vehicle Flask service -- see README "Control authority"). A missing or
    malformed field fails safe to OPERATOR rather than assuming the Local
    Agent has authority it was never explicitly granted.

    Note this is read fresh from the Flask service every iteration, never
    cached across a Local Agent restart -- the Local Agent has no authority
    state of its own to lose or reset. Two different things can look
    similar but are not: (a) the Local Agent process starting up always
    begins passive, because it always starts by reading whatever the Flask
    service currently reports, and that Flask service itself always
    initializes to OPERATOR on its own restart; (b) if a human has already
    explicitly granted LOCAL_AGENT (POST /agent/control_authority) and the
    Local Agent process alone restarts while the Flask service keeps
    running, this will correctly keep reading LOCAL_AGENT and command
    execution resumes. (b) is not "the Local Agent influencing the Pixhawk
    simply because it's running" -- a human already made that call before
    this process came up; the gate that matters is the explicit grant, not
    this process's uptime.
    """
    return vehicle_state.get("agent", {}).get("control_authority", DEFAULT_CONTROL_AUTHORITY)


def _poll_and_execute_commands(comm_state, control_authority, local_events):
    """
    Poll the operator backend for pending commands and execute any that
    validate. Only meaningful when we might actually reach the operator --
    while DISCONNECTED the operator backend queues commands on its side and
    there is nothing to poll against (see README: no local buffering of
    inbound commands, only outbound status/results).

    control_authority (vehicle state owned by the vehicle Flask service,
    read from GET /agent/state each iteration -- see main()) is passed
    through to command_handler.process_command(), which gates the whole
    queue on it: the operator command queue is explicit operator intent, so
    every supported command_type executes while authority is OPERATOR and
    is rejected while it's LOCAL_AGENT (the Local Agent's own autonomous
    writes own the vehicle then -- see README "Authority model"). Polling
    always happens regardless of authority (only DISCONNECTED skips it) --
    the operator backend's command queue is deliver-once (GET /agent/commands
    never re-offers a claimed command_id, see mock_operator.py), so a
    command rejected for wrong authority is a *terminal* rejection with an
    explicit reason, not silently left pending, since polling has already
    claimed it from the operator's deliver-once queue.
    """
    if comm_state == "DISCONNECTED":
        return

    for command in get_pending_commands(USV_ID):
        try:
            result_payload, event = process_command(command, control_authority)
        except Exception as e:
            # Defense in depth: process_command() already turns every
            # failure from the actual vehicle Flask call into a "failed"
            # result internally (see command_handler.py's own try/except
            # around call_local_endpoint). This catches anything
            # unexpected *outside* that guarded block instead -- a bug in
            # validation/dedup/history code, a malformed command dict, a
            # disk error writing command_log.jsonl, etc. Without this, such
            # an exception would propagate out of this loop and out of
            # main()'s while-loop entirely, killing the whole Local Agent
            # process with no command_result ever posted and no
            # command_history record ever made -- leaving the operator
            # backend's command permanently stuck at SENT (claimed_at set,
            # completed_at/result forever null) since a deliver-once queue
            # never re-offers the same command_id. This is the one place
            # that guarantees requirement (6)/(8): every claimed command
            # gets a terminal result, and none can remain SENT indefinitely.
            command_id = command.get("command_id") if isinstance(command, dict) else None
            command_type = command.get("command_type") if isinstance(command, dict) else None
            source = (
                (command.get("source") or command.get("requested_by") or "operator")
                if isinstance(command, dict) else "operator"
            )
            # Bounded retry (requirement 8): whatever unexpected bug landed
            # us here, this command_id must never be re-judged again --
            # without this, a redelivery of the same command_id would hit
            # the exact same bug and post the exact same "failed" result
            # forever (the live SET_HOME symptom this suite exists to
            # catch: a raw ISO expires_at string crashing _expired() before
            # command_handler.py's own mark_processed() call was ever
            # reached). Best-effort and silently swallowed -- if the disk
            # write itself is what's broken, that must not raise a second
            # exception out of this already-exceptional path and defeat
            # the one guarantee this handler exists to provide (a terminal
            # result always gets posted, the loop never dies).
            if command_id:
                try:
                    command_log.mark_processed(command_id)
                except Exception:
                    pass
            now = time.time()
            lifecycle = [
                {"status": "requested", "timestamp": round(now, 3)},
                {"status": "failed", "timestamp": round(now, 3)},
            ]
            reason = f"unexpected local agent error: {e}"
            result_payload = {
                "command_id": command_id,
                "usv_id": USV_ID,
                "command_type": command_type,
                "source": source,
                "status": "failed",
                "reason": reason,
                "timestamp": now,
                "lifecycle": lifecycle,
            }
            event = make_event(
                "command_failed",
                message=f"Command {command_type or '?'} ({command_id}): failed -- {reason}",
                detail={"command_id": command_id, "command_type": command_type},
                severity="warning",
            )
            command_history.record({
                "command_id": command_id,
                "command_type": command_type,
                "source": source,
                "status": "failed",
                "reason": reason,
                "lifecycle": lifecycle,
            })
            # Same authoritative-result guarantee as command_handler.py's
            # own terminal paths: this command_id must resend this exact
            # "failed" result on any redelivery, not re-run the same crash
            # or fabricate a fresh generic "duplicate" verdict. Best-effort
            # for the same reason as mark_processed() above.
            if command_id:
                try:
                    command_results.store_result(command_id, result_payload)
                except Exception:
                    pass
            print(f"[LOCAL AGENT] Unexpected error processing command {command_type} ({command_id}): {e}")

        local_events.append(event)
        print(f"[LOCAL AGENT] Command {result_payload.get('command_type')} "
              f"({result_payload.get('command_id')}): {result_payload['status']} -- {result_payload['reason']}")

        result_message = make_message(
            message_type="command_result",
            source=USV_ID,
            target="operator",
            payload=result_payload,
        )
        try:
            send_to_operator("/agent/command_result", result_message)
            # Operator has acknowledged this command_id -- see
            # command_results.clear_result's docstring for why this is
            # safe to drop now (deliver-once operator queue, no further
            # redelivery expected).
            command_id = result_payload.get("command_id")
            if command_id:
                command_results.clear_result(command_id)
        except Exception as e:
            buffer_message(result_message)
            print(f"[LOCAL AGENT] Could not send command result, buffering: {e}")


def main():
    print(f"[LOCAL AGENT] Starting (usv_id={USV_ID}, operators={OPERATOR_URLS}, buffer_file={BUFFER_FILE})")
    print(f"[LOCAL AGENT] Control authority is vehicle state owned by the vehicle Flask service "
          f"(GET/POST {LOCAL_FLASK_URL}/agent/control_authority) -- defaults to {DEFAULT_CONTROL_AUTHORITY} "
          "there on every restart of that service, and is never assumed here if it can't be read.")

    threading.Thread(
        target=agent_server.serve_forever,
        args=(LOCAL_AGENT_HTTP_HOST, LOCAL_AGENT_HTTP_PORT),
        daemon=True,
    ).start()

    comm_monitor = CommunicationMonitor()
    mission_runner = MissionRunner()
    local_events = []
    last_success_ts = None
    prev_mission_state = mission_runner.state
    prev_authority = DEFAULT_CONTROL_AUTHORITY
    # current_decision/current_decision_reason: the decision engine's own
    # running notion of "what did we last decide", so a repeat evaluation
    # that lands on the same label doesn't get logged as a transition (see
    # decision_engine.decide()). previous_decision/previous_decision_reason
    # are only overwritten at the moment the label actually changes, so the
    # Agent page can always show "what changed from what" -- None until the
    # first change happens.
    current_decision = None
    current_decision_reason = None
    previous_decision = None
    previous_decision_reason = None
    # Set on a comm recovery edge; cleared once flush_buffer reports the
    # backlog fully drained. Flushing always happens *before* the live
    # status send below, in the same iteration, so a fresh view is always
    # the last thing the operator sees -- buffered history can never look
    # like current state. If the flush doesn't fully drain (operator drops
    # again mid-flush) or this iteration's vehicle fetch fails afterwards,
    # pending_flush stays set and retries on the next iteration.
    pending_flush = False

    try:
        while True:
            runtime_status.mark_alive()
            comm_state = comm_monitor.poll()
            groups = allowed_groups(comm_state)

            if comm_state != comm_monitor.previous_state and comm_monitor.previous_state is not None:
                comm_reason = comm_transition_reason(comm_monitor.previous_state, comm_state)
                print(f"[LOCAL AGENT] Comm state: {comm_monitor.previous_state} -> {comm_state}: {comm_reason}")
                transition_log.record_transition("communication", comm_monitor.previous_state, comm_state, comm_reason)
                local_events.append(make_event(
                    "communication_state_changed",
                    message=comm_reason,
                    detail={"from": comm_monitor.previous_state, "to": comm_state},
                ))

            if comm_monitor.just_recovered:
                pending_flush = True
                local_events.append(make_event(
                    "comm_recovered",
                    message=f"Communication recovered from {comm_monitor.previous_state}",
                    detail={"from": comm_monitor.previous_state},
                ))

            # Catches backlog that didn't originate from a comm-down edge --
            # e.g. a command_result stuck in the buffer because its endpoint
            # 404/405s (a route mismatch, not a connectivity gap) while
            # comm_state has stayed CONNECTED throughout, or a leftover
            # buffer file from a previous process restart. Without this, such
            # a backlog would only ever be retried on the next genuine
            # PARTITIONED/DISCONNECTED -> CONNECTED edge, which may never
            # happen in a session that never actually drops.
            if not pending_flush and comm_state == "CONNECTED" and count_buffered_packets() > 0:
                pending_flush = True

            if pending_flush:
                result = flush_buffer(_send_buffered)
                print("[LOCAL AGENT] Backlog flush:", result)
                pending_flush = result["remaining"] > 0

            try:
                vehicle_state = get_vehicle_state()
            except Exception as e:
                print("[LOCAL AGENT] Could not fetch local state:", e)
                time.sleep(2)
                continue

            mission_state = mission_runner.update(vehicle_state.get("mission", {}))
            if mission_state != prev_mission_state:
                vs_mission = vehicle_state.get("mission", {})
                mission_reason = mission_transition_reason(
                    mission_state, vs_mission.get("current_waypoint"),
                    vs_mission.get("mission_count"), mission_runner.mission_id,
                )
                transition_log.record_transition("mission", prev_mission_state, mission_state, mission_reason)
                local_events.append(make_event(
                    "mission_state_changed",
                    message=mission_reason,
                    detail={"from": prev_mission_state, "to": mission_state, "mission_id": mission_runner.mission_id},
                ))
                prev_mission_state = mission_state

            current_authority = _current_authority(vehicle_state)
            if current_authority != prev_authority:
                authority_reason = authority_transition_reason(
                    vehicle_state.get("agent", {}), prev_authority, current_authority,
                )
                transition_log.record_transition("authority", prev_authority, current_authority, authority_reason)
                local_events.append(make_event(
                    "control_authority_changed",
                    message=authority_reason,
                    detail={"from": prev_authority, "to": current_authority},
                ))
                prev_authority = current_authority

            _poll_and_execute_commands(comm_state, current_authority, local_events)
            del local_events[:-MAX_LOCAL_EVENTS]

            # Vehicle owns raw mission identity/progress; the Local Agent owns
            # the phase interpretation and layers it on top here.
            mission_payload = dict(vehicle_state.get("mission", {}))
            mission_payload.update(mission_runner.to_dict())

            # Decision engine: re-evaluated fresh every iteration from this
            # iteration's own observations (never cached across iterations),
            # so decision_reason always reflects current evidence rather than
            # whatever the last *transition* happened to be about.
            decision_inputs = decision_engine.build_decision_inputs(
                vehicle_state, comm_state, mission_state, mission_runner, current_authority,
            )
            new_decision, new_decision_reason = decision_engine.decide(decision_inputs)
            decision_confidence, decision_confidence_missing = decision_engine.confidence(decision_inputs)
            watch_conditions = decision_engine.build_watch_conditions(decision_inputs)
            current_policy = decision_engine.build_policy(comm_state, mission_state, current_authority)

            if new_decision != current_decision:
                if current_decision is not None:
                    transition_log.record_transition("decision", current_decision, new_decision, new_decision_reason)
                    local_events.append(make_event(
                        "decision_changed",
                        message=new_decision_reason,
                        detail={"from": current_decision, "to": new_decision},
                    ))
                previous_decision = current_decision
                previous_decision_reason = current_decision_reason
                current_decision = new_decision
            current_decision_reason = new_decision_reason

            situation = decision_engine.build_situation(
                vehicle_state, comm_state, mission_state, current_authority,
                current_policy["autonomy_level"], decision_confidence,
            )

            agent_status = get_agent_status(comm_state, mission_state)
            agent_status["control_authority"] = current_authority
            # Pixhawk Home verification/readiness (services/set_home_service.py
            # on the vehicle Flask side, folded into vehicle_state["agent"] --
            # see agent_state.py there) -- passed through as-is, same idiom as
            # control_authority above, so the operator backend gets it via the
            # existing POST /agent/status push rather than a separate endpoint
            # the frontend would need to poll directly.
            agent_status["home_status"] = vehicle_state.get("agent", {}).get("home_status")
            agent_status["current_policy"] = current_policy
            agent_status["current_decision"] = current_decision
            agent_status["decision_reason"] = current_decision_reason
            agent_status["previous_decision"] = previous_decision
            agent_status["previous_decision_reason"] = previous_decision_reason
            agent_status["decision_confidence"] = decision_confidence
            agent_status["decision_confidence_missing_inputs"] = decision_confidence_missing
            agent_status["decision_inputs"] = decision_inputs
            agent_status["watch_conditions"] = watch_conditions
            agent_status["decision_timeline"] = transition_log.get_recent_by_type("decision")
            agent_status["situation"] = situation
            # last_transition reflects the most recent *real* transition this
            # Local Agent has recorded (communication/mission/authority/
            # decision) -- see transition_reasons.py -- kept as its own field
            # rather than overwriting decision_reason, which now always comes
            # straight from this iteration's own decision engine evaluation.
            agent_status["last_transition"] = transition_log.last()

            payload = {
                "usv_id": USV_ID,
                "name": USV_NAME,
                "comm_state": comm_state,
                "groups": groups,
                "telemetry": vehicle_state.get("telemetry", {}),
                "mavlink": decision_engine.build_mavlink_evidence(vehicle_state),
                "mission": mission_payload,
                "communication": get_communication_status(comm_state, last_success_ts),
                "agent": agent_status,
                "health": vehicle_state.get("health", {}),
                "measurements": vehicle_state.get("measurements", {}),
                "events": vehicle_state.get("events", []) + local_events,
                # Rolling audit trail (up to the latest 100) of every
                # communication/mission/authority transition this process has
                # observed, each with the concrete trigger -- see
                # transition_log.py. Unlike `events` above, this is never
                # cleared on a successful send, so a reconnecting operator
                # backend always gets the full recent history, not just a delta.
                "transitions": transition_log.get_recent(),
            }

            message = make_message(
                message_type="status",
                source=USV_ID,
                target="operator",
                payload=payload
            )

            try:
                response = send_to_operator("/agent/status", message)
                print("[LOCAL AGENT] Sent:", comm_state, mission_state, response)
                last_success_ts = time.time()
                local_events.clear()
            except Exception as e:
                buffer_message(message)
                print(f"[LOCAL AGENT] Could not send, buffering (buffer now {count_buffered_packets()} total):", e)

            time.sleep(telemetry_interval(comm_state))
    except KeyboardInterrupt:
        print("\n[LOCAL AGENT] Shutdown requested (Ctrl+C), exiting cleanly.")


if __name__ == "__main__":
    main()
