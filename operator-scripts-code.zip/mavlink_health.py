"""
MAVLink link health -- explicit connection/freshness/rate evidence for the
operator station, instead of making it infer link quality from telemetry
presence alone.

Pure computation on envelopes the caller (services/agent_state.py) already
fetched this request -- no mav_get of its own, so this adds zero extra
mavlink2rest calls. The only state kept here is a rolling window of
HEARTBEAT arrival times, used to measure an actual message rate rather than
assume one.

Every field is a real read or None -- nothing here is invented. In
particular `parser_errors` is always None today: mavlink2rest's message-cache
API (the only interface this Flask process talks to it through) does not
expose a parse-error/drop counter, so there is nothing real to report yet.
"""
import time
from collections import deque
from typing import Optional

from services.mavlink_message_utils import message_age_seconds, last_update_token

# MAVLink's own liveness convention: a HEARTBEAT is expected at ~1Hz, and a
# vehicle is conventionally considered "lost" after ~3 missed periods.
HEARTBEAT_TIMEOUT_S = 3.0

# Rolling window of *distinct* HEARTBEAT arrival wall-clock times (only
# advances when last_update actually changes -- polling the same cached
# message faster than Pixhawk sends it must not inflate the rate).
_HEARTBEAT_ARRIVALS = deque(maxlen=50)
_last_heartbeat_token: Optional[str] = None


def _record_heartbeat_arrival(hb: Optional[dict]) -> None:
    global _last_heartbeat_token
    token = last_update_token(hb)
    if token is None or token == _last_heartbeat_token:
        return
    _last_heartbeat_token = token
    _HEARTBEAT_ARRIVALS.append(time.time())


def _heartbeat_rate_hz() -> Optional[float]:
    """Measured over the arrivals currently in the window -- None until at
    least two distinct HEARTBEATs have been observed (a single sample can't
    imply a rate)."""
    if len(_HEARTBEAT_ARRIVALS) < 2:
        return None
    span = _HEARTBEAT_ARRIVALS[-1] - _HEARTBEAT_ARRIVALS[0]
    if span <= 0:
        return None
    return round((len(_HEARTBEAT_ARRIVALS) - 1) / span, 2)


def build_mavlink_health(hb, pos, hud, bat, gps_raw) -> dict:
    """
    hb/pos/hud/bat/gps_raw are the same HEARTBEAT/GLOBAL_POSITION_INT/
    VFR_HUD/BATTERY_STATUS/GPS_RAW_INT envelopes (or None) agent_state.py
    already fetched this request -- passed in rather than re-fetched.
    """
    _record_heartbeat_arrival(hb)

    heartbeat_age_s = message_age_seconds(hb)
    mavlink_connected = None
    if heartbeat_age_s is not None:
        mavlink_connected = heartbeat_age_s < HEARTBEAT_TIMEOUT_S
    # hb is None means either "mavlink2rest is unreachable" or "Pixhawk has
    # never sent a HEARTBEAT yet" -- this process can't tell those apart
    # (see agent_state.py's _pixhawk_ok comment), so mavlink_connected stays
    # None (unknown) rather than guessing False.

    ages = [
        a for a in (
            message_age_seconds(hb), message_age_seconds(pos),
            message_age_seconds(hud), message_age_seconds(bat),
            message_age_seconds(gps_raw),
        ) if a is not None
    ]

    return {
        "mavlink_connected": mavlink_connected,
        "heartbeat_age_s": round(heartbeat_age_s, 2) if heartbeat_age_s is not None else None,
        "mavlink_last_msg_age_s": round(min(ages), 2) if ages else None,
        "mavlink_msg_rate_hz": _heartbeat_rate_hz(),
        "parser_errors": None,  # not exposed by mavlink2rest's message-cache API
        "measured_at": round(time.time(), 2),
    }
