"""
Standalone tests for services/set_home_service.py. No pytest dependency --
run directly:

    python3 test_set_home_service.py

Fakes mav_get/mav_post with a small stateful "fake vehicle" modelling
mavlink2rest's real behavior for GLOBAL_POSITION_INT (a continuous stream,
read as-is with an age derived from its own timestamp -- no request/
response handshake), COMMAND_ACK, and HOME_POSITION (both single-slot
caches that only advance after a matching COMMAND_LONG has been posted and
the simulated Pixhawk has had time to answer -- exactly the "never expires
a cached message" trap set_home_service.py's freshness checking exists to
defeat, same idea as test_mission_service.py's FakeVehicle). No live
mavlink2rest or Pixhawk required.
"""
import time
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

import services.set_home_service as set_home_service


class FakeVehicle:
    def __init__(self):
        self.lat = 56.6505
        self.lon = 12.8707
        self.time_boot_ms = 100_000
        self.position_available = True
        self.position_age_s = 0.0

        self.ack_result = "MAV_RESULT_ACCEPTED"
        self.ack_never_arrives = False
        self.ack_wrong_command = False

        # What MAV_CMD_GET_HOME_POSITION resolves the Home to once posted;
        # defaults to matching (lat, lon) i.e. a clean successful Set Home.
        self.home_result = None
        self.home_never_updates = False

        self.post_log = []
        self._token_n = 0

        self._ack_cached = None
        self._ack_cached_token = None
        self._ack_pending = None

        self._home_cached = None
        self._home_cached_token = None
        self._home_pending = None

    def _new_token(self, age_s=0.0):
        self._token_n += 1
        ts = datetime.now(timezone.utc) - timedelta(seconds=age_s) + timedelta(microseconds=self._token_n)
        return ts.isoformat()

    def seed_home(self, lat, lon, alt=1.2):
        """Pre-populate HOME_POSITION as if ArduPilot already broadcast one
        earlier (e.g. the stale garage Home before any Set Home call)."""
        self._home_cached = {
            "latitude": int(lat * 1e7), "longitude": int(lon * 1e7), "altitude": int(alt * 1000),
        }
        self._home_cached_token = self._new_token()

    def inject_home_position(self, lat, lon, alt=1.2):
        """Simulates an unsolicited HOME_POSITION broadcast (e.g. another
        GCS, or ArduPilot re-deriving home on arm) -- directly overwrites
        the cache slot with a fresh token, bypassing the
        post-a-command-then-resolve flow real Set Home calls go through."""
        self.seed_home(lat, lon, alt)

    def mav_post(self, data):
        self.post_log.append(data)
        if data.get("type") != "COMMAND_LONG":
            return
        command = (data.get("command") or {}).get("type")
        if command == "MAV_CMD_DO_SET_HOME":
            if not self.ack_never_arrives:
                acked_command = "MAV_CMD_COMPONENT_ARM_DISARM" if self.ack_wrong_command else "MAV_CMD_DO_SET_HOME"
                self._ack_pending = (self._new_token(), acked_command, self.ack_result)
        elif command == "MAV_CMD_GET_HOME_POSITION":
            if not self.home_never_updates:
                home = self.home_result if self.home_result is not None else {"latitude": self.lat, "longitude": self.lon, "altitude": 1.2}
                self._home_pending = (self._new_token(), home)

    def _resolve_ack(self):
        if self._ack_pending:
            token, command, result = self._ack_pending
            self._ack_cached = {"command": {"type": command}, "result": {"type": result}}
            self._ack_cached_token = token
            self._ack_pending = None

    def _resolve_home(self):
        if self._home_pending:
            token, home = self._home_pending
            self._home_cached = {
                "latitude": int(home["latitude"] * 1e7),
                "longitude": int(home["longitude"] * 1e7),
                "altitude": int(home.get("altitude", 1.2) * 1000),
            }
            self._home_cached_token = token
            self._home_pending = None

    def mav_get(self, path):
        if path.endswith("GLOBAL_POSITION_INT"):
            if not self.position_available:
                raise RuntimeError("no data")
            token = self._new_token(age_s=self.position_age_s)
            return {
                "message": {"lat": int(self.lat * 1e7), "lon": int(self.lon * 1e7), "time_boot_ms": self.time_boot_ms},
                "status": {"time": {"last_update": token}},
            }
        if path.endswith("COMMAND_ACK"):
            self._resolve_ack()
            if self._ack_cached is None:
                raise RuntimeError("no data")
            return {"message": dict(self._ack_cached), "status": {"time": {"last_update": self._ack_cached_token}}}
        if path.endswith("HOME_POSITION"):
            self._resolve_home()
            if self._home_cached is None:
                raise RuntimeError("no data")
            return {"message": dict(self._home_cached), "status": {"time": {"last_update": self._home_cached_token}}}
        raise RuntimeError(f"unexpected path: {path}")


def _init(vehicle, reachable=True):
    set_home_service.init(
        mav_get_fn=vehicle.mav_get,
        mav_post_fn=vehicle.mav_post,
        mavlink_base_url="http://mavlink2rest.invalid",
    )
    set_home_service.reset_verification_for_tests()
    return patch.object(set_home_service, "mavlink2rest_reachable", return_value=reachable)


class FastTimeoutsMixin:
    """Shrinks every timeout/retry/poll constant so timeout-path tests run
    in well under a second instead of tens of seconds."""

    def setUp(self):
        self._patches = [
            patch.object(set_home_service, "_POLL_INTERVAL_S", 0.001),
            patch.object(set_home_service, "_ACK_TIMEOUT_S", 0.05),
            patch.object(set_home_service, "_HOME_TIMEOUT_S", 0.05),
            patch.object(set_home_service, "_ACK_MAX_RETRIES", 2),
            patch.object(set_home_service, "_HOME_MAX_RETRIES", 2),
        ]
        for p in self._patches:
            p.start()

    def tearDown(self):
        for p in self._patches:
            p.stop()
        set_home_service.reset_verification_for_tests()


class TestSuccessfulSetHome(FastTimeoutsMixin, unittest.TestCase):
    def test_successful_set_home_at_current_position(self):
        vehicle = FakeVehicle()
        with _init(vehicle):
            result = set_home_service.set_home_current_position("cmd-1")

        self.assertTrue(result["accepted"])
        self.assertTrue(result["verified"])
        self.assertEqual(result["command_id"], "cmd-1")
        self.assertAlmostEqual(result["requested_position"]["latitude"], 56.6505, places=6)
        self.assertAlmostEqual(result["home_position"]["latitude"], 56.6505, places=6)
        self.assertLess(result["verification_distance_m"], 1.0)
        self.assertEqual(result["ack_result"], "MAV_RESULT_ACCEPTED")
        self.assertIsNone(result["error"])

    def test_successful_set_home_latches_verification_state(self):
        vehicle = FakeVehicle()
        with _init(vehicle):
            set_home_service.set_home_current_position("cmd-2")
            status = set_home_service.get_home_status()

        self.assertTrue(status["verified"])
        self.assertEqual(status["verification_method"], "set_home_current_position")
        self.assertIsNotNone(status["verification_distance_m"])
        self.assertLess(status["verification_distance_m"], 1.0)
        self.assertTrue(status["ready_for_auto"])
        self.assertTrue(status["ready_for_rtl"])

    def test_never_touches_mission_messages(self):
        """Set Home must never post a MISSION_* message -- Home (mission
        sequence 0) and the mission's own executable items (1..N) are
        handled by entirely separate MAVLink messages."""
        vehicle = FakeVehicle()
        with _init(vehicle):
            set_home_service.set_home_current_position("cmd-3")

        for posted in vehicle.post_log:
            self.assertEqual(posted["type"], "COMMAND_LONG")
            self.assertNotIn("MISSION", posted["command"]["type"])


class TestStaleAndInvalidPosition(FastTimeoutsMixin, unittest.TestCase):
    def test_stale_gps_rejected(self):
        vehicle = FakeVehicle()
        vehicle.position_age_s = 10.0
        with _init(vehicle):
            result = set_home_service.set_home_current_position("cmd-4", freshness_s=1.0)

        self.assertFalse(result["accepted"])
        self.assertFalse(result["verified"])
        self.assertEqual(result["error"]["code"], "POSITION_STALE")

    def test_invalid_zero_zero_coordinates_rejected(self):
        vehicle = FakeVehicle()
        vehicle.lat = 0.0
        vehicle.lon = 0.0
        with _init(vehicle):
            result = set_home_service.set_home_current_position("cmd-5")

        self.assertFalse(result["accepted"])
        self.assertEqual(result["error"]["code"], "INVALID_POSITION")

    def test_missing_position_rejected(self):
        vehicle = FakeVehicle()
        vehicle.position_available = False
        with _init(vehicle):
            result = set_home_service.set_home_current_position("cmd-6")

        self.assertFalse(result["accepted"])
        self.assertEqual(result["error"]["code"], "POSITION_UNAVAILABLE")


class TestPixhawkUnreachable(FastTimeoutsMixin, unittest.TestCase):
    def test_pixhawk_unreachable_rejected(self):
        vehicle = FakeVehicle()
        with _init(vehicle, reachable=False):
            result = set_home_service.set_home_current_position("cmd-7")

        self.assertFalse(result["accepted"])
        self.assertEqual(result["error"]["code"], "PIXHAWK_UNREACHABLE")


class TestAckHandling(FastTimeoutsMixin, unittest.TestCase):
    def test_negative_command_ack_rejected(self):
        vehicle = FakeVehicle()
        vehicle.ack_result = "MAV_RESULT_DENIED"
        with _init(vehicle):
            result = set_home_service.set_home_current_position("cmd-8")

        self.assertFalse(result["accepted"])
        self.assertFalse(result["verified"])
        self.assertEqual(result["error"]["code"], "ACK_REJECTED")
        self.assertEqual(result["ack_result"], "MAV_RESULT_DENIED")

    def test_ack_timeout_rejected(self):
        vehicle = FakeVehicle()
        vehicle.ack_never_arrives = True
        with _init(vehicle):
            result = set_home_service.set_home_current_position("cmd-9")

        self.assertFalse(result["accepted"])
        self.assertEqual(result["error"]["code"], "ACK_TIMEOUT")

    def test_stale_unrelated_ack_does_not_satisfy_wait(self):
        """A COMMAND_ACK for a different command lingering in mavlink2rest's
        single cache slot must never be mistaken for this Set Home's own
        ack -- this should behave exactly like no ack ever arriving."""
        vehicle = FakeVehicle()
        vehicle.ack_wrong_command = True
        with _init(vehicle):
            result = set_home_service.set_home_current_position("cmd-10")

        self.assertFalse(result["accepted"])
        self.assertEqual(result["error"]["code"], "ACK_TIMEOUT")


class TestHomePositionHandling(FastTimeoutsMixin, unittest.TestCase):
    def test_home_position_timeout_rejected(self):
        vehicle = FakeVehicle()
        vehicle.home_never_updates = True
        with _init(vehicle):
            result = set_home_service.set_home_current_position("cmd-11")

        self.assertFalse(result["accepted"])
        self.assertEqual(result["error"]["code"], "HOME_POSITION_TIMEOUT")
        self.assertEqual(result["ack_result"], "MAV_RESULT_ACCEPTED")

    def test_home_outside_tolerance_rejected(self):
        vehicle = FakeVehicle()
        vehicle.home_result = {"latitude": vehicle.lat + 1.0, "longitude": vehicle.lon, "altitude": 1.2}
        with _init(vehicle):
            result = set_home_service.set_home_current_position("cmd-12", tolerance_m=5.0)

        self.assertFalse(result["accepted"])
        self.assertFalse(result["verified"])
        self.assertEqual(result["error"]["code"], "VERIFICATION_TOLERANCE_EXCEEDED")
        self.assertIsNotNone(result["home_position"])
        self.assertGreater(result["verification_distance_m"], 5.0)

    def test_home_within_tolerance_accepted(self):
        vehicle = FakeVehicle()
        # ~2m north-ish jitter, within the 5m default tolerance.
        vehicle.home_result = {"latitude": vehicle.lat + 0.000018, "longitude": vehicle.lon, "altitude": 1.2}
        with _init(vehicle):
            result = set_home_service.set_home_current_position("cmd-13")

        self.assertTrue(result["accepted"])
        self.assertTrue(result["verified"])


class TestDuplicateAndExpiry(FastTimeoutsMixin, unittest.TestCase):
    """set_home_service.py itself has no command_id dedup/expiry concept --
    that lives at the command-protocol layer
    (motherpi/services/local_mission_agent/set_home_handler.py, tested in
    test_set_home_handler.py there) so a retried command_id is rejected
    before ever reaching this module. Calling this module twice with the
    same command_id is otherwise a harmless idempotent Set Home -- asserted
    here so that division of responsibility is explicit."""

    def test_calling_twice_with_same_command_id_is_idempotent_here(self):
        vehicle = FakeVehicle()
        with _init(vehicle):
            first = set_home_service.set_home_current_position("dup-1")
            second = set_home_service.set_home_current_position("dup-1")

        self.assertTrue(first["verified"])
        self.assertTrue(second["verified"])


class TestVerificationInvalidation(FastTimeoutsMixin, unittest.TestCase):
    def test_reboot_invalidates_verification(self):
        vehicle = FakeVehicle()
        vehicle.time_boot_ms = 500_000
        with _init(vehicle):
            result = set_home_service.set_home_current_position("cmd-14")
            self.assertTrue(result["verified"])

            # Simulate a Pixhawk reboot/reconnect: time_boot_ms resets to a
            # small value (milliseconds since the *new* boot).
            vehicle.time_boot_ms = 1_000
            status = set_home_service.get_home_status()

        self.assertFalse(status["verified"])
        self.assertFalse(status["ready_for_auto"])
        self.assertFalse(status["ready_for_rtl"])
        self.assertIsNone(status["verification_distance_m"])

    def test_home_drift_invalidates_verification(self):
        vehicle = FakeVehicle()
        with _init(vehicle):
            result = set_home_service.set_home_current_position("cmd-15")
            self.assertTrue(result["verified"])

            # Something other than this module moves Home far away without
            # a new Set Home call (e.g. another GCS, or ArduPilot re-deriving
            # home on a later arm at a different spot).
            vehicle.inject_home_position(vehicle.lat + 1.0, vehicle.lon)
            status = set_home_service.get_home_status()

        self.assertFalse(status["verified"])

    def test_small_home_jitter_does_not_invalidate_verification(self):
        """HOME_DRIFT_INVALIDATION_M is deliberately looser than the tight
        just-set tolerance so ordinary GPS jitter around the same point
        doesn't spuriously invalidate a real verification."""
        vehicle = FakeVehicle()
        with _init(vehicle):
            set_home_service.set_home_current_position("cmd-16")
            vehicle.inject_home_position(vehicle.lat + 0.00003, vehicle.lon)  # ~3m
            status = set_home_service.get_home_status()

        self.assertTrue(status["verified"])

    def test_vehicle_driving_away_from_home_does_not_invalidate_verification(self):
        """The expected outcome of a mission (driving far from the verified
        recovery point) must never be mistaken for Home being wrong --
        distance_from_vehicle_m is informational only, never a gating
        input."""
        vehicle = FakeVehicle()
        with _init(vehicle):
            set_home_service.set_home_current_position("cmd-17")
            vehicle.lat += 0.05  # ~5.5km away -- a normal mission transit
            status = set_home_service.get_home_status()

        self.assertTrue(status["verified"])
        self.assertTrue(status["ready_for_auto"])
        self.assertGreater(status["distance_from_vehicle_m"], 1000)


class TestHomeStatusUnverifiedByDefault(FastTimeoutsMixin, unittest.TestCase):
    def test_never_verified_this_runtime_reports_unready(self):
        vehicle = FakeVehicle()
        vehicle.seed_home(56.0, 12.0)  # a stale Home coincidentally present, never verified by this module
        with _init(vehicle):
            status = set_home_service.get_home_status()

        self.assertFalse(status["verified"])
        self.assertFalse(status["ready_for_auto"])
        self.assertFalse(status["ready_for_rtl"])
        self.assertIsNotNone(status["reason"])
        self.assertIsNone(status["verification_distance_m"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
