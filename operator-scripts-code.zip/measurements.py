import random
import logging
from measuring.Adc import AdcManager
from measuring.pingsonar import pingSonarManager

from measuring.trios.Oil import Oil
from measuring.trios.NicoSensor import Nico
from measuring.trios.ph import PH
from measuring.trios.phd import PHD
from measuring.trios.DO import DO
from measuring.trios.cDOM import cDOM
from measuring.Conductivity import DFRobot_EC
from measuring.PFAS import PfasManager
import datetime as datetime
import time
from typing import Optional

from logging_setup import configure_logging

configure_logging(service_name="sensor-service")
logger = logging.getLogger(__name__)

class MeasurementManager:
    
    def __init__(self):
        self.calbrationDone = False
        self.Adc = None
        self.sonar = None
        self.ph = None
        self.phd = None
        self.oil = None
        self.Nico = None
        self.do = None
        self.cDOM = None
        self.conductivity = None
        self.PFAS = None

        self._health = {}
        for name in [
            "adc",
            "sonar",
            "ph",
            "phd",
            "oil",
            "nico",
            "do",
            "cdom",
            "conductivity",
            "pfas",
        ]:
            self._health[name] = {
                "available": False,
                "connected": None,
                "last_ok": None,
                "last_error": None,
                "last_error_at": None,
            }

        # Initialize all sensors with error handling
        try:
            self.Adc = AdcManager()
            self._set_health("adc", available=self.Adc is not None)
        except Exception as e:
            logger.warning("Failed to initialize AdcManager", exc_info=True)
            self._set_health("adc", available=False, ok=False, error=str(e))
        
        try:
            self.sonar = pingSonarManager()
            self._set_health("sonar", available=self.sonar is not None)
        except Exception as e:
            logger.warning("Failed to initialize pingSonarManager", exc_info=True)
            self._set_health("sonar", available=False, ok=False, error=str(e))
        
        try:
            self.ph = PH()
            self._set_health("ph", available=self.ph is not None, connected=getattr(self.ph, "connected", None))
        except Exception as e:
            logger.warning("Failed to initialize PH sensor", exc_info=True)
            self._set_health("ph", available=False, ok=False, error=str(e))
        
        try:
            self.phd = PHD()
            self._set_health("phd", available=self.phd is not None, connected=getattr(self.phd, "connected", None))
        except Exception as e:
            logger.warning("Failed to initialize PHD sensor", exc_info=True)
            self._set_health("phd", available=False, ok=False, error=str(e))
        
        try:
            self.oil = Oil()
            self._set_health("oil", available=self.oil is not None, connected=getattr(self.oil, "connected", None))
        except Exception as e:
            logger.warning("Failed to initialize Oil sensor", exc_info=True)
            self._set_health("oil", available=False, ok=False, error=str(e))
        
        try:
            self.Nico = Nico()
            self._set_health("nico", available=self.Nico is not None, connected=getattr(self.Nico, "connected", None))
        except Exception as e:
            logger.warning("Failed to initialize Nico sensor", exc_info=True)
            self._set_health("nico", available=False, ok=False, error=str(e))
        
        try:
            self.do = DO()
            self._set_health("do", available=self.do is not None, connected=getattr(self.do, "connected", None))
        except Exception as e:
            logger.warning("Failed to initialize DO sensor", exc_info=True)
            self._set_health("do", available=False, ok=False, error=str(e))
        
        try:
            self.cDOM = cDOM()
            self._set_health("cdom", available=self.cDOM is not None, connected=getattr(self.cDOM, "connected", None))
        except Exception as e:
            logger.warning("Failed to initialize cDOM sensor", exc_info=True)
            self._set_health("cdom", available=False, ok=False, error=str(e))
        
        try:
            self.conductivity = DFRobot_EC()
            if self.conductivity:
                self.conductivity.begin()
            self._set_health("conductivity", available=self.conductivity is not None)
        except Exception as e:
            logger.warning("Failed to initialize Conductivity sensor", exc_info=True)
            self._set_health("conductivity", available=False, ok=False, error=str(e))
        
        try:
            self.PFAS = PfasManager()
            self._set_health("pfas", available=self.PFAS is not None, connected=getattr(self.PFAS, "connected", None))
        except Exception as e:
            logger.warning("Failed to initialize PFAS sensor", exc_info=True)
            self._set_health("pfas", available=False, ok=False, error=str(e))

    def _set_health(
        self,
        name: str,
        *,
        available=None,
        connected=None,
        ok: Optional[bool] = None,
        error: Optional[str] = None,
    ) -> None:
        h = self._health.get(name)
        if h is None:
            h = {
                "available": False,
                "connected": None,
                "last_ok": None,
                "last_error": None,
                "last_error_at": None,
            }
            self._health[name] = h

        if available is not None:
            h["available"] = bool(available)
        if connected is not None:
            h["connected"] = connected

        now = datetime.datetime.now()
        if ok is True:
            h["last_ok"] = now
            h["last_error"] = None
            h["last_error_at"] = None
        elif ok is False and error:
            h["last_error"] = error
            h["last_error_at"] = now

    def get_status(self):
        """Return per-sensor health/status for observability."""
        def _dt(v):
            return v.isoformat() if isinstance(v, datetime.datetime) else None

        status = {}
        for name, h in self._health.items():
            status[name] = {
                "available": h.get("available", False),
                "connected": h.get("connected", None),
                "last_ok": _dt(h.get("last_ok")),
                "last_error": h.get("last_error"),
                "last_error_at": _dt(h.get("last_error_at")),
            }
        return status
    
    
    def Measure_Water_Leakage(self):
        try:
            return {"leak": 0}
            #return self.GPIO1.ReadPin("Leak")
        except Exception as e:
            logger.warning("Unable to read leak sensor", exc_info=True)
            return {"leak": None}



    
    
    

    #If no argument is given. It will only return non sensitive measurements
    #non sensitive measurements are defined as the measurements that can be taken an 
    #Unlimited amount of times without risking the longevity of the sensor
    
    
    def GetMeasurements(self, sensitive_measurements=True):
        global current_mission_id

        data = {}

        #MissionID is set as tag in the main app
        #Position is set in the main app
        
        #Add timestamp
        data["timestamp"] = datetime.datetime.now()

        #Battery voltage
        try:
            if self.Adc:
                data.update(self.Adc.Get_Battery_Voltage())
                self._set_health("adc", available=True, ok=True)
        except Exception as e:
            logger.exception("Error getting battery voltage")
            self._set_health("adc", available=self.Adc is not None, ok=False, error=str(e))

        #Depth
        try:
            if self.sonar:
                sonar_data = self.sonar.GetDistance()
                data.update(sonar_data)
                depth = sonar_data.get("depth")
                if depth == -2:
                    self._set_health("sonar", available=True, connected=False, ok=False, error="not_connected")
                elif depth == -1:
                    self._set_health("sonar", available=True, connected=True, ok=False, error="read_error_or_low_confidence")
                else:
                    self._set_health("sonar", available=True, connected=True, ok=True)
        except Exception as e:
            logger.exception("Error getting depth")
            self._set_health("sonar", available=self.sonar is not None, ok=False, error=str(e))
        
        #Water leakage
        try:
            leak_data = self.Measure_Water_Leakage()
            if leak_data:
                data.update(leak_data)
        except Exception as e:
            logger.exception("Error measuring water leakage")
                
        if(not sensitive_measurements):
            return data
        #Add sensitive measurements here
        
        #PH sensor
        try:
            if self.ph:
                ph_data = self.ph.Measure()
                if ph_data:
                    data.update(ph_data)
                self._set_health(
                    "ph",
                    available=True,
                    connected=getattr(self.ph, "connected", None),
                    ok=getattr(self.ph, "connected", None) is not False,
                )
        except Exception as e:
            logger.exception("Error reading PH sensor")
            self._set_health("ph", available=self.ph is not None, ok=False, error=str(e))
        
        #PHD sensor
        try:
            if self.phd:
                phd_data = self.phd.Measure()
                if phd_data:
                    data.update(phd_data)
                self._set_health(
                    "phd",
                    available=True,
                    connected=getattr(self.phd, "connected", None),
                    ok=getattr(self.phd, "connected", None) is not False,
                )
        except Exception as e:
            logger.exception("Error reading PHD sensor")
            self._set_health("phd", available=self.phd is not None, ok=False, error=str(e))
        
        #MicroFlu 
        try:
            if self.oil:
                oil_data = self.oil.Measure()
                if oil_data:
                    data.update(oil_data)
                self._set_health(
                    "oil",
                    available=True,
                    connected=getattr(self.oil, "connected", None),
                    ok=getattr(self.oil, "connected", None) is not False,
                )
        except Exception as e:
            logger.exception("Error reading Oil sensor")
            self._set_health("oil", available=self.oil is not None, ok=False, error=str(e))

        #Nico
        try:
            if self.Nico:
                nico_data = self.Nico.Measure()
                if nico_data:
                    data.update(nico_data)
                self._set_health(
                    "nico",
                    available=True,
                    connected=getattr(self.Nico, "connected", None),
                    ok=getattr(self.Nico, "connected", None) is not False,
                )
        except Exception as e:
            logger.exception("Error reading Nico sensor")
            self._set_health("nico", available=self.Nico is not None, ok=False, error=str(e))
        
        #DO
        #try:
        #    if self.do:
        #        do_data = self.do.Measure()
        #        if do_data:
        #            data.update(do_data)
        #except Exception as e:
        #    print(f"Error reading DO sensor: {e}")
        #    traceback.print_exc()
        
        #Cdom
        try:
            if self.cDOM:
                cdom_data = self.cDOM.Measure()
                if cdom_data:
                    data.update(cdom_data)
                self._set_health(
                    "cdom",
                    available=True,
                    connected=getattr(self.cDOM, "connected", None),
                    ok=getattr(self.cDOM, "connected", None) is not False,
                )
        except Exception as e:
            logger.exception("Error reading cDOM sensor")
            self._set_health("cdom", available=self.cDOM is not None, ok=False, error=str(e))

        #Conductivity is currently calculated from raw Adc value and the latest calibration curve WITHOUT temperature compensation!
        try:
            if self.Adc:
                raw_adc = self.Adc.GetAnalogMeasurement(2)
                
                if raw_adc == 0 or raw_adc is None:
                    data["Conductivity"] = None
                else:
                    calc_conductivity = 6542.3 * raw_adc - 16.727
                    data["Conductivity"] = calc_conductivity
                self._set_health("conductivity", available=True, ok=True)
        except Exception as e:
            logger.exception("Error calculating conductivity")
            self._set_health("conductivity", available=self.Adc is not None, ok=False, error=str(e))
        
        ##TODO use DFRobots conductivity code with integrated T compensation
        #if (data.get("watertemperature") is not None and self.conductivity):
        #    try:
        #        data["Conductivity"] = self.conductivity.readEC(self.Adc.GetAnalogMeasurement(2),data["watertemperature"])
        #    except Exception as e:
        #        print(f"Error reading conductivity with temperature compensation: {e}")
        
        #For calibrating
        #    if (self.calbrationDone is False):
        #        self.calbrationDone = True
        #        self.conductivity.calibration(self.Adc.GetAnalogMeasurement(2),data["watertemperature"])
        #        print("Conductivity calibrated")

        #PFAS
        #try:
        #    if self.PFAS:
        #        pfas_points = self.PFAS.GetPFAS()
        #except Exception as e:
        #    print(f"Error reading PFAS sensor: {e}")
        #    pfas_points = []
        
        return data # add , pfas_points
    

if __name__ =='__main__':
    dc = MeasurementManager()
    print(dc.GetMeasurements())
