"""
Single source of truth for the Scout's agent state.

Call init() once at app startup to register the mav_get function,
service URLs, and a getter for the app's immutable scalars.
"""
import time
from typing import Callable

import services.state as _state
from services.event_log import get_recent
from services.health_service import build_health
from services import control_authority
from services import set_home_service
from services.mavlink_health import build_mavlink_health
from services.mavlink_message_utils import gps_fix_type_num, gps_satellites_visible
from services.mode_verification import ARDUROVER_MODE_NAMES

_mav_get: Callable | None = None
_sensor_url: str | None = None
_gpio_socket_path: str | None = None
_get_app_state: Callable | None = None


def init(
    mav_get_fn: Callable,
    sensor_url: str,
    gpio_socket_path: str,
    app_state_getter: Callable,
) -> None:
    """
    Register dependencies from app.py.

    app_state_getter must be a zero-arg callable that returns a dict with keys:
      mission_active, current_mission_id, take_sensitive_measurements, measurementDelay
    """
    global _mav_get, _sensor_url, _gpio_socket_path, _get_app_state
    _mav_get = mav_get_fn
    _sensor_url = sensor_url
    _gpio_socket_path = gpio_socket_path
    _get_app_state = app_state_getter



def _mode_name(custom_mode) -> "str | None":
    """ArduRover custom_mode -> name, from the one name<->int table
    services/mode_verification.py owns (also used there to resolve a mode
    name to its custom_mode int before sending MAV_CMD_DO_SET_MODE) --
    not a second copy of the same enum. Unmapped values (a firmware version
    with a mode this table predates) fall back to "MODE_<n>" rather than a
    guessed name -- the raw int stays available as telemetry.mode either way.
    """
    if not isinstance(custom_mode, int):
        return None
    return ARDUROVER_MODE_NAMES.get(custom_mode, f"MODE_{custom_mode}")


def _battery_voltage(bat) -> "float | None":
    """Pack voltage isn't its own BATTERY_STATUS field -- sum the populated
    cell entries in `voltages` (mV each; unpopulated cells report 65535,
    MAVLink's UINT16_MAX sentinel for "not present")."""
    try:
        voltages = bat["message"]["voltages"]
        valid = [v for v in voltages if isinstance(v, int) and 0 < v < 65535]
        return round(sum(valid) / 1000.0, 2) if valid else None
    except Exception:
        return None


def _battery_current(bat) -> "float | None":
    """current_battery is centiamps; ArduPilot reports -1 when no current
    sensor is configured, which is "not measured", not "zero amps"."""
    try:
        current = bat["message"]["current_battery"]
        return round(current / 100.0, 2) if isinstance(current, int) and current >= 0 else None
    except Exception:
        return None


# EKF_STATUS_REPORT.flags bit values (ArduPilot EKF_STATUS_FLAGS enum).
_EKF_ATTITUDE = 1
_EKF_VELOCITY_HORIZ = 2
_EKF_POS_HORIZ_ABS = 16
_EKF_POS_VERT_ABS = 32
_EKF_CONST_POS_MODE = 128
_EKF_OK_MASK = _EKF_ATTITUDE | _EKF_VELOCITY_HORIZ | _EKF_POS_HORIZ_ABS | _EKF_POS_VERT_ABS


def _ekf_ok(ekf) -> "bool | None":
    """
    Standard "is the EKF healthy" heuristic (same bits QGroundControl/MAVSDK
    check): attitude + horizontal velocity + absolute horizontal/vertical
    position estimates all present, and not running in dead-reckoning
    constant-position mode. None if EKF_STATUS_REPORT has never been cached
    (not every firmware/stream configuration sends it).
    """
    if ekf is None:
        return None
    try:
        flags = ekf["message"]["flags"]
        bits = flags["bits"] if isinstance(flags, dict) else flags
        if not isinstance(bits, int):
            return None
        return bool(bits & _EKF_OK_MASK == _EKF_OK_MASK and not (bits & _EKF_CONST_POS_MODE))
    except Exception:
        return None


def build_agent_state() -> dict:
    now = time.time()

    app = _get_app_state()
    mission_active           = app['mission_active']
    current_mission_id       = app['current_mission_id']
    take_sensitive           = app['take_sensitive_measurements']
    measurement_delay        = app['measurementDelay']

    # ── Fetch MAVLink data once, reused across all sections ───────────────────
    # Each message is fetched independently: MISSION_COUNT/MISSION_CURRENT are
    # only ever cached by mavlink2rest after a mission operation (upload/
    # download) has actually happened, unlike HEARTBEAT/GLOBAL_POSITION_INT/
    # VFR_HUD/BATTERY_STATUS/GPS_RAW_INT which stream continuously. Bundling
    # all seven into one try/except meant an absent mission message (never
    # requested yet this session) aborted the fetch before HEARTBEAT's result
    # could mark the Pixhawk connected -- reporting "disconnected" while
    # telemetry/GPS were live and healthy.
    def _safe_mav_get(path):
        try:
            return _mav_get(path)
        except Exception:
            return None

    _pos     = _safe_mav_get('/mavlink/vehicles/1/components/1/messages/GLOBAL_POSITION_INT')
    _hud     = _safe_mav_get('/mavlink/vehicles/1/components/1/messages/VFR_HUD')
    _hb      = _safe_mav_get('/mavlink/vehicles/1/components/1/messages/HEARTBEAT')
    _bat     = _safe_mav_get('/mavlink/vehicles/1/components/1/messages/BATTERY_STATUS')
    _mc      = _safe_mav_get('/mavlink/vehicles/1/components/1/messages/MISSION_COUNT')
    _mcur    = _safe_mav_get('/mavlink/vehicles/1/components/1/messages/MISSION_CURRENT')
    _gps_raw = _safe_mav_get('/mavlink/vehicles/1/components/1/messages/GPS_RAW_INT')
    _ekf     = _safe_mav_get('/mavlink/vehicles/1/components/1/messages/EKF_STATUS_REPORT')

    # HEARTBEAT is MAVLink's own liveness message -- the same signal already
    # used as "is it alive" for /nav/mission_status's `mode` field below.
    _pixhawk_ok = _hb is not None

    # ── Telemetry ─────────────────────────────────────────────────────────────
    # Each field is extracted independently -- a missing GLOBAL_POSITION_INT/
    # VFR_HUD (e.g. no GPS fix yet) must not blank out armed/mode, which come
    # from HEARTBEAT and are frequently the only fields still live when the
    # others aren't. armed is read from the HEARTBEAT base_mode safety-armed
    # bit (128, MAV_MODE_FLAG_SAFETY_ARMED) -- never inferred from custom_mode,
    # since a vehicle can be armed in any mode. Any field whose source message
    # is absent or malformed comes back None rather than a fabricated default.
    def _field(fn):
        try:
            return fn()
        except Exception:
            return None

    lat = _field(lambda: round(_pos['message']['lat'] / 1e7, 7))
    lng = _field(lambda: round(_pos['message']['lon'] / 1e7, 7))
    base_mode_bits = _field(lambda: _hb['message']['base_mode']['bits'])

    custom_mode = _field(lambda: _hb['message']['custom_mode'])

    telemetry = {
        'lat': lat,
        'lng': lng,
        'alt':         _field(lambda: round(_hud['message']['alt'], 2)),
        'heading':     _field(lambda: round(_hud['message']['heading'], 2)),
        'groundspeed': _field(lambda: round(_hud['message']['groundspeed'], 2)),
        'battery':     _field(lambda: _bat['message']['battery_remaining']),
        'mode':        custom_mode,
        'armed':       bool(base_mode_bits & 128) if isinstance(base_mode_bits, int) else None,
        # -- newer fields below; existing lat/lng/alt/heading/groundspeed/
        # battery/mode/armed above are the single source of truth for their
        # data, not duplicated under a second name.
        'mode_name':        _mode_name(custom_mode),
        'battery_voltage':  _battery_voltage(_bat),
        'battery_current':  _battery_current(_bat),
        'gps_fix_type':     gps_fix_type_num(_gps_raw),
        'gps_satellites':   gps_satellites_visible(_gps_raw),
        'ekf_ok':           _ekf_ok(_ekf),
        # Scout is a surface vehicle with no airspeed sensor -- VFR_HUD.airspeed
        # is a synthetic ArduPilot value (not a real measurement) on a rover,
        # so this is deliberately always None rather than reporting a fake 0.
        'airspeed': None,
    }
    if lat is not None and lng is not None:
        _state.gps_log.append({'timestamp': now, 'lat': lat, 'lng': lng})

    # ── Mission ───────────────────────────────────────────────────────────────
    try:
        count   = _mc.get('message', {}).get('count') if _mc else None
        current = _mcur.get('message', {}).get('seq') if _mcur else None
        mode    = _hb.get('message', {}).get('custom_mode') if _hb else None
        mission = {
            'mission_active': mission_active,
            'current_mission_id': current_mission_id,
            'mission_count': count,
            'current_waypoint': current,
            'current_waypoint_display': (
                f"{current} / {count}"
                if current is not None and count is not None else None
            ),
            'mission_state': 'SEARCH' if mission_active else 'IDLE',
            'mode': mode,
        }
    except Exception as e:
        mission = {'error': str(e)}

    # ── Health ────────────────────────────────────────────────────────────────
    try:
        health = build_health(
            sensor_url=_sensor_url,
            gpio_socket_path=_gpio_socket_path,
            pixhawk_ok=_pixhawk_ok,
            bat=_bat,
            gps_raw=_gps_raw,
            sensors_enabled=take_sensitive,
        )
    except Exception as e:
        health = {'error': str(e)}

    # ── MAVLink link health ──────────────────────────────────────────────────
    # Real HEARTBEAT-derived evidence (heartbeat age, measured message rate,
    # connected/None) for the operator to reason about the vehicle<->Pixhawk
    # link directly, instead of inferring it from telemetry presence. See
    # services/mavlink_health.py -- computed from the same envelopes already
    # fetched above, no extra mavlink2rest calls.
    try:
        mavlink = build_mavlink_health(hb=_hb, pos=_pos, hud=_hud, bat=_bat, gps_raw=_gps_raw)
    except Exception as e:
        mavlink = {'error': str(e)}

    # ── Home verification/readiness ──────────────────────────────────────────
    # Folded into this same GET /agent/state response (payload.agent.home_status
    # once forwarded by the Local Agent) rather than a separate endpoint the
    # frontend would need to poll directly -- the Operator Backend is the only
    # thing the frontend ever talks to; this rides the existing push channel
    # (POST /agent/status) exactly like control_authority above. See
    # services/set_home_service.py for what "verified" actually means.
    try:
        home_status = set_home_service.get_home_status()
    except Exception as e:
        home_status = {'error': str(e)}

    # ── Measurements ─────────────────────────────────────────────────────────
    measurements = {
        'latest': {
            'temperature':  _state.latest_measurements.get('temperature'),
            'ph':           _state.latest_measurements.get('ph'),
            'conductivity': _state.latest_measurements.get('conductivity'),
            'turbidity':    _state.latest_measurements.get('turbidity'),
        },
        'sampling': {
            'enabled':     take_sensitive,
            'interval':    measurement_delay,
            'last_sample': _state.latest_measurements.get('last_sample'),
        },
    }

    return {
        'state_timestamp': round(now, 2),
        'telemetry':     telemetry,
        'mission':       mission,
        'mavlink':       mavlink,
        'communication': {
            'connectivity':                 'CONNECTED',
            'local_state_available':        True,
            'operator_reachable':           True,
            'last_successful_transmission': None,
            'buffered_packets':             None,
            'rtt_ms':                       None,
            'packet_loss':                  None,
            'bandwidth_estimate_kbps':      None,
            'vpn_status':                   None,
        },
        'health': health,
        'agent': {
            'current_communication_state': 'CONNECTED',
            'current_mission_state':       'SEARCH' if mission_active else 'IDLE',
            'current_policy':              'FULL_REPORTING',
            'decision_reason':             'Scout-owned aggregated state',
            'current_behaviour':           'monitoring',
            'autonomy_level':              'ASSISTED',
            'buffer_usage':                None,
            'last_operator_command':       None,
            'control_authority':           control_authority.get_authority(),
            # Evidence for *why* control_authority last changed, not just its
            # current value -- see services/control_authority.py.get_last_transition().
            # None until the first transition since this Flask process started.
            'control_authority_last_transition': control_authority.get_last_transition(),
            'home_status': home_status,
        },
        'measurements': measurements,
        'environment': {
            'wind':              None,
            'waves':             None,
            'water_temperature': None,
            'visibility':        None,
        },
        'fleet': {
            'role':        'SCOUT',
            'sector':      None,
            'neighbours':  [],
            'active_task': None,
        },
        'events': get_recent(20),
    }
