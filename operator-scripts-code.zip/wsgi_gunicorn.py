"""
WSGI entry point for gunicorn
Starts background threads for measurement, sampler, and buzzer loops
"""
import sys
import os
import threading

# Add parent directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(os.path.dirname(current_dir))
sys.path.insert(0, parent_dir)

from app import app, socketio, MeasuringLoop, samplerLoop, gpio_set_pin

# Start background threads
measurement_thread = threading.Thread(target=MeasuringLoop, daemon=True)
measurement_thread.start()

sampler_thread = threading.Thread(target=samplerLoop, daemon=True)
sampler_thread.start()

# Turn on light on startup
gpio_set_pin("Light", True)

# Gunicorn will use this as the WSGI application
application = app

