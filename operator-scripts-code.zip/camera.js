// Camera Stream Handler for RealSense MJPEG streams
// RGB and Depth streams are proxied through Flask from host RealSense service

// Configuration - Uses relative URLs (proxied through Flask)
const CAMERA_CONFIG = {
    // RGB stream from /camera/rgb (proxied from host:5001)
    realsenseUrl: window.REALSENSE_URL || "/camera/rgb",
    // Depth stream from /camera/depth (proxied from host:5002)
    camera2Url: window.CAMERA2_URL || "/camera/depth"
};

// Reload camera stream by resetting the src attribute
function reloadCamera() {
    const cam = document.getElementById("camStream");
    if (cam) {
        // Add timestamp to prevent caching
        const baseUrl = CAMERA_CONFIG.realsenseUrl.split('?')[0];
        cam.src = baseUrl + "?t=" + Date.now();
        console.log("Camera stream 1 reloaded manually.");
    }
}

function reloadCamera2() {
    const cam = document.getElementById("camStream2");
    if (cam) {
        const baseUrl = CAMERA_CONFIG.camera2Url.split('?')[0];
        cam.src = baseUrl + "?t=" + Date.now();
        console.log("Camera stream 2 reloaded manually.");
    }
}

// Auto-reload if stream stalls (MJPEG streams can sometimes freeze)
let lastFrameTime = Date.now();
let lastFrameTime2 = Date.now();


// Initialize camera streams when DOM is ready
document.addEventListener("DOMContentLoaded", () => {
    const cam1 = document.getElementById("camStream");
    const cam2 = document.getElementById("camStream2");
    
    if (cam1) {
        // Track successful frame loads
        cam1.addEventListener("load", () => {
            lastFrameTime = Date.now();
            console.log("Camera 1 stream connected");
        });
        
        // Handle stream errors
        cam1.addEventListener("error", () => {
            console.log("Camera 1 stream error → will retry...");
            setTimeout(reloadCamera, 2000);
        });
    }
    
    if (cam2) {
        cam2.addEventListener("load", () => {
            lastFrameTime2 = Date.now();
            console.log("Camera 2 stream connected");
        });
        
        cam2.addEventListener("error", () => {
            console.log("Camera 2 stream error → will retry...");
            setTimeout(reloadCamera2, 2000);
        });
    }
});

// Legacy support for iframe-based cameras (if needed)
var iFrames = document.getElementsByClassName("cameraIframe");

function cameraHandeler(id) {
    if (iFrames && iFrames[id]) {
        console.log("Reloading iframe camera " + id);
        iFrames[id].src = iFrames[id].src;
    }
}

