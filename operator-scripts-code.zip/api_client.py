import requests
from config import (
    LOCAL_FLASK_URL,
    OPERATOR_URLS,
    OPERATOR_CONNECT_TIMEOUT,
    OPERATOR_READ_TIMEOUT,
)

# Remembers the last operator URL that worked so we try it first, instead of
# re-probing dead URLs on every message during a flush.
_last_good_url = None


def _ordered_urls():
    if _last_good_url in OPERATOR_URLS:
        return [_last_good_url] + [u for u in OPERATOR_URLS if u != _last_good_url]
    return OPERATOR_URLS


def get_vehicle_state():
    r = requests.get(f"{LOCAL_FLASK_URL}/agent/state", timeout=5)
    r.raise_for_status()
    return r.json()


def get_diagnostics():
    """
    Read-only fetch of the vehicle Flask service's half of Vehicle Health
    diagnostics (mavlink/pixhawk/gps/battery/rc_receiver/camera/
    mission_service/storage/cpu/memory). Raises on failure; the caller
    (diagnostics.py) is responsible for turning that into UNKNOWN entries
    rather than guessing values.
    """
    r = requests.get(f"{LOCAL_FLASK_URL}/agent/diagnostics", timeout=5)
    r.raise_for_status()
    return r.json()


def get_mission():
    """
    Read-only fetch of the mission currently stored on the Pixhawk, via the
    vehicle Flask service's real MAVLink mission-download handshake (see
    services/mission_service.py there). Raises on failure; the caller
    (mission.py) is responsible for degrading to a cached/last-known result
    or an explicit error rather than guessing. Timeout is longer than the
    Flask side's own internal bounded wait (mission_service._OVERALL_TIMEOUT_S,
    20s) so a download that would have finished normally isn't cut off here
    first.
    """
    r = requests.get(f"{LOCAL_FLASK_URL}/agent/mission", timeout=25)
    r.raise_for_status()
    return r.json()


def get_pixhawk_mission():
    """
    Read-only fetch of the mission currently stored on the Pixhawk, in the
    schema the operator station's Pixhawk Mission card consumes
    (mission_loaded/mission_valid/count/current_seq/hash/waypoints/partial)
    -- via the vehicle Flask service's download_pixhawk_mission() (see
    services/mission_service.py there). Raises on failure; the caller
    (pixhawk_mission.py) is responsible for degrading to a cached/
    last-known result or an explicit error rather than guessing. Timeout is
    longer than the Flask side's own internal bounded wait
    (mission_service._OVERALL_TIMEOUT_S, 20s) so a download that would have
    finished normally isn't cut off here first.
    """
    r = requests.get(f"{LOCAL_FLASK_URL}/agent/pixhawk_mission", timeout=25)
    r.raise_for_status()
    return r.json()


def get_control_authority():
    """
    Read the vehicle's current control authority (OPERATOR/LOCAL_AGENT)
    from the vehicle Flask service -- the same process/port as
    get_vehicle_state, not a separate server. Raises on failure; the
    caller (local_agent.py) is responsible for failing safe to OPERATOR
    if this can't be reached, exactly as it would for any other vehicle
    state it can't fetch.
    """
    r = requests.get(f"{LOCAL_FLASK_URL}/agent/control_authority", timeout=3)
    r.raise_for_status()
    return r.json()["authority"]


def set_control_authority(authority: str):
    """Write the vehicle's control authority. Not used by the Local Agent's
    own main loop (it only ever reads) -- provided for tooling/tests that
    need to grant/revoke authority the same way an operator console would."""
    r = requests.post(f"{LOCAL_FLASK_URL}/agent/control_authority", json={"authority": authority}, timeout=3)
    r.raise_for_status()
    return r.json()["authority"]


def get_home_status():
    """
    Read-only fetch of Pixhawk Home verification/readiness -- see
    services/set_home_service.py's get_home_status() there. Internal to
    this process (used by command_executor.home_verified()'s AUTO/RTL/
    RESUME gate); never exposed on this process's own inbound HTTP surface
    -- the Operator Backend, not this call, is what the frontend talks to.
    Raises on failure; callers are responsible for failing safe (never
    assuming verified) rather than guessing.
    """
    r = requests.get(f"{LOCAL_FLASK_URL}/agent/home_status", timeout=5)
    r.raise_for_status()
    return r.json()


def _response_body(response):
    try:
        return response.json()
    except ValueError:
        return response.text


def send_to_operator(endpoint, message):
    """
    Raises on failure so the caller buffers `message` for retry (see
    local_agent.py). Two genuinely different failure modes are kept
    distinct in the error text: a 4xx response means the operator *was*
    reached and rejected the request at the protocol level (bad payload,
    wrong route, auth, ...) -- logged immediately with the actual response
    body, since that's a diagnosable bug on this side, not a connectivity
    gap. Everything else (connection refused, timeout, DNS failure, a 5xx)
    is a genuine reachability/availability problem and is reported as
    such. Conflating the two previously made every operator rejection
    print as "No operator reachable", which is actively misleading when
    the operator is up and simply refusing the request.
    """
    global _last_good_url

    errors = []
    protocol_rejection = False
    for base_url in _ordered_urls():
        try:
            r = requests.post(
                f"{base_url}{endpoint}",
                json=message,
                timeout=(OPERATOR_CONNECT_TIMEOUT, OPERATOR_READ_TIMEOUT),
            )
        except requests.exceptions.RequestException as e:
            errors.append(f"{base_url}: {e}")
            continue

        if 400 <= r.status_code < 500:
            body = _response_body(r)
            print(f"[API CLIENT] Operator {base_url}{endpoint} rejected request: "
                  f"HTTP {r.status_code} -- {body}")
            errors.append(f"{base_url}: HTTP {r.status_code} protocol rejection: {body}")
            protocol_rejection = True
            continue

        try:
            r.raise_for_status()
        except requests.exceptions.RequestException as e:
            errors.append(f"{base_url}: {e}")
            continue

        _last_good_url = base_url
        return {
            "ok": True,
            "operator": base_url,
            "response": r.json()
        }

    _last_good_url = None
    if protocol_rejection and len(errors) == 1:
        # The only operator configured (or the only one tried) was reached
        # and rejected the request -- never describe that as unreachable.
        raise RuntimeError("Operator rejected request: " + errors[0])
    raise RuntimeError("No operator reachable: " + " | ".join(errors))


def get_pending_commands(usv_id):
    """
    Poll the operator backend for commands queued for this USV.

    Unlike send_to_operator, this does not raise when no operator is
    reachable -- the operator backend is the source of truth for pending
    commands and keeps them queued until the next successful poll, so a
    failed poll here is just "nothing to report this iteration", not an
    error the caller needs to handle (see README: comm DISCONNECTED means
    rely on backend queueing, not local buffering of inbound commands).
    """
    global _last_good_url

    for base_url in _ordered_urls():
        try:
            r = requests.get(
                f"{base_url}/agent/commands",
                params={"usv_id": usv_id},
                timeout=(OPERATOR_CONNECT_TIMEOUT, OPERATOR_READ_TIMEOUT),
            )
            r.raise_for_status()
            _last_good_url = base_url
            return r.json().get("commands", [])
        except Exception:
            continue

    return []
