"""
Standalone tests for the vehicle's control_authority state and its
GET/POST /agent/control_authority routes. No pytest dependency -- run
directly:

    python3 test_control_authority.py

Builds a minimal Flask app registering only agent_bp (not the full app.py,
which needs mavlink2rest/GPIO/sensor services reachable) so this needs
nothing beyond Flask itself.
"""
import unittest

from flask import Flask

import services.control_authority as control_authority
from routes.agent_routes import agent_bp


def _make_client():
    app = Flask(__name__)
    app.register_blueprint(agent_bp)
    return app.test_client()


class TestControlAuthorityState(unittest.TestCase):
    def setUp(self):
        control_authority._authority = control_authority.OPERATOR
        control_authority._last_transition = None

    def tearDown(self):
        control_authority._authority = control_authority.OPERATOR
        control_authority._last_transition = None

    def test_defaults_to_operator(self):
        self.assertEqual(control_authority.get_authority(), control_authority.OPERATOR)

    def test_set_authority_to_local_agent(self):
        control_authority.set_authority("LOCAL_AGENT")
        self.assertEqual(control_authority.get_authority(), "LOCAL_AGENT")

    def test_set_authority_back_to_operator(self):
        control_authority.set_authority("LOCAL_AGENT")
        control_authority.set_authority("OPERATOR")
        self.assertEqual(control_authority.get_authority(), "OPERATOR")

    def test_invalid_authority_rejected_and_state_unchanged(self):
        with self.assertRaises(ValueError):
            control_authority.set_authority("AUTO")
        self.assertEqual(control_authority.get_authority(), control_authority.OPERATOR)

    def test_none_authority_rejected(self):
        with self.assertRaises(ValueError):
            control_authority.set_authority(None)


class TestControlAuthorityRoutes(unittest.TestCase):
    def setUp(self):
        control_authority._authority = control_authority.OPERATOR
        control_authority._last_transition = None
        self.client = _make_client()

    def tearDown(self):
        control_authority._authority = control_authority.OPERATOR
        control_authority._last_transition = None

    def test_get_reports_default_operator(self):
        resp = self.client.get("/agent/control_authority")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.get_json()["authority"], "OPERATOR")

    def test_post_local_agent_then_get_reflects_it(self):
        resp = self.client.post("/agent/control_authority", json={"authority": "LOCAL_AGENT"})
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.get_json()["authority"], "LOCAL_AGENT")

        resp = self.client.get("/agent/control_authority")
        self.assertEqual(resp.get_json()["authority"], "LOCAL_AGENT")

    def test_post_invalid_authority_rejected_with_400(self):
        resp = self.client.post("/agent/control_authority", json={"authority": "AUTO"})
        self.assertEqual(resp.status_code, 400)
        self.assertIn("error", resp.get_json())
        self.assertEqual(control_authority.get_authority(), "OPERATOR")

    def test_post_missing_body_rejected_with_400(self):
        resp = self.client.post("/agent/control_authority")
        self.assertEqual(resp.status_code, 400)

    def test_no_transition_before_first_change(self):
        self.assertIsNone(control_authority.get_last_transition())

    def test_last_transition_records_caller_supplied_reason(self):
        control_authority.set_authority("LOCAL_AGENT", reason="Operator explicitly requested TAKE CONTROL")
        transition = control_authority.get_last_transition()
        self.assertEqual(transition["from"], "OPERATOR")
        self.assertEqual(transition["to"], "LOCAL_AGENT")
        self.assertEqual(transition["reason"], "Operator explicitly requested TAKE CONTROL")
        self.assertIn("timestamp", transition)

    def test_last_transition_falls_back_when_no_reason_supplied(self):
        control_authority.set_authority("LOCAL_AGENT")
        transition = control_authority.get_last_transition()
        self.assertIn("no reason supplied", transition["reason"])

    def test_route_accepts_and_returns_reason(self):
        resp = self.client.post(
            "/agent/control_authority",
            json={"authority": "LOCAL_AGENT", "reason": "Operator explicitly requested TAKE CONTROL"},
        )
        body = resp.get_json()
        self.assertEqual(body["authority"], "LOCAL_AGENT")
        self.assertEqual(body["last_transition"]["reason"], "Operator explicitly requested TAKE CONTROL")

    def test_unchanged_authority_does_not_overwrite_last_transition(self):
        control_authority.set_authority("LOCAL_AGENT", reason="first reason")
        control_authority.set_authority("LOCAL_AGENT", reason="should be ignored, no real transition")
        self.assertEqual(control_authority.get_last_transition()["reason"], "first reason")

    def test_take_control_local_agent_to_operator_always_succeeds_immediately(self):
        """Required "Take Control" behavior: LOCAL_AGENT -> OPERATOR must
        always succeed immediately when requested by the Operator Station.
        set_authority() is a synchronous in-memory assignment with no lock,
        no wait, and no check of mission/vehicle state -- there is nothing
        in this module (or anywhere else; the Local Agent only ever reads
        this value, see local_mission_agent/README.md "Authority model")
        that could delay or deny this transition."""
        control_authority.set_authority("LOCAL_AGENT")
        self.assertEqual(control_authority.get_authority(), "LOCAL_AGENT")

        resp = self.client.post("/agent/control_authority", json={"authority": "OPERATOR", "reason": "Take Control"})

        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.get_json()["authority"], "OPERATOR")
        self.assertEqual(control_authority.get_authority(), "OPERATOR")


if __name__ == "__main__":
    unittest.main(verbosity=2)
