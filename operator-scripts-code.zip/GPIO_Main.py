import sys
import signal
import os

# Add current directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

# Import GPIO module from local file
from GPIO import GPIOManager
import socket
from time import sleep
import os
import sys
import traceback



#Command structure
#Pin nums are always two digits 
#D Define, S set, R Read
#Set pin    S0Led S1Led
#Read Pin RLeak
#Define D, 2 digits pinnum, OUTPUT = T/F, pullUp = T/F ,Name
#D02TFLED
class GPIO_Main_Manager():

    def __init__(self):
        try:
            self.socket_path = "/run/gpio/gpio_socket"
            self.gpio = None
            self.server = None
            self.OpenSocket()
            self.InitializeGPIO()
            print("GPIO Service initialized successfully")
        except Exception as e:
            print(f"Error initializing GPIO service: {e}")
            traceback.print_exc()
            sys.exit(1)

    def InitializeGPIO(self):
        """Initialize GPIO manager and define pins with error handling"""
        try:
            self.gpio = GPIOManager()

            # Define pins safely
            self.gpio.DefinePin("Leak", 25, OUTPUT=False, pullUp=True)
            self.gpio.DefinePin("Sensors", 24, OUTPUT=True)
            self.gpio.DefinePin("Light", 23, OUTPUT=True)
            self.gpio.DefinePin("Sampler", 26, OUTPUT=True)
            if "Sampler" in self.gpio.outputPins:
                self.gpio.SetPin("Sampler", True)
            if "Light" in self.gpio.outputPins:
                self.gpio.SetPin("Light", True)

        except Exception as e:
            print(f"Error initializing GPIO manager: {e}")
            traceback.print_exc()
            raise

    def OpenSocket(self):
        """Open Unix socket for GPIO communication"""
        try:
            # Remove path if socket already exists
            if os.path.exists(self.socket_path):
                os.remove(self.socket_path)

            # Ensure parent directory exists
            os.makedirs(os.path.dirname(self.socket_path), exist_ok=True)

            # Open new socket
            self.server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self.server.bind(self.socket_path)
            os.chmod(self.socket_path, 0o777)  # use the correct path
            self.server.listen(1)
            print(f"GPIO socket opened at {self.socket_path}")
        except Exception as e:
            print(f"Error opening GPIO socket: {e}")
            traceback.print_exc()
            raise


    
    def GetDefinedPins(self):
        pass

    def HandelRequest(self, conn, data):
        """Handle incoming GPIO requests with comprehensive error handling"""
        try:
            if not data or len(data) == 0:
                conn.sendall("E:Empty request".encode('utf-8'))
                return
            
            print(f"Request: {data}")
            
            ##Handel Reading a pin
            if(data[0] == 'R'):
                try:
                    if self.gpio is None:
                        conn.sendall("E:GPIO not initialized".encode('utf-8'))
                        return
                    
                    pin_name = data[1:]
                    pin_value = self.gpio.ReadPin(pin_name)
                    st = "H" + pin_name if pin_value else "L" + pin_name
                    conn.sendall(st.encode('utf-8'))
                except KeyError as e:
                    print(f"Error: Pin {data[1:]} not defined: {e}")
                    conn.sendall(f"E:Pin not defined".encode('utf-8'))
                except Exception as e:
                    print(f"Error reading pin: {e}")
                    traceback.print_exc()
                    conn.sendall(f"E:Read error".encode('utf-8'))

            ##Handel setting the status of a pin
            elif(data[0] == 'S'):
                try:
                    if self.gpio is None:
                        conn.sendall("E:GPIO not initialized".encode('utf-8'))
                        return
                    
                    if len(data) < 3:
                        conn.sendall("E:Invalid command format".encode('utf-8'))
                        return
                    
                    state = False
                    if(data[1] == '1'):
                        state = True
                    pin_name = data[2:]
                    self.gpio.SetPin(pin_name, state)
                    print(f"Setting pin:{pin_name} to {state}")
                    st = "T"
                    conn.sendall(st.encode('utf-8'))
                except KeyError as e:
                    print(f"Error: Pin {data[2:]} not defined: {e}")
                    conn.sendall(f"E:Pin not defined".encode('utf-8'))
                except Exception as e:
                    print(f"Error setting pin: {e}")
                    traceback.print_exc()
                    conn.sendall(f"E:Set error".encode('utf-8'))
            
            #Handel defining pins
            #C PP O P NAME
            #Define D, 2 digits pinnum, OUTPUT = T/F, pullUp = T/F ,Name
            elif(data[0] == 'D'):
                try:
                    if self.gpio is None:
                        conn.sendall("E:GPIO not initialized".encode('utf-8'))
                        return
                    
                    if len(data) < 6:
                        conn.sendall("E:Invalid command format".encode('utf-8'))
                        return
                    
                    pin_num = int(data[1:3])
                    is_output = bool(int(data[3]))
                    pull_up = bool(int(data[4]))
                    pin_name = data[5:]
                    
                    self.gpio.gpio.DefinePin(pin_name, pin_num, is_output, pull_up)
                    print(f"Defining pin: {pin_name} (pin {pin_num}, output={is_output}, pullup={pull_up})")
                    st = "T"
                    conn.sendall(st.encode('utf-8'))
                except ValueError as e:
                    print(f"Error: Invalid pin number format: {e}")
                    conn.sendall(f"E:Invalid pin number".encode('utf-8'))
                except Exception as e:
                    print(f"Error defining pin: {e}")
                    traceback.print_exc()
                    conn.sendall(f"E:Define error".encode('utf-8'))
            else:
                conn.sendall("E:Unknown command".encode('utf-8'))
        except Exception as e:
            print(f"Error handling request: {e}")
            traceback.print_exc()
            try:
                conn.sendall(f"E:Request error".encode('utf-8'))
            except:
                pass

    def Loop(self):
        """Main loop to accept and handle connections"""
        print("GPIO service loop started")
        while True:
            try:
                conn, _ = self.server.accept()
                try:
                    data = conn.recv(128).decode('utf-8')
                    if data:
                        self.HandelRequest(conn, data)
                except Exception as e:
                    print(f"Error processing connection: {e}")
                    traceback.print_exc()
                finally:
                    try:
                        conn.close()
                    except:
                        pass
            except Exception as e:
                print(f"Error in GPIO service loop: {e}")
                traceback.print_exc()
                sleep(1)


if __name__ == '__main__':
    GPMM = None

    def handle_exit(sig, frame):
        print(f"\nGPIO service received signal {sig}, shutting down...")
        if GPMM and GPMM.gpio:
            try:
                GPMM.gpio.cleanup()
            except Exception as e:
                print(f"Error during GPIO cleanup: {e}")
        sys.exit(0)

    signal.signal(signal.SIGTERM, handle_exit)
    signal.signal(signal.SIGINT, handle_exit)

    try:
        GPMM = GPIO_Main_Manager()
        GPMM.Loop()
    except Exception as e:
        print(f"Fatal error in GPIO service: {e}")
        traceback.print_exc()
        if GPMM and GPMM.gpio:
            try:
                GPMM.gpio.cleanup()
            except:
                pass
        sys.exit(1)
