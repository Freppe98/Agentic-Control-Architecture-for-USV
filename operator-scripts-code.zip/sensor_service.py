"""
Sensor/Measurement Service
HTTP API service for handling all sensor measurements (modbus, ADC, sonar, etc.)
Runs as a separate process to isolate sensor failures from the main Flask app
"""
from flask import Flask, jsonify, request
import logging
import datetime
import time
import threading

import sys
import os

# Add parent directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(os.path.dirname(current_dir))
sys.path.insert(0, parent_dir)

from logging_setup import configure_logging

configure_logging(service_name="sensor-service")
logger = logging.getLogger("sensor-service")

try:
    from measurements import MeasurementManager
except Exception as e:
    logger.warning("Failed to import MeasurementManager (service will run degraded)", exc_info=True)
    MeasurementManager = None

try:
    from watersampler import SamplerManager
except Exception as e:
    logger.warning("Failed to import SamplerManager (service will run degraded)", exc_info=True)
    SamplerManager = None

try:
    from dome import DomeCamManager
except Exception as e:
    logger.warning("Failed to import DomeCamManager (service will run degraded)", exc_info=True)
    DomeCamManager = None

try:
    from influxdbData import influxdb
except Exception as e:
    logger.warning("Failed to import influxdb manager (Influx optional)", exc_info=True)
    influxdb = None

app = Flask(__name__)

# Shared ServoKit instance to avoid I2C bus conflicts
_shared_servokit = None
_servokit_initialized = False

def get_shared_servokit():
    """Get or create a shared ServoKit instance for all PWM operations"""
    global _shared_servokit, _servokit_initialized
    
    if _servokit_initialized:
        return _shared_servokit
    
    try:
        from adafruit_servokit import ServoKit
        logger.info("[SharedServoKit] Initializing ServoKit (shared instance)...")
        _shared_servokit = ServoKit(channels=16)
        logger.info("[SharedServoKit] ServoKit initialized successfully!")
    except Exception as e:
        logger.warning("[SharedServoKit] Failed to initialize (running without PWM)", exc_info=True)
        _shared_servokit = None
    
    _servokit_initialized = True
    return _shared_servokit

# Initialize managers with error handling
mm = None
sm = None
dcm = None
influx = None

def initialize_services():
    """Initialize all sensor services with error handling"""
    global mm, sm, dcm, influx, _shared_servokit
    
    try:
        if MeasurementManager:
            logger.info("Initializing MeasurementManager...")
            mm = MeasurementManager()
            logger.info("MeasurementManager initialized successfully")
        else:
            logger.warning("MeasurementManager not available (imports failed)")
    except Exception as e:
        logger.warning("Failed to initialize MeasurementManager", exc_info=True)
        mm = None
    
    try:
        if SamplerManager:
            logger.info("Initializing SamplerManager...")
            sm = SamplerManager()
            logger.info("SamplerManager initialized successfully")
        else:
            logger.warning("SamplerManager not available (imports failed)")
    except Exception as e:
        logger.warning("Failed to initialize SamplerManager", exc_info=True)
        sm = None
    
    try:
        if DomeCamManager:
            logger.info("Initializing DomeCamManager...")
            dcm = DomeCamManager()
            logger.info("DomeCamManager initialized successfully")
        else:
            logger.warning("DomeCamManager not available (imports failed)")
    except Exception as e:
        logger.warning("Failed to initialize DomeCamManager", exc_info=True)
        dcm = None
    
    try:
        if influxdb:
            logger.info("Initializing InfluxDBManager...")
            influx = influxdb.InfluxdbManager()
            logger.info("InfluxDBManager initialized successfully")
        else:
            logger.warning("InfluxDB not available (imports failed)")
    except Exception as e:
        logger.warning("Failed to initialize InfluxDBManager (Influx optional)", exc_info=True)
        influx = None
        # Note: InfluxDB is optional for sensor service, Flask app handles it

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    status = {
        "status": "healthy",
        "services": {
            "measurement_manager": mm is not None,
            "sampler_manager": sm is not None,
            "dome_cam_manager": dcm is not None,
            "influxdb": influx is not None
        }
    }
    return jsonify(status), 200


@app.route('/health/details', methods=['GET'])
def health_details():
    """Health check endpoint with per-sensor details (non-breaking additive endpoint)."""
    status = {
        "status": "healthy",
        "services": {
            "measurement_manager": mm is not None,
            "sampler_manager": sm is not None,
            "dome_cam_manager": dcm is not None,
            "influxdb": influx is not None,
        },
        "devices": {},
    }

    try:
        if mm is not None and hasattr(mm, "get_status"):
            status["devices"] = mm.get_status()
    except Exception:
        logger.warning("Failed to collect measurement manager status", exc_info=True)

    return jsonify(status), 200

@app.route('/measurements', methods=['POST'])
def get_measurements():
    """Get sensor measurements"""
    try:
        if mm is None:
            return jsonify({"error": "MeasurementManager not initialized"}), 503
        
        data = request.get_json() or {}
        sensitive_measurements = data.get('sensitive_measurements', False)
        mission_id = data.get('mission_id')
        
        try:
            measurements = mm.GetMeasurements(sensitive_measurements=sensitive_measurements)
            
            # Convert timestamp to string if present
            if 'timestamp' in measurements and isinstance(measurements['timestamp'], datetime.datetime):
                measurements['timestamp'] = measurements['timestamp'].strftime("%Y-%m-%d %H:%M:%S")

            # Save to InfluxDB if initialized
            if influx:
                try:
                    influx.SavePoint(measurements, mission_id=mission_id)
                except Exception as e:
                    logger.warning("Error saving measurements to InfluxDB", exc_info=True)
            
            return jsonify(measurements), 200
        except Exception as e:
            logger.exception("Error getting measurements")
            return jsonify({"error": str(e)}), 500
            
    except Exception as e:
        logger.exception("Error in /measurements endpoint")
        return jsonify({"error": "Internal server error"}), 500

@app.route('/sampler/activate', methods=['POST'])
def activate_sampler():
    """Activate a water sampler"""
    try:
        if sm is None:
            return jsonify({"error": "SamplerManager not initialized"}), 503
        
        data = request.get_json()
        if not data or 'sampler_number' not in data:
            return jsonify({"error": "Missing sampler_number"}), 400
        
        sampler_number = int(data['sampler_number'])
        
        if sampler_number < 0 or sampler_number > 3:
            return jsonify({"error": "Invalid sampler_number (0-3)"}), 400
        
        try:
            result = sm.activate_sampler(sampler_number)
            # Handle both dict return (new) and None return (old behavior)
            if isinstance(result, dict):
                hardware_activated = result.get("activated", False)
                reason = result.get("reason", "")
                return jsonify({
                    "status": "success",
                    "sampler_number": sampler_number,
                    "hardware_activated": hardware_activated,
                    "reason": reason if not hardware_activated else ""
                }), 200
            else:
                # Backward compatibility: assume success if no dict returned
                return jsonify({
                    "status": "success",
                    "sampler_number": sampler_number,
                    "hardware_activated": True
                }), 200
        except Exception as e:
            logger.exception("Error activating sampler %s", sampler_number)
            return jsonify({"error": str(e)}), 500
            
    except Exception as e:
        logger.exception("Error in /sampler/activate endpoint")
        return jsonify({"error": "Internal server error"}), 500

@app.route('/dome/rotate', methods=['POST'])
def rotate_dome():
    """Rotate dome camera"""
    try:
        if dcm is None:
            return jsonify({"error": "DomeCamManager not initialized"}), 503
        
        data = request.get_json()
        if not data or 'direction' not in data:
            return jsonify({"error": "Missing direction"}), 400
        
        direction = data['direction']
        valid_directions = ['LL', 'L', 'C', 'R', 'RR']
        
        if direction not in valid_directions:
            return jsonify({"error": f"Invalid direction. Must be one of: {valid_directions}"}), 400
        
        try:
            dcm.rotate_dome_cam(direction)
            return jsonify({"status": "success", "direction": direction}), 200
        except Exception as e:
            logger.exception("Error rotating dome camera direction=%s", direction)
            return jsonify({"error": str(e)}), 500
            
    except Exception as e:
        logger.exception("Error in /dome/rotate endpoint")
        return jsonify({"error": "Internal server error"}), 500

@app.route('/influx/save', methods=['POST'])
def save_to_influx():
    """Save data point to InfluxDB"""
    try:
        if influx is None:
            return jsonify({"error": "InfluxDBManager not initialized"}), 503
        
        data = request.get_json()
        if not data:
            return jsonify({"error": "Missing data"}), 400
        
        mission_id = data.get('mission_id')
        point_data = data.get('scout', {})
        
        if not point_data:
            return jsonify({"error": "Missing data field"}), 400
        
        try:
            influx.SavePoint(point_data, mission_id=mission_id)
            return jsonify({"status": "success"}), 200
        except Exception as e:
            logger.exception("Error saving to InfluxDB")
            return jsonify({"error": str(e)}), 500
            
    except Exception as e:
        logger.exception("Error in /influx/save endpoint")
        return jsonify({"error": "Internal server error"}), 500

if __name__ == '__main__':
    logger.info("Starting Sensor Service...")
    initialize_services()
    logger.info("Sensor Service initialized, starting Flask server...")
    app.run(host='0.0.0.0', port=6001, debug=False)

