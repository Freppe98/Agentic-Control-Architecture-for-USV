# Dashboard API contract

This document describes the REST endpoints and Socket.IO events used by the AqualityINTELLIGENCE dashboard. Any frontend (current vanilla JS or a potential V0/React app) must use this contract to talk to the Flask backend.

**Base URL:** Same origin as the dashboard (e.g. `http://<device>:8080`). No CORS required when served from Flask.

---

## REST endpoints

| Method | Path | Request | Response | Purpose |
|--------|------|---------|----------|---------|
| GET | `/` | — | HTML | Dashboard page (legacy template or SPA) |
| GET | `/camera/rgb` | — | MJPEG stream | RGB video (proxied from RealSense :5001) |
| GET | `/camera/depth` | — | MJPEG stream | Depth video (proxied from RealSense :5002) |
| GET | `/getdata` | — | File download | `data_download.txt` |
| GET | `/get_missions` | — | JSON `{ "missions": [...] }` | List of mission IDs for history selector |
| GET | `/download_mission` | Query `id=<mission_id>` | ZIP file | Download mission data |
| POST | `/start_mission` | JSON `{ "name": "Mission name" }` | 200 text | Start mission recording |
| POST | `/stop_mission` | — | 200 text | Stop mission recording |
| POST | `/panel` | JSON `{ "lat", "lon", "cordTime" }` | JSON `{ "CameraMode" }` | Update GPS coords, get camera mode |
| GET/POST | `/rotate_dome_cam` | Query/body `direction=LL\|L\|C\|R\|RR` | 200 / 500 | Rotate dome camera |
| GET/POST | `/control_sampler` | Query/body (sampler params) | 200 / 500 | Activate sampler |
| GET/POST | `/reload_sampler` | — | 200 / 500 | Reload sampler |

---

## Socket.IO (same origin)

**Connect:** `io()` (defaults to current host).

### Client → Server (emit)

| Event | Payload | Purpose |
|-------|---------|---------|
| `webCommand` | `(command, value)` | Command: `toggleSensors`, `toggleMission`, `Buzzer`, `toggleLed`. Value: 0 or 1. |
| `request_data` | optional `{ date?, minutes? }` | Request data points (live or historical). Server responds with `response_data`. |
| `request_history` | — | Request list of available data/history. Server responds with `response_history`. |
| `request_log` | — | Request initial log message. Server responds with `response_Log`. |

### Server → Client (on)

| Event | Payload | Purpose |
|-------|---------|---------|
| `response_data` | Array of data points `[{ timestamp, ...fields }]` | Sensor/time-series data for map, graph, data column. |
| `response_history` | (varies) | Available history/database list for dropdown. |
| `response_Log` | `[type, time, message]` e.g. `["Info", "14:22:01", "Connected"]` | Log entry for UI. |

---

## Camera streams

- **RGB:** `<img src="/camera/rgb" alt="RGB" />` — MJPEG, may need cache-bust query `?t=<timestamp>` on reload.
- **Depth:** `<img src="/camera/depth" alt="Depth" />` — MJPEG.

Both are `multipart/x-mixed-replace` streams. If the stream fails, the server returns 503 JSON `{ "error": "..." }`.

---

## Data point shape (response_data)

Each item in the `response_data` array typically has:

- `timestamp`: string (e.g. `"YYYY-MM-DD HH:MM:SS"`)
- Sensor fields (e.g. `latitude`, `longitude`, `sensorsEnabled`, and any InfluxDB fields)

The frontend uses this for the map track, graph, and data column.
