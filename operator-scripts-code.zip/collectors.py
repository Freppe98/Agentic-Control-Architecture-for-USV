from config import BUFFER_FILE
from state_machine import MissionState


def get_communication_status(comm_state, last_success_ts=None):
    return {
        "connectivity": comm_state,
        "operator_reachable": comm_state == "CONNECTED",
        "last_successful_transmission": last_success_ts,
        "buffered_packets": count_buffered_packets(),
        "rtt_ms": None,
        "packet_loss": None,
        "bandwidth_estimate_kbps": None,
        "vpn_status": None,
    }


def get_agent_status(comm_state, mission_state=MissionState.IDLE):
    """
    current_policy/decision_reason/current_behaviour/autonomy_level moved to
    decision_engine.py (build_policy/decide) -- that module is now the single
    source of truth for policy and decision reasoning, evaluated against the
    full observation set (battery/GPS/mavlink/mission/authority), not just
    comm_state. local_agent.py merges its output into this dict.
    """
    return {
        "current_communication_state": comm_state,
        "current_mission_state": mission_state,
        "buffer_usage": count_buffered_packets(),
        "last_operator_command": None,
    }


def count_buffered_packets():
    try:
        with open(BUFFER_FILE, "r", encoding="utf-8") as f:
            return sum(1 for _ in f)
    except FileNotFoundError:
        return 0


def policy_for_comm(comm_state):
    if comm_state == "CONNECTED":
        return "FULL_REPORTING"
    if comm_state == "PARTITIONED":
        return "REDUCED_REPORTING_LOCAL_AUTONOMY"
    return "BUFFER_AND_LOCAL_FALLBACK"