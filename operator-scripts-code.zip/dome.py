import sys
from time import sleep
import logging

from logging_setup import configure_logging
from shared_servo import get_servo_kit, is_hardware_available

configure_logging(service_name="sensor-service")
logger = logging.getLogger(__name__)

class DomeCamManager:
    def __init__(self):
        self.kit = None
        self.hardware_available = is_hardware_available()
        self._initialized = False

        logger.info("[DomeCam] Ready (using shared ServoKit instance)")

    def _ensure_initialized(self):
        """Get the shared ServoKit instance on first use"""
        if self._initialized:
            return
            
        logger.info("[DomeCam] Getting shared ServoKit instance...")
        self.kit = get_servo_kit()
        
        if self.kit is None:
            self.hardware_available = False
            logger.warning("[DomeCam] No hardware available - running in dummy mode")
        else:
            logger.info("[DomeCam] Using shared ServoKit instance successfully!")
        
        self._initialized = True

    def rotate_dome_cam(self, cam_direction):
        """Rotate dome camera. If PWM not available, just log and skip."""
        # Initialize hardware on first use
        self._ensure_initialized()
        
        valid_directions = {"LL": 180, "L": 135, "C": 90, "R": 45, "RR": 0}

        if cam_direction not in valid_directions:
            logger.warning("[DomeCam] Invalid cam direction: %s", cam_direction)
            return

        angle = valid_directions[cam_direction]

        if self.kit:
            logger.info("[DomeCam] Rotating camera to %s (%s°)", cam_direction, angle)
            try:
                self.kit.servo[15].angle = angle
                sleep(1)
            except Exception as e:
                logger.exception("[DomeCam] Error rotating dome camera")
        else:
            logger.warning("[DomeCam] Dummy mode: would rotate camera to %s (%s°)", cam_direction, angle)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python dome_cam.py <direction>")
        sys.exit(1)

    direction = sys.argv[1]
    dcm = DomeCamManager()
    dcm.rotate_dome_cam(direction)
