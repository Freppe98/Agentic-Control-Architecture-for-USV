from flask import Blueprint, jsonify, request
from services.agent_state import build_agent_state
from services import control_authority
from services.diagnostics_service import build_diagnostics
from services.mission_service import download_mission, download_pixhawk_mission
from services.set_home_service import set_home_current_position, get_home_status

agent_bp = Blueprint('agent', __name__)


@agent_bp.route('/agent/state', methods=['GET'])
def agent_state_route():
    try:
        return jsonify(build_agent_state())
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@agent_bp.route('/agent/diagnostics', methods=['GET'])
def agent_diagnostics_route():
    """
    Read-only vehicle-side health for the Vehicle Health page. Covers only
    the components this Flask process can answer directly (mavlink2rest,
    Pixhawk telemetry, camera streams, mission state, this host's cpu/
    memory/storage) -- see services/diagnostics_service.py. The Local Agent
    layers its own communication/local_agent/network checks on top of this
    (motherpi/services/local_mission_agent/diagnostics.py) for the full
    13-component picture the operator station displays.
    """
    try:
        return jsonify(build_diagnostics())
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@agent_bp.route('/agent/mission', methods=['GET'])
def agent_mission_route():
    """
    Read-only download of the mission currently stored on the Pixhawk, via
    the real MAVLink mission protocol (MISSION_REQUEST_LIST -> MISSION_COUNT
    -> MISSION_REQUEST_INT(seq) -> MISSION_ITEM_INT(seq), bounded timeout/
    retry) -- see services/mission_service.py. Never uploads, modifies,
    deletes, or overwrites a mission.
    """
    try:
        return jsonify(download_mission())
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@agent_bp.route('/agent/pixhawk_mission', methods=['GET'])
def agent_pixhawk_mission_route():
    """
    Read-only download of the mission currently stored on the Pixhawk, in
    the schema the operator station's Pixhawk Mission card consumes --
    mission_loaded/mission_valid/count/current_seq/hash/waypoints/partial
    plus duplicate/invalid/unsupported sequence breakdowns -- see
    services/mission_service.py's download_pixhawk_mission(). Same MAVLink
    handshake and read-only guarantee as GET /agent/mission; never uploads,
    modifies, deletes, or overwrites a mission. Scout remains the owner of
    mission state.
    """
    try:
        return jsonify(download_pixhawk_mission())
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@agent_bp.route('/agent/control_authority', methods=['GET'])
def get_control_authority_route():
    return jsonify({'authority': control_authority.get_authority()})


@agent_bp.route('/agent/control_authority', methods=['POST'])
def set_control_authority_route():
    body = request.get_json(silent=True) or {}
    try:
        authority = control_authority.set_authority(body.get('authority'), reason=body.get('reason'))
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    return jsonify({'authority': authority, 'last_transition': control_authority.get_last_transition()})


@agent_bp.route('/agent/set_home', methods=['POST'])
def agent_set_home_route():
    """
    Sets Pixhawk HOME_POSITION to the Scout's current GPS position and
    verifies it actually took effect -- see services/set_home_service.py.
    Only `mode: "current_position"` is implemented today.

    Always returns 200 with a structured accepted/verified/error body, even
    for a fully rejected/failed attempt -- the request itself was
    well-formed, so the caller (motherpi/services/local_mission_agent/
    set_home_handler.py) is expected to inspect `accepted`/`verified`/
    `error` in the body, not the HTTP status. 400 is reserved for a
    genuinely malformed request (missing command_id). Never sets Home
    automatically -- this route only ever runs in response to an explicit
    operator-issued command_id.
    """
    body = request.get_json(silent=True) or {}
    command_id = body.get('command_id')
    mode = body.get('mode', 'current_position')
    tolerance_m = body.get('tolerance_m')
    freshness_s = body.get('freshness_s')

    if not command_id:
        return jsonify({'error': 'missing command_id'}), 400

    if mode != 'current_position':
        return jsonify({
            'accepted': False,
            'verified': False,
            'command_id': command_id,
            'requested_position': None,
            'home_position': None,
            'verification_distance_m': None,
            'ack_result': None,
            'error': {'code': 'UNSUPPORTED_MODE', 'message': f'unsupported mode: {mode}'},
        })

    try:
        return jsonify(set_home_current_position(command_id, tolerance_m=tolerance_m, freshness_s=freshness_s))
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@agent_bp.route('/agent/home_status', methods=['GET'])
def agent_home_status_route():
    """
    Read-only Home verification/readiness -- see
    services/set_home_service.py's get_home_status(). `ready_for_auto`/
    `ready_for_rtl` reflect the exact same gate app.py's /nav/AutoModeOn,
    /nav/rtl, /nav/resume check before executing.
    """
    try:
        return jsonify(get_home_status())
    except Exception as e:
        return jsonify({'error': str(e)}), 500
