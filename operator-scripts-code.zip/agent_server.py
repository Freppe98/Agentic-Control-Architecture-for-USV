"""
Inbound HTTP surface for the Local Agent -- read-only Vehicle Health data
for the operator station.

    GET  /agent/diagnostics       per-component OK/WARNING/FAIL/UNKNOWN
    POST /agent/system_check      PASS/WARN/FAIL/UNKNOWN readiness checklist
    GET  /agent/command_history   rolling record of recent operator command lifecycles
    GET  /agent/decision_timeline rolling record of current_decision changes (Agent page)
    GET  /agent/mission           mission currently stored on the Pixhawk (legacy schema)
    GET  /agent/pixhawk_mission   mission currently stored on the Pixhawk (Pixhawk Mission card schema)

This is the only inbound listener the Local Agent runs; everything else in
this module is an outbound client (api_client.py) to the vehicle Flask
service and the operator backend. Deliberately stdlib-only (same
http.server.ThreadingHTTPServer approach as mock_operator.py) rather than a
second Flask app, since this process has no other HTTP-serving need.

Started as a daemon thread from local_agent.py's main() -- run() blocks, so
it must never be called on the main thread, which owns the polling loop.

Read-only by construction: every handler only ever calls into diagnostics.py,
mission.py, or pixhawk_mission.py (all GET-only) or command_history.py's
in-memory record of commands the main loop already executed via
_poll_and_execute_commands. No handler here takes a request body that
changes vehicle state, and none can reach a /nav/* or /agent/set_home
endpoint -- there is no code path here that can arm, change mode, set Home,
upload/clear a mission, or otherwise write to Pixhawk. The Operator Backend
is the only thing the frontend/operator UI ever talks to; this process has
no inbound HTTP surface for issuing commands (including SET_HOME, which
reaches the vehicle Flask service exactly the way ARM/RTL/every other
command type does -- queued by the operator backend, polled via
GET /agent/commands, executed by command_handler.py/command_executor.py,
result pushed back via POST /agent/command_result -- see README "Set
Home").
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from diagnostics import build_diagnostics, build_system_check
from mission import build_mission_status
from pixhawk_mission import build_pixhawk_mission_status
import command_history
import transition_log


class Handler(BaseHTTPRequestHandler):
    def _send_json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/agent/diagnostics"):
            try:
                self._send_json(build_diagnostics())
            except Exception as e:
                self._send_json({"error": str(e)}, 500)
        elif self.path.startswith("/agent/command_history"):
            try:
                self._send_json({"commands": command_history.get_recent()})
            except Exception as e:
                self._send_json({"error": str(e)}, 500)
        elif self.path.startswith("/agent/decision_timeline"):
            # Same rolling data as payload.agent.decision_timeline on every
            # status push (transition_log.py, type=="decision") -- exposed
            # here too so the Agent page can fetch full recent history on
            # load/reconnect without waiting for the next push.
            try:
                self._send_json({"decisions": transition_log.get_recent_by_type("decision")})
            except Exception as e:
                self._send_json({"error": str(e)}, 500)
        elif self.path.startswith("/agent/pixhawk_mission"):
            try:
                self._send_json(build_pixhawk_mission_status())
            except Exception as e:
                self._send_json({"error": str(e)}, 500)
        elif self.path.startswith("/agent/mission"):
            try:
                self._send_json(build_mission_status())
            except Exception as e:
                self._send_json({"error": str(e)}, 500)
        else:
            self._send_json({"error": "not found"}, 404)

    def do_POST(self):
        if self.path.startswith("/agent/system_check"):
            try:
                self._send_json(build_system_check())
            except Exception as e:
                self._send_json({"error": str(e)}, 500)
        else:
            self._send_json({"error": "not found"}, 404)

    def log_message(self, format, *args):
        pass  # quiet -- local_agent.py's own [LOCAL AGENT] prints are enough


def serve_forever(host: str, port: int) -> None:
    print(f"[LOCAL AGENT] Diagnostics HTTP server listening on {host}:{port} "
          f"(GET /agent/diagnostics, POST /agent/system_check, GET /agent/command_history, "
          f"GET /agent/decision_timeline, GET /agent/mission, GET /agent/pixhawk_mission)")
    try:
        ThreadingHTTPServer((host, port), Handler).serve_forever()
    except Exception as e:
        print(f"[LOCAL AGENT] Diagnostics HTTP server crashed: {e}", file=sys.stderr)
