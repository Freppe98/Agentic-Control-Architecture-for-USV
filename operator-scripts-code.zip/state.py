"""
Shared mutable Scout state.

Mutable containers (list, dict) are safe to share across modules via reference.
Immutable scalars (mission_active, etc.) stay in app.py and are passed to
services via the app_state_getter registered in agent_state.init().
"""

gps_log: list = []

latest_measurements: dict = {
    'temperature': None,
    'ph': None,
    'conductivity': None,
    'turbidity': None,
    'last_sample': None,
}
