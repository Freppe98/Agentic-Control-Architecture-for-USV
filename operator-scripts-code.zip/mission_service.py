"""
Read-only mission-download service: fetches the mission actually stored on
the Pixhawk right now, using the real MAVLink mission-download handshake

    MISSION_REQUEST_LIST -> MISSION_COUNT
    MISSION_REQUEST_INT(seq) -> MISSION_ITEM_INT(seq)   for seq in range(count)

against mavlink2rest, the same HTTP bridge every other MAVLink interaction in
this codebase goes through (see app.py's mav_get/mav_post). There is no
pymavlink/mavutil connection anywhere in this repo -- mavlink2rest owns the
actual MAVLink socket, this process only ever GETs its message cache and
POSTs messages for it to send.

mavlink2rest never expires a cached message on its own (see
mavlink_message_utils.py's docstring) -- a channel that stopped answering
hours ago still returns its last-known value. Worse, a message that *does*
change can still be the wrong answer: mavlink2rest caches exactly one slot
per (vehicle, component, message type) -- there is no per-request id, no
per-seq slot, and (confirmed against a real Pixhawk) no reliable signal that
distinguishes "a fresh reply to the request I just sent" from "some other
message of the same type that happened to land in that slot" (a reply
mavlink2rest attributes to an earlier, unrelated poll; a retry's answer
arriving after a later retry already gave up; anything else that shares the
message type). A naive "post the request, sleep a fixed amount, read
whatever's cached" (the pattern the older /nav/fetch_mission and
/nav/mission_count routes in app.py use) can silently return a stale
response. The confirmed real-world failure this module now specifically
guards against is subtler than that: a MISSION_ITEM_INT whose cache slot
*did* visibly change and whose own `seq` field *did* match what was
requested, but whose content was still the previous mission -- see
"Freshness mechanism" below for why token-change-plus-seq-match alone isn't
sufficient proof, and what this module checks instead.

Call init() once at app startup (same pattern as diagnostics_service.py),
then:
  - download_mission()          -- legacy/original schema, GET /agent/mission
  - download_pixhawk_mission()  -- GET /agent/pixhawk_mission, the schema the
                                    operator station's Pixhawk Mission card
                                    actually consumes; adds mission content
                                    validation (duplicate sequences, invalid
                                    coordinates, undecodable items) and a
                                    deterministic mission hash for the
                                    operator's future mission-comparison use.
Both share the same low-level fetch helpers below -- there is exactly one
MAVLink download implementation, not two.

Strictly read-only: every mav_post call here either *requests* Pixhawk state
(MISSION_REQUEST_LIST / MISSION_REQUEST_INT) or *closes* the transfer session
that request opened (MISSION_ACK -- see _send_mission_ack() and "Known
limitations" below). Nothing here ever posts MISSION_COUNT, MISSION_ITEM_INT,
or MISSION_CLEAR_ALL -- those are the write-side messages /nav/upload_mission
and /nav/clear_mission use, and this module never calls them. Scout (the
vehicle) remains the sole owner of the mission; nothing in this module ever
changes what's stored on the Pixhawk. (The MISSION_ACK sent here is a
transfer-session close, never mission content -- it carries no waypoint data
and cannot write, clear, or alter anything the Pixhawk has stored.)

Freshness mechanism
--------------------
Every fetch (download_mission()/download_pixhawk_mission()) creates a
_Transaction: a generation number, a start timestamp, and the expected
target system/component/mission_type. That transaction is threaded through
every MISSION_REQUEST_LIST/MISSION_REQUEST_INT sub-request it makes. A
candidate MISSION_COUNT or MISSION_ITEM_INT reply is only accepted if *all*
of the following hold:

  1. Its `status.time.last_update` token differs from what was cached
     immediately before this specific sub-request was posted (proves *some*
     new arrival happened -- the pre-existing check).
  2. mavlink2rest's own reported arrival time for it (parsed from that same
     timestamp field) is not earlier than the wall-clock moment this
     specific sub-request was posted, i.e. it is provably a reply that could
     only have been produced *after* we asked -- not merely "different from
     whatever I last happened to read" (which a message that changed for
     unrelated reasons, or a delayed answer to an earlier retry, can also
     satisfy). This is the literal "received after the request timestamp"
     proof, and it does not depend on how tightly the baseline read in (1)
     was timed relative to the post.
  3. Where present, the message's own `mission_type` field matches the
     transaction's expected mission type.
  4. Where present, the sending system/component (mavlink2rest's envelope
     header) matches the Pixhawk's expected identity.
  5. For MISSION_ITEM_INT specifically, its own `seq` field equals the
     `seq` just requested.

(1)+(5) alone is what this module originally relied on, and is what a
19-item-mission download with the wrong content for items 1-13 (item 0 --
the ArduPilot-injected home position -- reading correctly, because it's
regenerated from current position on every reply) was able to slip past:
both conditions are satisfiable by a message that is "new" only in the sense
that its cache slot happened to change, while still not being the genuine
answer to *this* request. (2)-(4) close that gap: (2) proves the reply's own
timestamp cannot predate this request, (3)/(4) reject a reply carrying an
unexpected mission type or source where mavlink2rest's envelope reports one.

Known limitations (see also "Choose a robust solution and document its
limitations" -- this module's mechanism, and what it does *not* solve):

  - mavlink2rest's public GET/POST message-cache API (the only interface
    this process talks to it through -- see module docstring above) exposes
    no DELETE/invalidate verb for a single cached message and no exposed
    generation/sequence counter distinct from `status.time.last_update`, so
    "clear the cache slot before requesting" and "observe a changed
    mavlink2rest-native counter" (both raised as options worth investigating)
    are not available to build on; this module was only able to combine the
    timestamp/mission_type/source/seq signals actually exposed today.
  - The freshness proof in (2) assumes this Flask process's clock and
    mavlink2rest's clock are reasonably in sync (a small _CLOCK_SKEW_TOLERANCE_S
    allowance is applied, but a large, unbounded skew between the two hosts
    could still cause a genuine fresh reply to be rejected, or -- in the
    opposite skew direction -- narrow the window in which a stale one could
    still be accepted). Not verified against the real deployment's clock
    setup.
  - If mavlink2rest ever fails to supply a parseable timestamp on a message
    (malformed/missing `status.time.last_update`), this module degrades to
    proof (1) alone for that message rather than hard-failing -- a
    deliberate choice (a fetch that could never succeed at all otherwise is
    worse than a narrower freshness guarantee), documented rather than
    silently assumed safe.
  - MISSION_ACK is now sent at the end of every download attempt (see
    _send_mission_ack()) -- confirmed against mavlink.io's Mission Protocol
    page ("On successful completion, the message must contain type of
    MAV_MISSION_ACCEPTED; this is sent by the system that is receiving the
    command/data -- e.g. ... the GCS for mission download") that omitting
    this closing ack was a real protocol violation, not just a documented
    gap: without it, ArduPilot's mission-sender state machine has no signal
    that a previous download ever finished, and a subsequent
    MISSION_REQUEST_LIST can be answered with an unsolicited MISSION_ACK
    instead of a fresh MISSION_COUNT -- exactly the observed failure mode
    ("MISSION_REQUEST_LIST/MISSION_REQUEST_INT/MISSION_ACK seen, MISSION_COUNT/
    MISSION_ITEM_INT never seen again"). MISSION_ACK's own field is named
    `type` in the MAVLink XML (MAV_MISSION_RESULT), which collides with
    mavlink2rest's REST convention of using the top-level `type` key for the
    message name; confirmed (via mavlink2rest's own published HEARTBEAT
    example, which renames its identically-colliding `type`/MAV_TYPE field
    to `mavtype`) that mavlink2rest resolves this the same way for every
    message with a literal `type` field, so MISSION_ACK's result code is
    posted as `mavtype` here, not `type`.
"""
import hashlib
import itertools
import json
import threading
import time
from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple

import requests

from services.mavlink_message_utils import last_update_token, last_update_epoch

TARGET_SYSTEM = 1
TARGET_COMPONENT = 1
MISSION_TYPE = "MAV_MISSION_TYPE_MISSION"

# MISSION_ACK.type (MAV_MISSION_RESULT) values this module actually sends --
# see _send_mission_ack(). MAV_MISSION_ACCEPTED closes a fully valid
# download; MAV_MISSION_OPERATION_CANCELLED closes one that never got a
# MISSION_COUNT or stopped partway through, so ArduPilot's mission-sender
# state is released either way rather than only on success.
_MISSION_ACK_ACCEPTED = "MAV_MISSION_ACCEPTED"
_MISSION_ACK_CANCELLED = "MAV_MISSION_OPERATION_CANCELLED"

_BASE_PATH = f"/mavlink/vehicles/{TARGET_SYSTEM}/components/{TARGET_COMPONENT}/messages"
_MISSION_COUNT_PATH = f"{_BASE_PATH}/MISSION_COUNT"
_MISSION_ITEM_PATH = f"{_BASE_PATH}/MISSION_ITEM_INT"
_MISSION_CURRENT_PATH = f"{_BASE_PATH}/MISSION_CURRENT"
_HOME_POSITION_PATH = f"{_BASE_PATH}/HOME_POSITION"

# Bounded timeout/retry knobs. Kept module-level (not a config.py, this
# service has no such file) same as mavlink_health.py's HEARTBEAT_TIMEOUT_S.
_POLL_INTERVAL_S = 0.05
_COUNT_TIMEOUT_S = 2.0
_COUNT_MAX_RETRIES = 3
_ITEM_TIMEOUT_S = 1.5
_ITEM_MAX_RETRIES = 3
_OVERALL_TIMEOUT_S = 20.0

# Allowance for clock disagreement between this Flask process and
# mavlink2rest when comparing mavlink2rest's own reported arrival time for a
# message against the wall-clock moment we posted the request for it -- see
# module docstring "Freshness mechanism" / "Known limitations".
_CLOCK_SKEW_TOLERANCE_S = 0.25

# mavlink2rest fields loiter time is meaningful for -- MAV_CMD_NAV_WAYPOINT's
# and MAV_CMD_NAV_LOITER_TIME's param1 is a hold/loiter time in seconds; on
# every other command param1 means something else entirely, so it would be
# fabricating meaning to report it as loiter_time there.
_LOITER_TIME_COMMANDS = {"MAV_CMD_NAV_WAYPOINT", "MAV_CMD_NAV_LOITER_TIME"}

# Commands whose x/y (latitude/longitude) fields are an actual position --
# coordinate validation only applies to these. Plenty of legitimate mission
# items (DO_*/CONDITION_* commands) reuse x/y/z for non-position parameters
# or leave them at 0 entirely; flagging those as "invalid coordinates" would
# be a false positive, not a real data-quality problem.
_POSITION_COMMANDS = {
    "MAV_CMD_NAV_WAYPOINT",
    "MAV_CMD_NAV_RETURN_TO_LAUNCH",
    "MAV_CMD_NAV_LOITER_TIME",
    "MAV_CMD_NAV_LOITER_UNLIM",
    "MAV_CMD_NAV_LOITER_TURNS",
    "MAV_CMD_NAV_LAND",
    "MAV_CMD_NAV_TAKEOFF",
    "MAV_CMD_NAV_SPLINE_WAYPOINT",
}

# Single gunicorn worker (gthread, multiple threads -- see gunicorn_config.py)
# means two overlapping GET /agent/mission(_pixhawk) calls would otherwise
# interleave MISSION_REQUEST_INT/MISSION_ITEM_INT traffic against the same
# mavlink2rest cache, exactly the "don't open a second connection" hazard for
# a protocol that has no request id of its own to disambiguate replies.
# Serialized here rather than left to the caller. The last-known-good caches
# below are also only ever touched while holding this lock.
_download_lock = threading.Lock()

# Monotonic per-process transaction/generation counter -- every
# download_mission()/download_pixhawk_mission() call gets its own, exposed
# in the response as `generation` so a specific fetch attempt can be
# correlated in logs/operator tooling. See module docstring "Freshness
# mechanism" and requirement for "a transaction identifier or generation...
# so responses from previous mission downloads cannot satisfy a new
# download" -- the actual cross-request contamination this guards against
# happens on mavlink2rest's side (its single cache slot per message type),
# which is why the *content* checks in _Transaction-aware freshness proof
# above do the real work; this counter makes each attempt auditable.
_generation_counter = itertools.count(1)

# Last-known-good full results, kept only as explicitly-labelled cache data
# (`cached`/`stale` in the response) -- populated only after a fully
# mission_valid download, never substituted for a fresh result unless *no*
# current waypoint could be confirmed at all this attempt. See
# _cache_fallback().
_last_good_legacy: Optional[dict] = None
_last_good_pixhawk: Optional[dict] = None

_mav_get: Optional[Callable] = None
_mav_post: Optional[Callable] = None
_mavlink_base_url: Optional[str] = None


def init(mav_get_fn: Callable, mav_post_fn: Callable, mavlink_base_url: str) -> None:
    global _mav_get, _mav_post, _mavlink_base_url
    _mav_get = mav_get_fn
    _mav_post = mav_post_fn
    _mavlink_base_url = mavlink_base_url


def reset_last_known_good() -> None:
    """
    Clears both last-known-good caches (see `cached`/`stale` in the
    download_mission()/download_pixhawk_mission() schema). Not called
    anywhere in normal operation -- a real process is meant to accumulate
    the last successful download for the rest of its life -- this exists so
    tests exercising the cache-fallback path can start from a known-empty
    state instead of leaking a previous test's cached mission into the
    next one.
    """
    global _last_good_legacy, _last_good_pixhawk
    _last_good_legacy = None
    _last_good_pixhawk = None


def _safe_get(path: str):
    try:
        return _mav_get(path)
    except Exception:
        return None


def mavlink2rest_reachable(timeout: float = 1.0) -> bool:
    if not _mavlink_base_url:
        return False
    try:
        requests.get(_mavlink_base_url, timeout=timeout)
        return True
    except Exception:
        return False


@dataclass(frozen=True)
class _Transaction:
    """
    One mission-fetch attempt's identity, created fresh by every
    download_mission()/download_pixhawk_mission() call (_new_transaction())
    and threaded through every sub-request it makes -- see module docstring
    "Freshness mechanism" for what this is used to prove.
    """
    generation: int
    started_at: float
    target_system: int
    target_component: int
    mission_type: str


def _new_transaction() -> _Transaction:
    return _Transaction(
        generation=next(_generation_counter),
        started_at=time.time(),
        target_system=TARGET_SYSTEM,
        target_component=TARGET_COMPONENT,
        mission_type=MISSION_TYPE,
    )


def _decode_enum(value):
    return value.get("type") if isinstance(value, dict) else value


def _envelope_mission_type(envelope: dict) -> Optional[str]:
    """The message's own `mission_type` field, decoded, when present --
    MISSION_COUNT/MISSION_ITEM_INT both carry one in the same
    {"type": "MAV_MISSION_TYPE_..."} shape this module posts requests with
    (see _fetch_mission_count/_fetch_mission_item). None if absent/malformed
    -- callers must treat that as "unknown, don't reject on this alone", not
    as a mismatch; see _matches_transaction()."""
    try:
        return _decode_enum(envelope["message"].get("mission_type"))
    except (KeyError, TypeError, AttributeError):
        return None


def _envelope_source(envelope: dict) -> Optional[Tuple[int, int]]:
    """(system_id, component_id) the message actually came from, read from
    mavlink2rest's envelope header, when present. This module's own
    mav_post wrapper (app.py) always addresses TARGET_SYSTEM/TARGET_COMPONENT
    as the *recipient*; the header, if mavlink2rest exposes one on GET
    responses, identifies the *sender* -- unverified against a live
    mavlink2rest instance (see module docstring "Known limitations"), so a
    missing/unrecognized shape yields None (checked opportunistically, never
    required) rather than a false rejection."""
    try:
        header = envelope["header"]
        return header["system_id"], header["component_id"]
    except (KeyError, TypeError):
        return None


def _matches_transaction(envelope: dict, txn: _Transaction) -> bool:
    """mission_type/source checks applied to every accepted MISSION_COUNT
    and MISSION_ITEM_INT: a mismatch is only ever a *rejection* signal,
    never acceptance -- the field simply being absent from a given
    mavlink2rest response is not treated as a failure, per "require...
    where available"."""
    mission_type = _envelope_mission_type(envelope)
    if mission_type is not None and mission_type != txn.mission_type:
        return False
    source = _envelope_source(envelope)
    if source is not None and source != (txn.target_system, txn.target_component):
        return False
    return True


def _envelope_is_fresh(envelope: dict, baseline_token, not_before: float) -> bool:
    """
    True only if `envelope` both (a) carries a `status.time.last_update`
    token different from `baseline_token` -- a new arrival relative to what
    was cached immediately before this specific sub-request was posted --
    AND (b) mavlink2rest's own reported arrival time for it is not earlier
    than `not_before` (the wall-clock moment this specific sub-request was
    posted, minus _CLOCK_SKEW_TOLERANCE_S). (a) alone proves only "the cache
    slot changed since I last looked", which a message that changed for an
    unrelated reason, or a delayed answer to an earlier retry, can also
    satisfy; (b) is the "received after the request timestamp" proof and
    does not depend on how tightly (a)'s baseline read was timed relative to
    the post. If mavlink2rest supplies no parseable timestamp at all, this
    degrades to proof (a) alone rather than hard-failing every fetch -- see
    module docstring "Known limitations".
    """
    token = last_update_token(envelope)
    if token is None or token == baseline_token:
        return False
    arrival = last_update_epoch(envelope)
    if arrival is None:
        return True
    return arrival >= not_before - _CLOCK_SKEW_TOLERANCE_S


def _wait_for_fresh(path: str, baseline_token, not_before: float, deadline: float,
                     txn: _Transaction, predicate: Optional[Callable] = None):
    """
    Poll `path` until a message that is provably fresh (_envelope_is_fresh),
    belongs to this transaction (_matches_transaction), and (if given)
    satisfies `predicate` arrives, or `deadline` (an absolute time.time())
    passes. Returns (envelope, token); envelope is None on timeout.
    """
    while time.time() < deadline:
        envelope = _safe_get(path)
        if (envelope is not None
                and _envelope_is_fresh(envelope, baseline_token, not_before)
                and _matches_transaction(envelope, txn)
                and (predicate is None or predicate(envelope))):
            return envelope, last_update_token(envelope)
        time.sleep(_POLL_INTERVAL_S)
    return None, baseline_token


def _fetch_mission_count(txn: _Transaction, overall_deadline: float):
    """MISSION_REQUEST_LIST -> MISSION_COUNT, bounded by _COUNT_TIMEOUT_S per
    attempt and _COUNT_MAX_RETRIES attempts, both capped by overall_deadline.
    Only accepts a reply that passes the full freshness/mission_type/source
    proof for this transaction -- see module docstring "Freshness
    mechanism"."""
    baseline_token = last_update_token(_safe_get(_MISSION_COUNT_PATH))
    for _ in range(_COUNT_MAX_RETRIES):
        if time.time() >= overall_deadline:
            return None, "timed out waiting for MISSION_COUNT"
        _mav_post({
            "type": "MISSION_REQUEST_LIST",
            "target_system": txn.target_system,
            "target_component": txn.target_component,
            "mission_type": {"type": txn.mission_type},
        })
        request_sent_at = time.time()
        attempt_deadline = min(overall_deadline, request_sent_at + _COUNT_TIMEOUT_S)
        envelope, baseline_token = _wait_for_fresh(
            _MISSION_COUNT_PATH, baseline_token, request_sent_at, attempt_deadline, txn,
        )
        if envelope is not None:
            try:
                return envelope["message"]["count"], None
            except (KeyError, TypeError):
                return None, "malformed MISSION_COUNT response"
    return None, (
        f"no MISSION_COUNT response for mission_type={txn.mission_type} from "
        f"system {txn.target_system}/{txn.target_component} after {_COUNT_MAX_RETRIES} attempts"
    )


def _send_mission_ack(txn: _Transaction, result: str) -> None:
    """
    Closes this transaction's mission-transfer session on the Pixhawk side.
    The MAVLink Mission Protocol requires the *receiving* side of a transfer
    to send the closing MISSION_ACK -- for a download, that's the GCS (this
    module), not ArduPilot (see module docstring "Known limitations"). Every
    download_mission()/download_pixhawk_mission() call now sends exactly one
    of these, whether or not a MISSION_COUNT was ever obtained: ArduPilot's
    mission-sender state has no other way to learn a given attempt is over,
    and leaving it dangling was confirmed to make the *next* attempt's
    MISSION_REQUEST_LIST come back as an unsolicited MISSION_ACK instead of a
    fresh MISSION_COUNT.

    Posted as `mavtype` rather than MISSION_ACK's own field name (`type`) --
    see module docstring for why mavlink2rest's REST schema needs that
    rename to avoid colliding with its own top-level message-name `type` key.
    """
    _mav_post({
        "type": "MISSION_ACK",
        "target_system": txn.target_system,
        "target_component": txn.target_component,
        "mavtype": {"type": result},
        "mission_type": {"type": txn.mission_type},
    })


def _fetch_mission_item(seq: int, txn: _Transaction, overall_deadline: float):
    """MISSION_REQUEST_INT(seq) -> MISSION_ITEM_INT(seq), bounded by
    _ITEM_TIMEOUT_S per attempt and _ITEM_MAX_RETRIES attempts, both capped
    by overall_deadline. Only accepts a reply that passes the full
    freshness/mission_type/source proof for this transaction *and* whose own
    `seq` field matches what was requested -- mavlink2rest caches exactly
    one MISSION_ITEM_INT regardless of seq, so without the seq check a reply
    to a *different* request (a race, or a leftover from a previous call)
    could be mistaken for this one; without the rest of the proof, a reply
    that merely *looks* new (changed cache slot, matching seq -- both
    satisfiable by contamination from an earlier or unrelated transfer, see
    module docstring) could be too."""
    baseline_token = last_update_token(_safe_get(_MISSION_ITEM_PATH))

    def _is_requested_seq(envelope) -> bool:
        try:
            return envelope["message"]["seq"] == seq
        except (KeyError, TypeError):
            return False

    for _ in range(_ITEM_MAX_RETRIES):
        if time.time() >= overall_deadline:
            return None, f"timed out waiting for MISSION_ITEM_INT seq={seq}"
        _mav_post({
            "type": "MISSION_REQUEST_INT",
            "seq": seq,
            "target_system": txn.target_system,
            "target_component": txn.target_component,
            "mission_type": {"type": txn.mission_type},
        })
        request_sent_at = time.time()
        attempt_deadline = min(overall_deadline, request_sent_at + _ITEM_TIMEOUT_S)
        envelope, baseline_token = _wait_for_fresh(
            _MISSION_ITEM_PATH, baseline_token, request_sent_at, attempt_deadline, txn,
            predicate=_is_requested_seq,
        )
        if envelope is not None:
            return envelope, None
    return None, f"no matching MISSION_ITEM_INT for seq={seq} after {_ITEM_MAX_RETRIES} attempts"


def _fetch_current_waypoint() -> Optional[int]:
    """
    MISSION_CURRENT.seq, read directly from whatever mavlink2rest has
    cached -- never estimated, derived, or carried over from a previous
    response. Unlike MISSION_COUNT/MISSION_ITEM_INT there is no
    "request and wait for a fresh reply" step: MISSION_CURRENT is a
    periodic ArduPilot broadcast with no MISSION_REQUEST_* counterpart, so
    this can only report the most recent value mavlink2rest has seen (or
    None if it has never seen one) -- see README "MAVLink limitations".
    """
    envelope = _safe_get(_MISSION_CURRENT_PATH)
    if envelope is None:
        return None
    try:
        return envelope["message"]["seq"]
    except (KeyError, TypeError):
        return None


def _fetch_home_position() -> Optional[dict]:
    """
    Best-effort, cache-only read of HOME_POSITION -- ArduPilot broadcasts
    this once when home/EKF origin is set, not on a repeating stream, so
    unlike MISSION_COUNT/MISSION_ITEM_INT there is no equivalent "request
    and wait for a fresh reply" handshake to perform here. See this
    module's docstring / README "MAVLink limitations": a null value here
    can mean either "no home set" or "mavlink2rest hasn't been sent one
    since it last restarted", and this module cannot tell those apart.
    """
    envelope = _safe_get(_HOME_POSITION_PATH)
    if envelope is None:
        return None
    try:
        msg = envelope["message"]
        return {
            "latitude": round(msg["latitude"] / 1e7, 7),
            "longitude": round(msg["longitude"] / 1e7, 7),
            "altitude": round(msg["altitude"] / 1000.0, 3),
        }
    except (KeyError, TypeError):
        return None


def _decode_waypoint(envelope: dict) -> Optional[dict]:
    """
    Decodes one MISSION_ITEM_INT envelope. Returns None (rather than a
    dict with guessed/placeholder fields) if the message is missing a
    `seq` or `command` -- the two fields everything else here depends on
    to be meaningful -- so the caller can record it as an unsupported item
    instead of fabricating one.
    """
    try:
        msg = envelope["message"]
        seq = msg["seq"]
        command = _decode_enum(msg.get("command"))
        if command is None:
            return None
        param1, param2, param3, param4 = (msg.get(f"param{i}") for i in (1, 2, 3, 4))
        autocontinue = msg.get("autocontinue")
        return {
            "sequence": seq,
            "latitude": round(msg["x"] / 1e7, 7) if msg.get("x") is not None else None,
            "longitude": round(msg["y"] / 1e7, 7) if msg.get("y") is not None else None,
            "altitude": msg.get("z"),
            "command": command,
            "frame": _decode_enum(msg.get("frame")),
            "autocontinue": bool(autocontinue) if autocontinue is not None else None,
            "loiter_time": param1 if command in _LOITER_TIME_COMMANDS else None,
            "param1": param1,
            "param2": param2,
            "param3": param3,
            "param4": param4,
        }
    except (KeyError, TypeError):
        return None


def _download_items(count: int, txn: _Transaction, overall_deadline: float):
    """
    Fetches MISSION_ITEM_INT for every seq in range(count). Returns
    (waypoints, partial, unsupported_sequences, item_error):
      - waypoints: successfully decoded items, in seq order, never padded
        with guessed data for a seq that failed.
      - partial: True iff the download stopped before reaching `count`
        (timeout or no matching reply) -- distinct from an individual item
        merely failing to decode.
      - unsupported_sequences: seqs whose MISSION_ITEM_INT arrived but
        couldn't be decoded (see _decode_waypoint) -- the download kept
        going past these rather than aborting, since one malformed/unusual
        item doesn't mean the rest of the mission is unreadable.
      - item_error: the timeout/fetch error that caused `partial`, if any.
    """
    waypoints: List[dict] = []
    unsupported_sequences: List[int] = []
    item_error: Optional[str] = None
    partial = False

    for seq in range(count):
        if time.time() >= overall_deadline:
            item_error = f"timed out after fetching {len(waypoints) + len(unsupported_sequences)}/{count} waypoints"
            partial = True
            break
        envelope, fetch_err = _fetch_mission_item(seq, txn, overall_deadline)
        if envelope is None:
            item_error = fetch_err
            partial = True
            break
        decoded = _decode_waypoint(envelope)
        if decoded is None:
            unsupported_sequences.append(seq)
        else:
            waypoints.append(decoded)

    return waypoints, partial, unsupported_sequences, item_error


def _find_duplicate_sequences(waypoints: List[dict]) -> List[int]:
    """
    Structurally, _fetch_mission_item's seq-matching predicate means a
    single download() call cannot request the same seq twice, so this
    should never find anything today -- kept as a real, cheap defensive
    check (not a fabricated "just in case" placeholder) against a future
    change to the fetch strategy, or a mavlink2rest response shape this
    module doesn't currently anticipate.
    """
    seen = set()
    duplicates = []
    for wp in waypoints:
        seq = wp["sequence"]
        if seq in seen:
            duplicates.append(seq)
        seen.add(seq)
    return duplicates


def _find_invalid_coordinate_sequences(waypoints: List[dict]) -> List[int]:
    """Flags position-bearing waypoints (_POSITION_COMMANDS) whose
    latitude/longitude are missing or outside the valid numeric range.
    Coordinates on non-position commands (DO_*/CONDITION_*, which reuse
    x/y/z for other parameters) are never checked -- see _POSITION_COMMANDS."""
    invalid = []
    for wp in waypoints:
        if wp["command"] not in _POSITION_COMMANDS:
            continue
        lat, lon = wp["latitude"], wp["longitude"]
        if lat is None or lon is None or not (-90.0 <= lat <= 90.0) or not (-180.0 <= lon <= 180.0):
            invalid.append(wp["sequence"])
    return invalid


def _summarize_error(item_error, duplicate_sequences, invalid_sequences, unsupported_sequences) -> Optional[str]:
    problems = []
    if item_error:
        problems.append(item_error)
    if duplicate_sequences:
        problems.append(f"duplicate sequence number(s): {duplicate_sequences}")
    if invalid_sequences:
        problems.append(f"invalid coordinates at sequence(s): {invalid_sequences}")
    if unsupported_sequences:
        problems.append(f"unsupported/undecodable mission item(s) at sequence(s): {unsupported_sequences}")
    return "; ".join(problems) if problems else None


def compute_mission_hash(waypoints: List[dict]) -> str:
    """
    Deterministic SHA256 over the operator-relevant mission content --
    sequence, command, frame, latitude, longitude, altitude, and all four
    mission parameters -- so the hash changes if and only if one of those
    changes, not e.g. this service's own request timing or field ordering.

    SHA256 (stdlib hashlib, no new dependency) rather than CRC32: this hash
    is meant for the operator to detect *any* real mission difference, and
    CRC32's much higher collision rate makes a false "unchanged" reading
    plausible over the number of comparisons a fleet could accumulate --
    not an acceptable trade for a size-negligible mission payload where
    CRC32's speed advantage doesn't matter.

    Waypoints are sorted by sequence before hashing (independent of
    whatever order the caller's list happens to be in) and serialized via
    json.dumps with sort_keys=True and fixed separators, so the exact same
    mission always produces the exact same digest regardless of dict
    key-insertion order or incidental whitespace.
    """
    ordered = sorted(waypoints, key=lambda wp: wp["sequence"])
    canonical = json.dumps(
        [
            {
                "sequence": wp["sequence"],
                "command": wp["command"],
                "frame": wp["frame"],
                "latitude": wp["latitude"],
                "longitude": wp["longitude"],
                "altitude": wp["altitude"],
                "param1": wp["param1"],
                "param2": wp["param2"],
                "param3": wp["param3"],
                "param4": wp["param4"],
            }
            for wp in ordered
        ],
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _cache_fallback(last_good: Optional[dict], attempt_error: Optional[str], reachable: bool) -> Optional[dict]:
    """
    If a last-known-good full mission exists from a prior successful
    transaction, returns it relabelled as explicitly-cached data: `cached`
    and `stale` both True, `fetched_at` taken from *that* prior transaction
    (not now), `mission_valid` forced False, and `error` naming why *this*
    attempt failed. Never called unless the current attempt confirmed zero
    current waypoints (see callers) -- a genuine partial read of the mission
    actually on the Pixhawk right now is always preferred over substituting
    older cached data, and mixing the two (some fresh waypoints, some
    stale ones papered in from a previous mission) would be strictly more
    misleading than either alone, so this module never does that. Returns
    None (nothing to fall back to) if no prior success has ever been
    recorded in this process.
    """
    if last_good is None:
        return None
    fallback = dict(last_good)
    fallback["mission_valid"] = False
    fallback["cached"] = True
    fallback["stale"] = True
    fallback["reachable"] = reachable
    fallback["error"] = (
        f"{attempt_error or 'fresh mission fetch confirmed no current waypoints'}; "
        f"showing last confirmed mission fetched at {last_good['fetched_at']}"
    )
    return fallback


def _empty_result(fetched_at: float, reachable: bool, error: Optional[str], generation: int,
                   current_waypoint: Optional[int] = None, home_position: Optional[dict] = None) -> dict:
    return {
        "available": False,
        "reachable": reachable,
        "fetched_at": fetched_at,
        "mission_count": None,
        "current_waypoint": current_waypoint,
        "home_position": home_position,
        "waypoints": [],
        "mission_loaded": None,
        "mission_valid": None,
        "last_fetch_age": 0.0,
        "error": error,
        "mission_hash": None,
        "mission_version": None,
        "schema_version": 1,
        "generation": generation,
        "cached": False,
        "stale": False,
    }


def download_mission() -> dict:
    """
    Legacy/original schema (GET /agent/mission). Read-only download of the
    mission currently stored on the Pixhawk. Never uploads, modifies,
    deletes, or overwrites anything. Every field is a real read or explicit
    None; nothing is invented -- a partial/timed-out download still returns
    whatever waypoints it did confirm, flagged via mission_valid=False and
    `error`, rather than being discarded.

    `mission_hash` here uses the exact same compute_mission_hash() as
    download_pixhawk_mission() -- one hash definition, not two -- populated
    whenever mission_valid is True (this field was reserved-but-null since
    this endpoint's introduction specifically for this).

    On a fresh-fetch failure that confirmed zero current waypoints, falls
    back to the last-known-good mission (if any) instead of an empty
    result -- see _cache_fallback() and `cached`/`stale` in the schema.
    """
    global _last_good_legacy
    with _download_lock:
        fetched_at = round(time.time(), 2)
        txn = _new_transaction()

        if not mavlink2rest_reachable():
            fallback = _cache_fallback(_last_good_legacy, "mavlink2rest unreachable", reachable=False)
            if fallback is not None:
                return fallback
            return _empty_result(fetched_at, reachable=False, error="mavlink2rest unreachable",
                                  generation=txn.generation)

        overall_deadline = time.time() + _OVERALL_TIMEOUT_S
        current_waypoint = _fetch_current_waypoint()
        home_position = _fetch_home_position()

        count, error = _fetch_mission_count(txn, overall_deadline)
        if count is None:
            _send_mission_ack(txn, _MISSION_ACK_CANCELLED)
            fallback = _cache_fallback(_last_good_legacy, error, reachable=True)
            if fallback is not None:
                return fallback
            return _empty_result(fetched_at, reachable=True, error=error, generation=txn.generation,
                                  current_waypoint=current_waypoint, home_position=home_position)

        waypoints, partial, unsupported_sequences, item_error = _download_items(count, txn, overall_deadline)
        duplicate_sequences = _find_duplicate_sequences(waypoints)
        invalid_sequences = _find_invalid_coordinate_sequences(waypoints)

        mission_valid = (
            not partial and not duplicate_sequences and not invalid_sequences
            and not unsupported_sequences and len(waypoints) == count
        )
        error_summary = _summarize_error(item_error, duplicate_sequences, invalid_sequences, unsupported_sequences)
        _send_mission_ack(txn, _MISSION_ACK_ACCEPTED if mission_valid else _MISSION_ACK_CANCELLED)

        if not waypoints and not mission_valid:
            fallback = _cache_fallback(_last_good_legacy, error_summary, reachable=True)
            if fallback is not None:
                return fallback

        result = {
            "available": True,
            "reachable": True,
            "fetched_at": fetched_at,
            "mission_count": count,
            "current_waypoint": current_waypoint,
            "home_position": home_position,
            "waypoints": waypoints,
            "mission_loaded": count > 0,
            "mission_valid": mission_valid,
            "last_fetch_age": 0.0,
            "error": error_summary,
            "mission_hash": compute_mission_hash(waypoints) if mission_valid else None,
            "mission_version": None,
            "schema_version": 1,
            "generation": txn.generation,
            "cached": False,
            "stale": False,
        }
        if mission_valid:
            _last_good_legacy = dict(result)
        return result


def _pixhawk_unavailable(mission_loaded, current_seq, error, reachable, fetched_at, generation,
                          partial=None) -> dict:
    return {
        "mission_loaded": mission_loaded,
        "mission_valid": None,
        "count": None,
        "current_seq": current_seq,
        "hash": None,
        "waypoints": [],
        "partial": partial,
        "duplicate_sequences": [],
        "invalid_sequences": [],
        "unsupported_sequences": [],
        "error": error,
        "reachable": reachable,
        "fetched_at": fetched_at,
        "schema_version": 1,
        "generation": generation,
        "cached": False,
        "stale": False,
    }


def download_pixhawk_mission() -> dict:
    """
    GET /agent/pixhawk_mission -- the schema the operator station's Pixhawk
    Mission card actually consumes. Same MAVLink download as
    download_mission() (see _download_items et al.), reshaped with explicit
    mission-content validation and a comparison-ready hash:

        mission_loaded   -- count > 0 (a real, non-empty mission exists);
                             None if count itself couldn't be determined.
        mission_valid    -- the download is complete AND internally
                             consistent: not partial, no duplicate
                             sequences, no out-of-range coordinates, no
                             undecodable items, and every requested seq
                             was retrieved. False on any of those; None if
                             `count` itself is unknown.
        count            -- MISSION_COUNT.count, or None if never obtained.
        current_seq      -- MISSION_CURRENT.seq, read directly, never
                             estimated (see _fetch_current_waypoint).
        hash             -- compute_mission_hash(waypoints), only when
                             mission_valid is True. A hash computed over a
                             partial/inconsistent read would not represent
                             the mission actually stored on the Pixhawk,
                             and could cause a false "the mission changed"
                             reading downstream -- so this is None instead
                             of a misleading value, exactly the "never
                             fabricate" rule applied to the hash itself.
        waypoints        -- decoded items that were successfully read;
                             never padded to `count` with guessed entries.
        partial          -- True iff the download stopped before reaching
                             `count` (timeout, or no matching reply for
                             some seq); None if `count` is unknown.
        duplicate_sequences / invalid_sequences / unsupported_sequences --
                             the specific seqs behind a `mission_valid`
                             False, for operator-side debugging; always
                             `[]` (not omitted) when clean.
        error            -- combined human-readable summary of whatever
                             went wrong, or None.
        reachable        -- mavlink2rest itself answered, independent of
                             whether the mission download succeeded.
        fetched_at       -- unix time this download was attempted, unless
                             `cached` is True, in which case this is the
                             time of the prior successful transaction the
                             cached data actually came from.
        generation       -- this transaction's monotonic id, for
                             correlating a specific response with logs.
        cached / stale   -- True only when this attempt confirmed zero
                             current waypoints and a last-known-good
                             mission from a previous transaction is being
                             shown instead of an empty result -- see
                             _cache_fallback(). Both False on a genuine
                             (even if partial/invalid) fresh read.

    Read-only, same guarantee as download_mission(): only
    MISSION_REQUEST_LIST/MISSION_REQUEST_INT/MISSION_ACK (a session close,
    not mission content -- see _send_mission_ack()) are ever posted. Scout
    (the vehicle) remains the sole owner of mission state -- nothing here
    uploads, clears, or otherwise writes a mission.
    """
    global _last_good_pixhawk
    with _download_lock:
        fetched_at = round(time.time(), 2)
        txn = _new_transaction()

        if not mavlink2rest_reachable():
            fallback = _cache_fallback(_last_good_pixhawk, "mavlink2rest unreachable", reachable=False)
            if fallback is not None:
                return fallback
            return _pixhawk_unavailable(
                mission_loaded=None, current_seq=None, error="mavlink2rest unreachable",
                reachable=False, fetched_at=fetched_at, generation=txn.generation,
            )

        overall_deadline = time.time() + _OVERALL_TIMEOUT_S
        current_seq = _fetch_current_waypoint()

        count, count_error = _fetch_mission_count(txn, overall_deadline)
        if count is None:
            _send_mission_ack(txn, _MISSION_ACK_CANCELLED)
            fallback = _cache_fallback(_last_good_pixhawk, count_error, reachable=True)
            if fallback is not None:
                return fallback
            return _pixhawk_unavailable(
                mission_loaded=None, current_seq=current_seq, error=count_error,
                reachable=True, fetched_at=fetched_at, generation=txn.generation, partial=True,
            )

        waypoints, partial, unsupported_sequences, item_error = _download_items(count, txn, overall_deadline)
        duplicate_sequences = _find_duplicate_sequences(waypoints)
        invalid_sequences = _find_invalid_coordinate_sequences(waypoints)

        mission_valid = (
            not partial and not duplicate_sequences and not invalid_sequences
            and not unsupported_sequences and len(waypoints) == count
        )
        error_summary = _summarize_error(item_error, duplicate_sequences, invalid_sequences, unsupported_sequences)
        _send_mission_ack(txn, _MISSION_ACK_ACCEPTED if mission_valid else _MISSION_ACK_CANCELLED)

        if not waypoints and not mission_valid:
            fallback = _cache_fallback(_last_good_pixhawk, error_summary, reachable=True)
            if fallback is not None:
                return fallback

        result = {
            "mission_loaded": count > 0,
            "mission_valid": mission_valid,
            "count": count,
            "current_seq": current_seq,
            "hash": compute_mission_hash(waypoints) if mission_valid else None,
            "waypoints": waypoints,
            "partial": partial,
            "duplicate_sequences": duplicate_sequences,
            "invalid_sequences": invalid_sequences,
            "unsupported_sequences": unsupported_sequences,
            "error": error_summary,
            "reachable": True,
            "fetched_at": fetched_at,
            "schema_version": 1,
            "generation": txn.generation,
            "cached": False,
            "stale": False,
        }
        if mission_valid:
            _last_good_pixhawk = dict(result)
        return result
