"""
Shared "send MAV_CMD_DO_SET_MODE, then prove the Pixhawk actually changed
mode" logic for every ArduRover mode-change route (AUTO, MANUAL, HOLD,
LOITER, RTL) -- mirrors set_home_service.py's ACK/readback verification
pattern so a request being *sent* is never conflated with it actually
having *happened*.

Root cause this exists to fix: app.py's /nav/rtl previously posted
MAV_CMD_DO_SET_MODE with param1=11, param2=0 -- base_mode and custom_mode
swapped, and the wrong value in each slot -- while every other /nav/* mode
route (AutoModeOn, hold, loiter, manual) hand-rolled its own *separate*
correct call (param1=209, param2=<mode>), each with its own copy of the
same MAVLink shape and none of them reading back COMMAND_ACK or
HEARTBEAT.custom_mode afterward. Four duplicated call sites made the fifth
(RTL) an easy place for the params to drift out of sync unnoticed. This
module is now the *one* place any route sends MAV_CMD_DO_SET_MODE:
ARDUROVER_CUSTOM_MODES is the one name<->int table (also used by
services/agent_state.py's mode_name field, instead of that module keeping
its own copy), and set_mode_and_verify() is the one function every
mode-changing route calls -- app.py's /nav/AutoModeOn, /nav/manual,
/nav/hold, /nav/loiter, /nav/rtl all just supply a mode name (and, for
LOITER, shorter bounds -- see its own module docstring in app.py) and
inspect the returned accepted/verified/observed_mode/reason, never send a
COMMAND_LONG themselves.

Future-proofing for multiple USVs: target_system/target_component are
parameters of every call (defaulting to DEFAULT_TARGET_SYSTEM/
DEFAULT_TARGET_COMPONENT = 1/1, the one vehicle every route in this
codebase talks to today), not module-level constants baked into a fixed
URL at import time -- mavlink2rest addresses vehicles by
`/mavlink/vehicles/{system_id}/components/{component_id}/...`, so a future
deployment fronting more than one system_id through the same mavlink2rest
(or a Pixhawk configured with a non-default SYSID_THISMAV) needs no change
here beyond passing a different target_system/target_component -- the
path is built per call, and the result always echoes back exactly which
target_system/target_component it used.
"""
import time
from typing import Callable, Optional

from services.mavlink_message_utils import last_update_token, last_update_epoch

DEFAULT_TARGET_SYSTEM = 1
DEFAULT_TARGET_COMPONENT = 1

_SET_MODE_COMMAND = "MAV_CMD_DO_SET_MODE"

# ArduRover custom_mode <-> name -- the one table every caller in this
# codebase that needs to go from a mode name to the MAVLink int (this
# module) or from the int back to a name (services/agent_state.py's
# telemetry.mode_name field) shares, instead of each keeping its own copy
# that could silently drift apart. Unrecognized ints (a firmware version
# with a mode this table predates) are handled by the caller, not here --
# see agent_state.py's _mode_name() fallback.
ARDUROVER_CUSTOM_MODES = {
    "MANUAL": 0, "ACRO": 1, "STEERING": 3, "HOLD": 4, "LOITER": 5,
    "FOLLOW": 6, "SIMPLE": 7, "AUTO": 10, "RTL": 11, "SMART_RTL": 12,
    "GUIDED": 15, "INITIALISING": 16,
}
ARDUROVER_MODE_NAMES = {v: k for k, v in ARDUROVER_CUSTOM_MODES.items()}

# base_mode (param1) sent with every DO_SET_MODE here -- SAFETY_ARMED(128)
# | MANUAL_INPUT_ENABLED(64) | STABILIZE_ENABLED(16) | CUSTOM_MODE_ENABLED(1)
# = 209. custom_mode (param2, looked up from ARDUROVER_CUSTOM_MODES above)
# is the only field that actually selects the ArduRover mode.
_BASE_MODE = 209

_DEFAULT_ACK_TIMEOUT_S = 1.5
_DEFAULT_VERIFY_TIMEOUT_S = 5.0
_DEFAULT_STABLE_WINDOW_S = 1.5
_DEFAULT_POLL_INTERVAL_S = 0.1
_CLOCK_SKEW_TOLERANCE_S = 0.25

_mav_get: Optional[Callable] = None
_mav_post: Optional[Callable] = None


def init(mav_get_fn: Callable, mav_post_fn: Callable) -> None:
    global _mav_get, _mav_post
    _mav_get = mav_get_fn
    _mav_post = mav_post_fn


def _messages_path(target_system: int, target_component: int) -> str:
    return f"/mavlink/vehicles/{target_system}/components/{target_component}/messages"


def _safe_get(path: str):
    try:
        return _mav_get(path)
    except Exception:
        return None


def _decode_enum(value):
    return value.get("type") if isinstance(value, dict) else value


def _read_custom_mode(envelope) -> Optional[int]:
    try:
        return envelope["message"]["custom_mode"]
    except (KeyError, TypeError):
        return None


def _current_custom_mode(heartbeat_path: str) -> Optional[int]:
    return _read_custom_mode(_safe_get(heartbeat_path))


def _send_set_mode(custom_mode: int, target_system: int, target_component: int) -> None:
    _mav_post({
        "type": "COMMAND_LONG",
        "param1": _BASE_MODE, "param2": custom_mode, "param3": 0, "param4": 0,
        "param5": 0, "param6": 0, "param7": 0,
        "command": {"type": _SET_MODE_COMMAND},
        "target_system": target_system, "target_component": target_component,
        "confirmation": 0,
    })


def _wait_for_set_mode_ack(ack_path: str, baseline_token, sent_at: float, deadline: float, poll_interval_s: float):
    """Bounded wait for a COMMAND_ACK naming MAV_CMD_DO_SET_MODE, proven
    fresh the same way set_home_service.py proves COMMAND_ACK fresh (a
    status.time.last_update token change from a baseline captured *before*
    the command was sent, plus an arrival time not earlier than `sent_at`)
    -- mavlink2rest caches exactly one COMMAND_ACK regardless of which
    command it acks, so a baseline captured after sending could already be
    this very ack, silently swallowing it as "no change". Not every
    ArduPilot firmware version ACKs DO_SET_MODE, so a timeout here is only
    ever reported as ack_result=None, never treated as a hard failure -- the
    HEARTBEAT.custom_mode readback below is the authoritative signal, this
    is best-effort extra evidence."""
    while time.time() < deadline:
        envelope = _safe_get(ack_path)
        if envelope is not None:
            token = last_update_token(envelope)
            if token is not None and token != baseline_token:
                try:
                    if _decode_enum(envelope["message"]["command"]) == _SET_MODE_COMMAND:
                        arrival = last_update_epoch(envelope)
                        if arrival is None or arrival >= sent_at - _CLOCK_SKEW_TOLERANCE_S:
                            return _decode_enum(envelope["message"].get("result"))
                except (KeyError, TypeError):
                    pass
                baseline_token = token
        time.sleep(poll_interval_s)
    return None


def _log(event, **fields) -> None:
    """Structured single-line logs, same plain-print convention as
    set_home_service.py's [SET_HOME] lines and local_agent.py's [LOCAL
    AGENT] ones."""
    detail = " ".join(f"{k}={v}" for k, v in fields.items())
    print(f"[MODE_VERIFY] {event}: {detail}")


def _result(base, accepted, verified, observed_mode, reason, samples) -> dict:
    return {
        **base,
        "accepted": accepted,
        "verified": verified,
        "observed_mode": observed_mode,
        "reason": reason,
        "samples": samples,
    }


def set_mode_and_verify(
    requested_mode_name: str,
    custom_mode: Optional[int] = None,
    target_system: int = DEFAULT_TARGET_SYSTEM,
    target_component: int = DEFAULT_TARGET_COMPONENT,
    ack_timeout_s: float = _DEFAULT_ACK_TIMEOUT_S,
    verify_timeout_s: float = _DEFAULT_VERIFY_TIMEOUT_S,
    stable_window_s: float = _DEFAULT_STABLE_WINDOW_S,
    poll_interval_s: float = _DEFAULT_POLL_INTERVAL_S,
) -> dict:
    """
    Sends MAV_CMD_DO_SET_MODE for `requested_mode_name` (e.g. "RTL",
    "LOITER", "AUTO", "MANUAL", "HOLD" -- any key of ARDUROVER_CUSTOM_MODES)
    and proves it actually took effect via HEARTBEAT.custom_mode before ever
    reporting verified=true -- never from HTTP success or ACK alone. Never
    raises; always returns a structured dict:

      previous_mode, requested_mode, requested_custom_mode, observed_mode,
      target_system, target_component, ack_result, accepted, verified,
      reason, samples (the HEARTBEAT.custom_mode values polled during
      verification, oldest first -- for diagnosing exactly what happened).

    `custom_mode` is resolved from `ARDUROVER_CUSTOM_MODES[requested_mode_name.upper()]`
    when not given explicitly -- callers should normally just pass the name;
    the explicit override exists for a mode this table doesn't yet know
    about, or a test double.

    `accepted` is true once the Pixhawk's HEARTBEAT reports the requested
    custom_mode at all (within verify_timeout_s of sending the command).
    `verified` is additionally true only if that mode then held for the
    rest of stable_window_s -- catches "briefly enters RTL and immediately
    reverts" (RC mode channel override, another GCS, a failsafe, ...) rather
    than reporting success on a transient blip.
    """
    if custom_mode is None:
        custom_mode = ARDUROVER_CUSTOM_MODES[requested_mode_name.upper()]

    heartbeat_path = f"{_messages_path(target_system, target_component)}/HEARTBEAT"
    ack_path = f"{_messages_path(target_system, target_component)}/COMMAND_ACK"

    previous_mode = _current_custom_mode(heartbeat_path)
    _log("previous_mode", requested=requested_mode_name, custom_mode=custom_mode, previous=previous_mode,
         target_system=target_system, target_component=target_component)

    # Baseline captured *before* sending -- see _wait_for_set_mode_ack's
    # docstring for why a baseline taken after posting the command could
    # already be this very ack (mavlink2rest's single-slot COMMAND_ACK
    # cache), silently swallowing it as "no new token".
    baseline_ack_token = last_update_token(_safe_get(ack_path))
    sent_at = time.time()
    _send_set_mode(custom_mode, target_system, target_component)
    _log("sent_set_mode", requested=requested_mode_name, custom_mode=custom_mode,
         target_system=target_system, target_component=target_component)

    ack_result = _wait_for_set_mode_ack(ack_path, baseline_ack_token, sent_at, sent_at + ack_timeout_s, poll_interval_s)
    _log("ack_result", requested=requested_mode_name, result=ack_result)

    base = {
        "previous_mode": previous_mode,
        "requested_mode": requested_mode_name,
        "requested_custom_mode": custom_mode,
        "target_system": target_system,
        "target_component": target_component,
        "ack_result": ack_result,
    }

    verify_deadline = sent_at + verify_timeout_s
    samples = []
    observed_mode = None
    reached_at = None
    while time.time() < verify_deadline:
        observed_mode = _current_custom_mode(heartbeat_path)
        samples.append(observed_mode)
        if observed_mode == custom_mode:
            reached_at = time.time()
            break
        time.sleep(poll_interval_s)

    if reached_at is None:
        reason = (
            f"Pixhawk never reported custom_mode={custom_mode} ({requested_mode_name}) "
            f"within {verify_timeout_s:.1f}s of the request (last observed custom_mode: {observed_mode})."
        )
        _log("final_result", requested=requested_mode_name, status="not_reached",
             last_observed=observed_mode, samples=samples)
        return _result(base, False, False, observed_mode, reason, samples)

    # Reached the requested mode at least once -- now prove it *held* for
    # stable_window_s rather than being an immediately-overridden blip.
    stable_deadline = min(verify_deadline, reached_at + stable_window_s)
    held = True
    while time.time() < stable_deadline:
        time.sleep(poll_interval_s)
        current = _current_custom_mode(heartbeat_path)
        samples.append(current)
        if current != custom_mode:
            held = False
            observed_mode = current
            break

    if not held:
        reason = (
            f"Pixhawk entered {requested_mode_name} (custom_mode={custom_mode}) but reverted to "
            f"custom_mode={observed_mode} before {stable_window_s:.1f}s of stability elapsed -- "
            "another source (RC mode channel, failsafe, another GCS, or the Local Agent) likely overrode it."
        )
        _log("final_result", requested=requested_mode_name, status="reverted",
             observed=observed_mode, samples=samples)
        return _result(base, True, False, observed_mode, reason, samples)

    _log("final_result", requested=requested_mode_name, status="verified",
         observed=custom_mode, samples=samples)
    return _result(base, True, True, custom_mode, None, samples)
