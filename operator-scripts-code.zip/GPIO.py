from gpiozero import DigitalInputDevice
from gpiozero import DigitalOutputDevice
from time import sleep
import subprocess
import traceback


class PinctrlOutputDevice:
    """Fallback for pins claimed by other subsystems (e.g. I2C).
    Uses pinctrl to write directly to hardware registers."""

    def __init__(self, pin: int):
        self.pin = pin
        subprocess.run(["/usr/bin/pinctrl", "set", str(pin), "op", "dl"], check=True)
        print(f"PinctrlOutputDevice: pin {pin} configured as output (low)")

    def on(self):
        subprocess.run(["/usr/bin/pinctrl", "set", str(self.pin), "op", "dh"], check=True)

    def off(self):
        subprocess.run(["/usr/bin/pinctrl", "set", str(self.pin), "op", "dl"], check=True)

    def close(self):
        self.off()


class GPIOManager:
    
    


    def __init__(self):
        try:
            print("GPIO init")
            self.inputPins = {}
            self.outputPins = {}
        except Exception as e:
            print(f"Error initializing GPIOManager: {e}")
            traceback.print_exc()
            raise

    
    
    def DefinePin(self, pinName: str, pinNum: int, OUTPUT: bool, pullUp: bool = False, retries: int = 5, delay: float = 0.5) -> bool:
        """Define a GPIO pin with retry if busy. Falls back to pinctrl for output pins."""
        for attempt in range(retries):
            try:
                if OUTPUT:
                    self.outputPins[pinName] = DigitalOutputDevice(pinNum)
                else:
                    self.inputPins[pinName] = DigitalInputDevice(pinNum, pull_up=pullUp)
                print(f"Pin {pinName} defined successfully (pin {pinNum}, output={OUTPUT})")
                return True
            except Exception as e:
                print(f"Attempt {attempt+1} failed to define pin {pinName} (pin {pinNum}): {e}")
                sleep(delay)

        # Fallback to pinctrl for output pins claimed by other subsystems
        if OUTPUT:
            try:
                self.outputPins[pinName] = PinctrlOutputDevice(pinNum)
                print(f"Pin {pinName} defined via pinctrl fallback (pin {pinNum})")
                return True
            except Exception as e:
                print(f"Pinctrl fallback also failed for pin {pinName}: {e}")

        print(f"Failed to define pin {pinName} after {retries} attempts")
        return False



    def ReadPin(self, pinName:str):
        """Read a GPIO pin value with error handling"""
        try:
            if pinName in self.inputPins:
                return self.inputPins[pinName].value
            else:
                raise KeyError(f"Pin {pinName} not found in input pins")
        except Exception as e:
            print(f"Error reading pin {pinName}: {e}")
            traceback.print_exc()
            raise



    def SetPin(self, pinName:str, state: bool):
        """Set a GPIO pin state with error handling"""
        try:
            if pinName not in self.outputPins:
                raise KeyError(f"Pin {pinName} not found in output pins")
            
            if state:
                self.outputPins[pinName].on()
            else:
                self.outputPins[pinName].off()
        except Exception as e:
            print(f"Error setting pin {pinName} to {state}: {e}")
            traceback.print_exc()
            raise
            
            
    def cleanup(self):
        """Cleanup all GPIO pins with error handling"""
        try:
            for pin_name, pin in self.outputPins.items():
                try:
                    pin.close()
                except Exception as e:
                    print(f"Error closing output pin {pin_name}: {e}")
            
            for pin_name, pin in self.inputPins.items():
                try:
                    pin.close()
                except Exception as e:
                    print(f"Error closing input pin {pin_name}: {e}")
            
            self.outputPins.clear()
            self.inputPins.clear()
            print("GPIO cleanup complete.")
        except Exception as e:
            print(f"Error during GPIO cleanup: {e}")
            traceback.print_exc()
        
        



#### TEST SCRIPT ####        



if __name__ == '__main__':
    
    print("Testing GPIO")
    gm = GPIOManager()

    #gm.DefinePin("Led",23,True)
    #gm.DefinePin("Leak",25, False, True)
    gm.DefinePin("Sensors",24,True)
    
    gm.SetPin("Sensors",True)
    

