"""
Control authority: which of the two *stored software* authorities currently
owns commanding the vehicle from the Operator Backend's command queue vs.
the Local Agent's own autonomous decision-making.

This stores exactly two values, OPERATOR and LOCAL_AGENT -- there is no
third stored "RC" state. Physical RC override is an independent, always-
available, higher-priority hardware path (RC override > OPERATOR >
LOCAL_AGENT) that this module does not model or mutate: see
motherpi/services/local_mission_agent/README.md "Authority model" for the
full three-way distinction (operator-command relay / Local Agent autonomous
writes / physical RC override) and why RC is deliberately not folded into
this stored field.

Setting this value never sends a MAVLink message and never changes Pixhawk
mode by itself -- it only gates, in motherpi/services/local_mission_agent/
command_handler.py, whether the Local Agent executes commands from the
Operator Backend's queue (OPERATOR) or is instead running its own
autonomous vehicle-control writes (LOCAL_AGENT, gated separately by
motherpi/services/local_mission_agent/autonomy_gate.py). A caller (e.g. the
Local Agent) reads this fresh every cycle rather than caching it -- see
local_agent._current_authority -- so a transition here takes effect on the
next read, no coordination required.

OPERATOR      -- the operator command queue is explicit operator intent:
                 every supported queued command_type executes (SET_HOME and
                 LOITER included, no exemptions -- strict model). The Local
                 Agent's own autonomous vehicle-control writes are blocked.
                 Telemetry, health, communication monitoring, buffering,
                 and event generation all continue regardless. This is the
                 default and safe startup value.
LOCAL_AGENT   -- queued operator commands are rejected with a terminal
                 result (the Local Agent is not taking vehicle-control
                 intent from that queue while it owns the vehicle itself).
                 The Local Agent's own autonomous vehicle-control writes
                 are allowed (subject to its own per-write authority check
                 and to physical RC override, neither of which this module
                 is involved in). This module never blocks or delays a
                 transition back to OPERATOR: see set_authority() below --
                 it is a synchronous, unconditional in-memory assignment.

In-memory only, on purpose: always resets to OPERATOR when this Flask
service (re)starts (e.g. gunicorn worker restart) -- authority is never
persisted and never assumed, only ever explicitly granted via
POST /agent/control_authority.
"""
import time

from services.event_log import add_event

OPERATOR = "OPERATOR"
LOCAL_AGENT = "LOCAL_AGENT"
VALID = (OPERATOR, LOCAL_AGENT)

_authority = OPERATOR
_last_transition: dict | None = None


def get_authority() -> str:
    return _authority


def get_last_transition() -> "dict | None":
    """
    Evidence for the operator's "why did authority change" display -- who/
    what triggered the most recent transition, not just the current value.
    None until the first transition since this Flask process started (in-
    memory only, same lifetime as _authority itself -- see module docstring).
    """
    return _last_transition


def set_authority(value: str, reason: "str | None" = None) -> str:
    """
    Transition control authority to `value` (OPERATOR or LOCAL_AGENT).

    `reason` is supplied by the caller (e.g. the operator UI's "Take
    Control"/"Release Control" action) -- this module records it verbatim
    rather than guessing why a human made the change; it has no way to know
    that on its own. A caller that doesn't supply one gets an honest,
    non-invented fallback string instead of a fabricated explanation.

    Raises ValueError for anything else -- the route handler turns that
    into a 400 rather than silently keeping the previous authority.
    """
    global _authority, _last_transition

    if value not in VALID:
        raise ValueError(f"invalid control authority: {value!r} (must be one of {VALID})")

    previous = _authority
    _authority = value
    if previous != value:
        resolved_reason = reason or "authority changed via POST /agent/control_authority (no reason supplied)"
        print(f"[CONTROL AUTHORITY] {previous} -> {value}: {resolved_reason}")
        add_event('CONTROL_AUTHORITY_CHANGED', detail={'from': previous, 'to': value, 'reason': resolved_reason})
        _last_transition = {
            'from': previous,
            'to': value,
            'reason': resolved_reason,
            'timestamp': round(time.time(), 2),
        }
    return _authority
